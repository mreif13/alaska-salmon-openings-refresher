# Reconstructed fixtures — read this before trusting them

These two files are NOT the app's own PDF extraction. They were rebuilt from
verbatim transcription of the published ADF&G PDFs when the announcement
service was unreachable from the build sandbox:

* `KOD45.txt`  — Kodiak Management Area announcement #45, EO 4-FS-K-45-26,
  released September 2, 2026. https://www.adfg.alaska.gov/static/applications/dcfnewsrelease/1833462759.pdf
* `SANDPT26.txt` — Alaska Peninsula Management Area announcement #26,
  released September 4, 2026. https://www.adfg.alaska.gov/static/applications/dcfnewsrelease/1834219457.pdf

They exist to lock the two GRAMMARS that missed these releases (ledger #110):

1. Kodiak's "There will be a <N>-hour commercial salmon fishing period ... in
   the following areas:" — the block finder required the literal word
   "extension", so two of #45's three periods matched nothing.
2. Area M's "Commercial salmon fishing by <gear> gear will be extended ... in
   the following districts and sections:" — the block finder required "will be
   allowed", so all three of #26's blocks matched nothing.

Both grammars are style variants of sentences the parser already handled. The
fixtures are therefore safe as GRAMMAR tests. They are NOT ground truth for
coordinates or for the app's own text extraction, and nothing in the shipped
dataset is built from them.
