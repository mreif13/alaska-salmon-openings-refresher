"""Self-test + coverage gate for Alaska Fishery Openings.

Mirrors the NSRAA tracker's discipline: the app can check itself. The gate that
matters most is the extractor's precision — a single wrong closure fails the
build. Runnable from the running engine (/api/selftest) or standalone
(python tests/test_all.py). Returns a JSON-able summary; exits non-zero on
failure when run standalone, so it can gate the Windows build.
"""
import os, sys, json, glob, re

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "engine"))
sys.path.insert(0, os.path.join(ROOT, "pipeline"))

MIN_RECALL = 0.95          # precision must be exactly 1.0; recall floor (achieved 0.995)


def _nums(x):
    return tuple(re.findall(r"\d+\.?\d*", x or ""))


def _keys(area_list):
    ks = set()
    for a in area_list or []:
        for r in a.get("rules", []):
            for pt in r.get("points", []):
                k = (_nums(pt.get("lat_dm")), _nums(pt.get("lon_dm")))
                if k[0] and k[1]:
                    ks.add((r.get("status"), k))
    return ks


def extractor_gate():
    import extract
    txtdir = os.path.join(HERE, "fixtures", "eo_text")
    rawdir = os.path.join(ROOT, "seeds", "raw")
    TP = FP = FN = 0; files = 0
    for tf in sorted(glob.glob(os.path.join(txtdir, "*.txt"))):
        rid = os.path.basename(tf)[:-4]
        rawp = os.path.join(rawdir, rid + ".json")
        if not os.path.exists(rawp):
            continue
        files += 1
        gt = json.load(open(rawp, encoding="utf-8"))
        ex = extract.parse(open(tf, encoding="utf-8").read(), rid)
        g = _keys(gt.get("areas")); e = _keys(ex.get("areas"))
        TP += len(g & e); FP += len(e - g); FN += len(g - e)
    prec = TP / (TP + FP) if TP + FP else 0.0
    rec = TP / (TP + FN) if TP + FN else 0.0
    ok = (files > 0 and FP == 0 and rec >= MIN_RECALL)
    return {"name": "extractor precision/recall", "ok": ok,
            "precision": round(prec, 3), "recall": round(rec, 3),
            "TP": TP, "FP": FP, "FN": FN, "files": files,
            "detail": f"precision={prec:.3f} (must be 1.000, FP={FP}) recall={rec:.3f} (floor {MIN_RECALL})"}


def areastatus_gate():
    """Lock the non-SE named-unit parser's precision against ground truth. Every
    unit the parser emits must carry the status the announcement actually states;
    a single wrong status fails the build (a wrong closure is the one thing this
    app must never show, for any area)."""
    import openparse
    fx = os.path.join(HERE, "fixtures", "nseo_text")
    # (region, {unit-name-lower: expected-status}) — verified by hand against the PDFs
    EXPECT = {
        # Copper is PARTIAL, not open: its body carries the grass-bank line
        # closure ("Waters north of this line ... are closed ... all periods") —
        # plain green would paint over closed delta water.
        "PWS43.txt": ("PWS", {
            "copper river district": "partial", "bering river district": "open",
            "eshamy district": "closed", "northern district": "partial",
            "cannery creek subdistrict": "partial"}),
        "KOD44.txt": ("Kodiak", {
            "cape alitak": "open", "alitak bay": "open", "moser bay": "open",
            "olga bay": "open", "outer karluk": "open", "central": "open",
            "north cape": "open", "inner uganik bay": "open",
            "southwest afognak": "open", "outer ayakulik": "open",
            "humpy-deadman": "open", "eastside kodiak district": "open",
            "northeast kodiak district": "open", "afognak district": "open",
            "duck bay": "closed", "izhut bay": "closed",
            "outer kitoi bay": "closed", "inner kitoi bay": "closed"}),
        # Situk-Ahrnklin & Seal open WITH stated restrictions -> partial;
        # Lost & Tsiu closed; the two districts open (the applier then downgrades
        # them to partial because the release closes waters the map can't place).
        "UCI34.txt": ("CookInlet", {"chinitna bay subdistrict": "open"}),
        "KOTZ.txt": ("AYK", {"kotzebue district": "open"}),
        "YAK.txt": ("Yakutat", {
            "east alsek river": "open", "alsek river": "open", "akwe river": "open",
            "dangerous river": "open", "yakutat bay": "open",
            "situk-ahrnklin inlet": "partial", "lost river": "closed",
            "manby shore-outside waters": "open", "manby shore-inside waters": "open",
            "remainder of the yakutat district": "open", "yakataga district": "open",
            "kaliakh river": "open", "tsiu river": "closed", "seal river": "partial"}),
    }
    wrong = []; checked = 0; miss = 0
    for fn, (region, exp) in EXPECT.items():
        p = os.path.join(fx, fn)
        if not os.path.exists(p):
            continue
        r = openparse.parse(open(p, encoding="utf-8").read(), fn[:-4])
        if r.get("region") != region:
            wrong.append(f"{fn}: region {r.get('region')} != {region}")
        got = {}
        for u in r.get("units", []):
            got[u["name"].strip().lower()] = u["status"]
        # every emitted unit that we have an expectation for must match (precision)
        for name, st in got.items():
            if name in exp:
                checked += 1
                if exp[name] != st:
                    wrong.append(f"{fn}: {name!r} parsed {st}, expected {exp[name]}")
        # every expected unit should be found (recall) — a miss is not fatal but counted
        for name in exp:
            if name not in got:
                miss += 1
    # A DISTRICT MAY NEVER BIND TO A SUBDISTRICT THAT SHARES ITS NAME
    # (ledger #114). Lower Cook Inlet's EASTERN DISTRICT was resolving to Upper
    # Cook Inlet's EASTERN SUBDISTRICT — a different fishery in different water,
    # and a closure painted there is a wrong closure.
    try:
        import areastatus as _as
        _rd = json.load(open(os.path.join(ROOT, "data", "regions_data.json"),
                             encoding="utf-8"))
        _blk = (_rd.get("regions") or {}).get("CookInlet")
        if _blk:
            _bn, _bd, _bc = _as._build_index("CookInlet", _blk)
            got = _as._map_unit({"name": "Eastern District", "kind": "district",
                                 "status": "closed"}, _bn, _bd, _bc)
            if got:
                wrong.append(f"'Eastern District' bound to {sorted(got)} — a "
                             f"district must never resolve to a subdistrict")
    except Exception as e:
        wrong.append(f"kind-collision check could not run: {e}")

    ok = (checked > 0 and not wrong)
    return {"name": "non-SE named-unit parser", "ok": ok,
            "checked": checked, "wrong": len(wrong), "recall_misses": miss,
            "detail": (f"{checked} units verified, 0 wrong" if ok
                       else "; ".join(wrong[:6]))}


def inventory_gate():
    """Unit-inventory completeness, checked against the REGULATIONS' own lists —
    not against whatever a GIS layer happened to contain. The Districts 2/4/5
    miss (client-caught, ledger #60) happened because the sections layer omits
    sectionless districts; this gate fails the build if any regulation-defined
    inventory item is absent from the shipped dataset."""
    import re as _re
    page = None
    for d in (os.path.join(ROOT, "data", "regions_data.json"),):
        if os.path.exists(d):
            page = json.load(open(d, encoding="utf-8"))
            break
    if page is None:
        html_p = os.path.join(ROOT, "seeds", "SE_Openings.html")
        if not os.path.exists(html_p):
            return {"name": "unit inventory vs regulations", "ok": False, "detail": "no dataset found"}
        txt = open(html_p, encoding="utf-8", errors="replace").read()
        m = _re.search(r"const DATA_ALL = (\{.*?\});", txt, _re.S)
        if not m:
            return {"name": "unit inventory vs regulations", "ok": False, "detail": "page has no dataset"}
        page = json.loads(m.group(1))
    probs = []
    R = page["regions"]
    # SE: 5 AAC 33.200 defines Districts 1-16 (+ Dixon Entrance in the service)
    se_d = {s.get("district_name") for s in R["SE"]["sections"].values()}
    for n in range(1, 17):
        if f"District {n}" not in se_d:
            probs.append(f"SE District {n} missing")
    # Federal troll water (Salmon FMP East Area, 50 CFR 679.2) — client-caught:
    # the EEZ east of Cape Suckling is open to troll under the same SE/Yakutat
    # announcements and must be on the map, troll-gear-scoped, with real
    # boundary lines (BOEM SLA inner / NOAA EEZ outer), never a fabricated fill
    fed = R["SE"]["sections"].get("Federal EEZ (East Area)")
    if not fed:
        probs.append("SE federal EEZ troll unit missing")
    else:
        if fed.get("gears") != ["troll"]:
            probs.append("SE federal unit not troll-scoped")
        if len(fed.get("lines") or []) < 100:
            probs.append("SE federal unit boundary lines missing")
        if fed.get("polys"):
            probs.append("SE federal unit must not carry a fabricated polygon")
    # Bristol Bay: 5 AAC 06.200 defines five districts
    bb_d = {s.get("district_name") for s in R["BristolBay"]["sections"].values()} | set(R["BristolBay"]["sections"])
    for n in ("Naknek-Kvichak District", "Egegik District", "Ugashik District",
              "Nushagak District", "Togiak District"):
        if n not in bb_d:
            probs.append(f"Bristol Bay {n} missing")
    # Kodiak: 5 AAC 18.200's seven districts, district-aware
    kd = {s.get("district_name") for s in R["Kodiak"]["sections"].values()}
    for n in ("Afognak District", "Alitak District", "Eastside Kodiak District",
              "Mainland District", "Northeast Kodiak District",
              "Northwest Kodiak District", "Southwest Kodiak District"):
        if n not in kd:
            probs.append(f"Kodiak {n} missing")
    # named units the current advisories require (PWS districts key by code,
    # so check names as well as keys)
    for area, unit in (("CookInlet", "Chinitna Bay Subdistrict"),
                       ("PWS", "Cannery Creek Subdistrict"),
                       ("PWS", "Eshamy District")):
        names = {s.get("name") for s in R[area]["sections"].values()}
        if unit not in R[area]["sections"] and unit not in names:
            probs.append(f"{area} {unit} missing")
    # the land backdrop must exist — a chart with no coast orients nobody
    if not page.get("land_ak"):
        probs.append("statewide land backdrop missing")
    ok = not probs
    return {"name": "unit inventory vs regulations", "ok": ok,
            "detail": ("SE 16+Dixon, BB 5, Kodiak 7 districts; advisory units; land present"
                       if ok else "; ".join(probs[:8]))}


def doctor_gate():
    """Corrupt-and-recover proof: damage every class of file the app depends on,
    run the doctor, and require a servable state back — quarantined evidence,
    restored page, re-derived datasets, and a crash loop that resets to seeds.
    If the app cannot heal these, the build does not ship."""
    import tempfile, shutil, json as _json
    import doctor
    seeds = os.path.join(ROOT, "seeds")
    page = os.path.join(seeds, "SE_Openings.html")
    if not os.path.exists(page):
        return {"name": "self-repair (doctor)", "ok": False, "detail": "seed page missing"}
    tmp = tempfile.mkdtemp()
    try:
        data = os.path.join(tmp, "data")
        os.makedirs(os.path.join(data, "raw")); os.makedirs(os.path.join(data, "areas"))
        # damage class 1: corrupt per-release records
        open(os.path.join(data, "raw", "111.json"), "w").write("{ not json")
        open(os.path.join(data, "areas", "222.json"), "w").write("\x00\x01garbage")
        # damage class 2: corrupt derived datasets + state
        open(os.path.join(data, "app_data.json"), "w").write("{{{{")
        open(os.path.join(data, "state.json"), "w").write("!!")
        # damage class 3: a rebuild that died mid-write (truncated page)
        with open(page, "rb") as f:
            half = f.read(os.path.getsize(page) // 2)
        with open(os.path.join(data, "SE_Openings.html"), "wb") as f:
            f.write(half)
        r = doctor.run(data, seeds, rebuild_fn=None, log=lambda *a: None)
        probs = []
        if not r["ok"]:
            probs.append("doctor reports not ok")
        if not doctor._page_ok(os.path.join(data, "SE_Openings.html")):
            probs.append("page not restored")
        for n in ("regions_data.json", "se_openings_data.json"):
            if not os.path.exists(os.path.join(data, n)):
                probs.append(n + " not re-derived")
        qdir = os.path.join(data, "quarantine")
        q = len(os.listdir(qdir)) if os.path.isdir(qdir) else 0
        if q < 3:
            probs.append(f"only {q} damaged files quarantined")
        if os.path.exists(os.path.join(data, "raw", "111.json")):
            probs.append("corrupt raw record left in place")
        try:
            _json.load(open(os.path.join(data, "state.json")))
        except Exception:
            probs.append("state.json not reset")
        # crash loop: 2 failed boots then the third resets from seeds
        data2 = os.path.join(tmp, "data2"); os.makedirs(data2)
        open(os.path.join(data2, "SE_Openings.html"), "w").write("dead")
        _json.dump({"attempts": 2}, open(os.path.join(data2, doctor.BOOT_FILE), "w"))
        note = doctor.boot_check(data2, seeds, log=lambda *a: None)
        if not note:
            probs.append("crash loop not detected at threshold")
        if not doctor._page_ok(os.path.join(data2, "SE_Openings.html")):
            probs.append("crash-loop reset did not restore the page")
        ok = not probs
        return {"name": "self-repair (doctor)", "ok": ok,
                "repairs": len(r["findings"]),
                "detail": (f"recovered from {q} quarantined damages + crash loop; "
                           f"{len(r['findings'])} repairs" if ok else "; ".join(probs))}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def scheduler_gate():
    import scheduler, datetime as dt
    now = dt.datetime(2026, 8, 23, 12, 0)
    rel = []
    try:
        rel = json.load(open(os.path.join(ROOT, "data", "app_data.json"), encoding="utf-8")).get("releases", [])
    except Exception:
        try:
            rel = json.load(open(os.path.join(ROOT, "seeds", "app_data.json"), encoding="utf-8")).get("releases", [])
        except Exception:
            rel = []
    ts = scheduler.next_poll_times(rel, now=now) if rel else []
    ok = bool(ts) and all(t > now for t in ts) and (ts[0] - now) <= dt.timedelta(hours=24)
    return {"name": "anticipatory scheduler", "ok": ok,
            "detail": f"{len(ts)} upcoming polls; first at {ts[0] if ts else 'n/a'}"}


def fetch_gate():
    import fetch_detect
    sample = ('dcfnewsrelease/1766166725.pdf index.cfm?adfg=cfnews.detail&id=1766843682 '
              '<guid>...cfnewsrelease.1767031834</guid> dcfnewsrelease/1766166725.pdf')
    ids = fetch_detect.list_release_ids(sample)
    ok = ids == ["1766166725", "1766843682", "1767031834"]
    return {"name": "fetch/detect id parsing", "ok": ok, "detail": f"parsed {ids}"}


def data_gate():
    for d in (os.path.join(ROOT, "data", "SE_Openings.html"), os.path.join(ROOT, "seeds", "SE_Openings.html")):
        if os.path.exists(d) and os.path.getsize(d) > 1_000_000:
            return {"name": "built map present", "ok": True,
                    "detail": f"{os.path.basename(os.path.dirname(d))}/SE_Openings.html {round(os.path.getsize(d)/1024/1024,2)} MB"}
    return {"name": "built map present", "ok": False, "detail": "SE_Openings.html missing or too small"}


def partial_floor_gate():
    """REGRESSION FLOOR (client-caught, ledger #62): once Southeast shipped
    'exactly where' partials — the dividing line drawn from the EO's own
    coordinates, or failing that the announcement's own words — that standard
    became a floor for EVERY area wearing the label 'partial'. A partial that
    tells a captain nothing about WHERE is a regression, and the build fails.
    Rule: every rec with status 'partial' (and every rec carrying drawable
    rules) must have (a) at least one rule with >=2 pts, or (b) the closure's
    words — a non-empty period_text or a text-bearing rule."""
    import re as _re
    page = None
    p = os.path.join(ROOT, "data", "regions_data.json")
    if os.path.exists(p):
        page = json.load(open(p, encoding="utf-8"))
    else:
        html_p = os.path.join(ROOT, "seeds", "SE_Openings.html")
        if os.path.exists(html_p):
            txt = open(html_p, encoding="utf-8", errors="replace").read()
            m = _re.search(r"const DATA_ALL = (\{.*?\});", txt, _re.S)
            if m:
                page = json.loads(m.group(1))
    if page is None:
        return {"name": "partial 'exactly where' floor", "ok": False, "detail": "no dataset found"}
    bad = []
    n_partial = 0
    for rk, R in (page.get("regions") or {}).items():
        for gear, recs in (R.get("status") or {}).items():
            for code, rec in (recs or {}).items():
                if not isinstance(rec, dict) or rec.get("status") != "partial":
                    continue
                n_partial += 1
                rules = rec.get("rules") or []
                drawable = any(len(r.get("pts") or []) >= 2 for r in rules)
                worded = bool((rec.get("period_text") or "").strip()) or \
                    any((r.get("text") or "").strip() for r in rules)
                if not (drawable or worded):
                    bad.append(f"{rk}/{gear}/{code}")
    ok = not bad and n_partial > 0
    return {"name": "partial 'exactly where' floor", "ok": ok,
            "detail": (f"{n_partial} partial recs all carry a drawn line or the announcement's words"
                       if ok else (f"{len(bad)} partial recs with NO where: {bad[:6]}" if bad
                                   else "no partial recs found — floor unverifiable"))}


def stale_status_gate():
    """GATE 11 — THE CLOCK IS THE AUTHORITY (client-caught, ledger #74;
    axiom 30). 9-B displayed 'Some waters open until Sun, Aug 23, 9:00 PM' a
    week after that window ended, because the expired->closed conversion keyed
    on a LABEL (time_state=='expired') and records labeled 'superseded' with
    equally-dead windows sailed through. Rule, enforced on the dataset the
    page will actually serve: NO rec may display open/partial/upcoming when
    its own window is behind the build clock —
      - open/partial with ends  < as_of  -> a wrong opening, build FAILS;
      - upcoming     with starts < as_of and no future window text -> stale.
    The comparison is the timestamps themselves; a state label is never
    trusted over the clock."""
    import re as _re
    page = None
    p = os.path.join(ROOT, "data", "regions_data.json")
    if os.path.exists(p):
        page = json.load(open(p, encoding="utf-8"))
    else:
        html_p = os.path.join(ROOT, "seeds", "SE_Openings.html")
        if os.path.exists(html_p):
            txt = open(html_p, encoding="utf-8", errors="replace").read()
            m = _re.search(r"const DATA_ALL = (\{.*?\});", txt, _re.S)
            if m:
                page = json.loads(m.group(1))
    if page is None:
        return {"name": "no stale windows displayed (clock gate)", "ok": False,
                "detail": "no dataset found"}
    # the build clock: the dataset's own as_of (regions carry it; fall back to
    # the newest as_of found) — never wall-time here, so the gate is
    # deterministic against the artifact it checks
    as_of = None
    for R in (page.get("regions") or {}).values():
        a = R.get("as_of")
        if a and (as_of is None or a > as_of):
            as_of = a
    if not as_of:
        return {"name": "no stale windows displayed (clock gate)", "ok": False,
                "detail": "dataset carries no as_of clock"}
    bad = []
    n = 0
    for rk, R in (page.get("regions") or {}).items():
        for gear, recs in (R.get("status") or {}).items():
            for code, rec in (recs or {}).items():
                if not isinstance(rec, dict):
                    continue
                n += 1
                st = rec.get("status")
                ends = rec.get("ends") or ""
                starts = rec.get("starts") or ""
                if st in ("open", "partial") and ends and str(ends) < str(as_of):
                    bad.append(f"{rk}/{gear}/{code} {st} ended {ends}")
                elif st == "upcoming" and starts and str(starts) < str(as_of) and \
                        not (ends and str(ends) >= str(as_of)):
                    bad.append(f"{rk}/{gear}/{code} upcoming but started {starts}")
    ok = not bad and n > 0
    return {"name": "no stale windows displayed (clock gate)", "ok": ok,
            "detail": (f"{n} recs checked against as_of {as_of}: every displayed "
                       f"open/partial/upcoming window is current"
                       if ok else f"{len(bad)} STALE displayed statuses: {bad[:6]}")}


def feature_floor_gate():
    """THE FEATURE FLOOR (client-demanded, ledger #65): every capability that
    ever shipped is registered in feature_registry.json with markers that must
    exist in the built page. A rebuild, refactor, or new feature that silently
    drops a shipped behavior fails the build — on the developer's machine AND
    on the client's, since the runtime rebuild chain regenerates the page and
    this gate runs against whatever page will actually be served. Features are
    retired only by editing the registry deliberately, never by accident."""
    reg_p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "feature_registry.json")
    if not os.path.exists(reg_p):
        return {"name": "feature floor (registry)", "ok": False, "detail": "feature_registry.json missing"}
    try:
        reg = json.load(open(reg_p, encoding="utf-8"))["features"]
    except Exception as e:
        return {"name": "feature floor (registry)", "ok": False, "detail": f"registry unreadable: {e}"}
    page = None
    for d in (os.path.join(ROOT, "data", "SE_Openings.html"),
              os.path.join(ROOT, "seeds", "SE_Openings.html")):
        if os.path.exists(d) and os.path.getsize(d) > 1_000_000:
            page = open(d, encoding="utf-8", errors="replace").read()
            src = os.path.basename(os.path.dirname(d))
            break
    if page is None:
        return {"name": "feature floor (registry)", "ok": False, "detail": "no built page to check"}
    lost = []
    for feat, markers in reg.items():
        missing = [m for m in markers if m not in page]
        if missing:
            lost.append(f"{feat} (missing {missing})")
    ok = not lost
    return {"name": "feature floor (registry)", "ok": ok,
            "detail": (f"{len(reg)} shipped features verified present in {src} page"
                       if ok else f"{len(lost)} SHIPPED FEATURES LOST: {lost[:4]}")}


def freshness_gate():
    """ANNOUNCEMENT FRESHNESS (client-caught, ledger #69: a snapshot shipped
    built from 6 of ADF&G's 33 listed releases and was called done). The build
    carries a listing snapshot (seeds/listing_snapshot.json — the FULL id list
    ADF&G's announcement page showed at build time) and an ingest manifest
    (seeds/ingest_manifest.json — every id ever examined, with its disposition:
    ingested-<region>, skipped-non-salmon, skipped-no-region). This gate fails
    the build if ANY listed id has no disposition — an announcement can be
    skipped only for a recorded reason, never by not having been looked at.
    Delivery discipline: the listing snapshot is re-pulled from ADF&G before
    every ship; a stale snapshot cannot claim completeness for a fresh day, so
    the gate also fails when the snapshot is older than 7 days (the runtime
    app refreshes itself daily on the client's machine — this floor is for
    SHIPPED SNAPSHOTS: seeds, the hosted page)."""
    sd = os.path.join(ROOT, "seeds")
    lp, mp = os.path.join(sd, "listing_snapshot.json"), os.path.join(sd, "ingest_manifest.json")
    if not os.path.exists(lp) or not os.path.exists(mp):
        return {"name": "announcement freshness (listing vs manifest)", "ok": False,
                "detail": "listing snapshot or ingest manifest missing"}
    try:
        snap = json.load(open(lp, encoding="utf-8"))
        man = json.load(open(mp, encoding="utf-8"))
    except Exception as e:
        return {"name": "announcement freshness (listing vs manifest)", "ok": False,
                "detail": f"unreadable: {e}"}
    unexamined = [i for i in snap.get("ids", []) if i not in man]
    import datetime as _dt
    age_days = None
    try:
        age_days = (_dt.datetime.now() - _dt.datetime.fromisoformat(snap["pulled_at"])).days
    except Exception:
        pass
    stale = age_days is not None and age_days > 7
    ok = not unexamined and not stale
    return {"name": "announcement freshness (listing vs manifest)", "ok": ok,
            "detail": (f"all {len(snap.get('ids', []))} listed releases have a recorded disposition; "
                       f"listing pulled {age_days}d ago" if ok else
                       (f"{len(unexamined)} listed releases NEVER EXAMINED: {unexamined[:5]}" if unexamined
                        else f"listing snapshot is {age_days} days old — re-pull before shipping"))}


def publisher_gate():
    """GATE 12 — the phone page is an extension of the refresh (ledger #79),
    and a published DOWNLOAD survives every later deploy (ledger #103).

    Round-trips engine/publisher.py against a local mock of Netlify's digest
    deploy API. The zip deploy this replaced silently DELETED any file it did
    not itself contain, so an installer published from the desktop was wiped by
    the next cloud refresh two hours later. This gate proves four things: the
    site resolves by name; the exact built page is uploaded as index.html; a
    file already on the site is carried into the new deploy WITHOUT being
    re-uploaded; and the token never appears in status().
    """
    import http.server, socketserver, threading, tempfile, hashlib as _h, zipfile, io as _io
    sys.path.insert(0, os.path.join(ROOT, "engine"))
    import publisher as pub
    page = os.path.join(ROOT, "data", "SE_Openings.html")
    if not os.path.exists(page):
        page = os.path.join(ROOT, "seeds", "SE_Openings.html")
    page_bytes = open(page, "rb").read()
    page_sha = _h.sha1(page_bytes).hexdigest()
    # a download already published, which no later deploy may drop
    EXISTING = {"/downloads/NSRAA-Return-Tracker-Setup-latest.exe": "a" * 40}
    got = {"uploads": {}, "manifest": None, "auth": None}

    class Mock(http.server.BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _json(self, obj):
            b = json.dumps(obj).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(b)))
            self.end_headers()
            self.wfile.write(b)

        def do_GET(self):
            if self.path.endswith("/files"):
                self._json([{"id": p, "sha": s_} for p, s_ in EXISTING.items()])
            elif self.path.startswith("/api/v1/sites"):
                self._json([{"id": "site-123", "name": "alaska-salmon-openings",
                             "ssl_url": "https://alaska-salmon-openings.netlify.app"}])

        def do_POST(self):
            n = int(self.headers.get("Content-Length") or 0)
            got["manifest"] = json.loads(self.rfile.read(n) or b"{}").get("files", {})
            got["auth"] = self.headers.get("Authorization")
            # everything the site does not already hold must be uploaded
            required = [sha for p, sha in got["manifest"].items() if sha not in EXISTING.values()]
            self._json({"id": "dep-1", "state": "uploaded", "required": required,
                        "ssl_url": "https://alaska-salmon-openings.netlify.app"})

        def do_PUT(self):
            n = int(self.headers.get("Content-Length") or 0)
            body = self.rfile.read(n)
            got["uploads"][self.path.split("/files", 1)[1]] = body
            self._json({"ok": True})

    srv = socketserver.TCPServer(("127.0.0.1", 0), Mock)
    port = srv.server_address[1]
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    old_api = pub.API
    pub.API = f"http://127.0.0.1:{port}/api/v1"
    try:
        with tempfile.TemporaryDirectory() as td:
            st = pub.configure(td, "TESTTOKEN-abc", "alaska-salmon-openings.netlify.app")
            ok_cfg = st["configured"] and st["enabled"] and st["site_name"] == "alaska-salmon-openings"
            # a local extra file must ship too
            os.makedirs(os.path.join(td, "publish_extra", "downloads"), exist_ok=True)
            with open(os.path.join(td, "publish_extra", "downloads", "note.txt"), "wb") as f:
                f.write(b"hello")
            r1 = pub.maybe_publish(td, page, log=lambda *a: None)
            man = got["manifest"] or {}
            ok_page = man.get("/index.html") == page_sha and \
                got["uploads"].get("/index.html") == page_bytes
            ok_extra = "/downloads/note.txt" in man and \
                got["uploads"].get("/downloads/note.txt") == b"hello"
            # THE POINT OF THE REWRITE: already-published files are carried, unsent
            carried = list(EXISTING)[0]
            ok_carry = man.get(carried) == EXISTING[carried] and carried not in got["uploads"]
            try:
                inner = zipfile.ZipFile(_io.BytesIO(got["uploads"].get("/app-src.zip", b"")))
                ok_src = "app.py" in inner.namelist() and \
                    any(n.startswith("engine/") for n in inner.namelist()) and \
                    any(n.startswith("seeds/") for n in inner.namelist())
            except Exception:
                ok_src = False
            ok_auth = got.get("auth") == "Bearer TESTTOKEN-abc"
            r2 = pub.maybe_publish(td, page, log=lambda *a: None)
            ok_skip = (not r2["published"]) and r2["reason"] == "page unchanged"
            leak = "TESTTOKEN" in json.dumps(pub.status(td))
            ok = all([ok_cfg, r1.get("published"), ok_page, ok_extra, ok_carry,
                      ok_src, ok_auth, ok_skip, not leak])
            detail = (f"site resolves; page uploaded byte-exact ({len(page_bytes)//1024} KB); "
                      f"publish_extra shipped; a published download carried forward WITHOUT "
                      f"re-upload; unchanged page skipped; token never in status"
                      if ok else
                      f"cfg={ok_cfg} pub={r1} page={ok_page} extra={ok_extra} carry={ok_carry} "
                      f"src={ok_src} auth={ok_auth} skip={ok_skip} leak={leak}")
    finally:
        pub.API = old_api
        srv.shutdown()
    return {"name": "auto-publish round-trip + published downloads survive (ledger #103)",
            "ok": ok, "detail": detail}


def announcement_text_gate():
    """GATE 13 (ledger #89) — THE CAPTAIN'S RIGHT TO THE WHOLE ANNOUNCEMENT.

    Section 15-C's sheet once promised "with the following restriction:" and
    then said nothing, because the restriction had been filed under an
    unattributed bucket by an attribution the parser got wrong. The remedy is
    that the announcement's complete body rides with every release, so the
    parse decides only what is DRAWN. This gate holds the machinery that
    carries those words: the body extractor, and the per-release map the page
    reads. Deterministic and offline — it never needs a network or a PDF.
    """
    sys.path.insert(0, os.path.join(ROOT, "engine"))
    from extract import _body_text
    raw = ("ALASKA DEPARTMENT OF FISH AND GAME\n"
           "Division of Commercial Fisheries\n"
           "P.O. BOX 240020\n"
           "Page 1 of 2\n"
           "\n"
           "Section 15-C will be open from 12:01 p.m., Sunday, August 30,\n"
           "through 12:00 noon, Wednesday, September 2, 2026, with the follow-\n"
           "ing restriction:\n"
           "\n"
           "The Boat Harbor THA will close for the season at 11:59 p.m.,\n"
           "Saturday, August 29, 2026, west of 135\u00b009.57\u2032 W long.\n"
           "www.adfg.alaska.gov\n")
    body = _body_text(raw)
    problems = []
    if not body:
        problems.append("no body extracted")
    else:
        if "P.O. BOX" in body or "Page 1 of 2" in body or "www." in body:
            problems.append("page furniture survived into the captain's text")
        # THE WHOLE POINT: the restriction that follows the colon must be there
        if "Boat Harbor THA will close for the season" not in body:
            problems.append("the restriction after the colon was lost")
        if "following restriction" not in body:
            problems.append("line-break hyphen not rejoined ('follow-\ning')")
        if body.count("\n\n") < 1:
            problems.append("paragraph breaks lost")
    # the release -> announcements map the page reads, keyed by id, text intact
    rels = [{"id": "111", "title": "T", "published": "2026-08-27T00:00",
             "emergency_order": "1S7026", "url": "u", "full_text": body},
            {"id": "222", "full_text": None}]
    amap = {r["id"]: {"title": r.get("title"), "published": r.get("published"),
                      "eo": r.get("emergency_order"), "url": r.get("url"),
                      "text": r.get("full_text")}
            for r in rels if r.get("id") and r.get("full_text")}
    if list(amap) != ["111"]:
        problems.append(f"announcements map keys wrong: {list(amap)}")
    elif amap["111"]["text"] != body:
        problems.append("announcement text altered in the map")
    # and the backfill that tops up records ingested before full_text existed
    try:
        import fetch_detect
        if not callable(getattr(fetch_detect, "backfill_full_text", None)):
            problems.append("backfill_full_text missing")
    except Exception as e:
        problems.append(f"fetch_detect import failed: {e}")
    return {"name": "the announcement's complete words (extract -> map -> page)",
            "ok": not problems,
            "detail": ("body kept its restriction, furniture stripped, hyphens "
                       f"rejoined; map keyed by release ({len(body)} chars)"
                       if not problems else "; ".join(problems))}


def page_engine_gate():
    """GATE 14 (axiom 33, ledger #85/#96) — THE PAGE SAYS WHICH ENGINE BUILT IT.

    The installer preserves data/, and a rebuild only fires when new
    announcements arrive, so for four releases a freshly upgraded app SERVED
    AND PUBLISHED its predecessor's page while /api/state honestly reported the
    new engine version. Engine and page are two different facts; the page now
    carries its own, the app reconciles them at boot, and this gate refuses any
    build whose page does not say — correctly — who built it.
    """
    name = "page carries its engine version (axiom 33)"
    page = os.path.join(ROOT, "data", "SE_Openings.html")
    try:
        with open(page, encoding="utf-8") as f:
            # the meta stamp is in the first few KB; the visible chip sits after
            # the stylesheet, so the markup slice has to reach past it (the data
            # blob is far below either)
            head = f.read(400_000)
    except Exception as e:
        return {"name": name, "ok": False, "detail": f"page unreadable: {e}"}
    m = re.search(r'<meta name="afo-engine" content="([^"]*)"', head[:8192])
    if not m:
        return {"name": name, "ok": False,
                "detail": "the built page carries no afo-engine stamp"}
    stamped = m.group(1)
    # the engine that SHOULD have built it
    want = None
    try:
        with open(os.path.join(ROOT, "app.py"), encoding="utf-8") as f:
            for line in f:
                t = line.strip()
                if t.startswith("VERSION") and "=" in t and '"' in t:
                    want = t.split('"')[1]
                    break
    except Exception as e:
        return {"name": name, "ok": False, "detail": f"app.py unreadable: {e}"}
    # the stamp is "<version>+<generator hash>" (ledger #107): the version must
    # match, and the hash must be the one THIS generator produces
    stamped_ver = stamped.split("+")[0]
    if stamped_ver != want:
        return {"name": name, "ok": False,
                "detail": f"page was built by engine {stamped!r} but this app is {want!r} "
                          f"— the served and published page is a version behind"}
    try:
        import hashlib
        h = hashlib.sha256()
        for fn in sorted(("build_app.py", "restatus.py", "areastatus.py", "timemodel.py")):
            fp = os.path.join(ROOT, "pipeline", fn)
            if os.path.exists(fp):
                with open(fp, "rb") as f:
                    h.update(f.read())
        expect = want + "+" + h.hexdigest()[:8]
        if stamped != expect:
            return {"name": name, "ok": False,
                    "detail": f"page stamp {stamped!r} was produced by a DIFFERENT generator than "
                              f"the one in this tree ({expect!r}) — same version, different code"}
    except Exception:
        pass
    # and the reader can SEE it: the chip must render the same number
    if f'>v{stamped}<' not in head and f'>v{stamped}' not in head:
        return {"name": name, "ok": False,
                "detail": f"the page stamps {stamped} but shows no visible version chip"}
    return {"name": name, "ok": True,
            "detail": f"page stamped and displayed as engine {stamped}; app.py agrees"}


def future_open_gate():
    """GATE 15 (axiom 36, ledger #105) — AN OPENING THAT HAS NOT STARTED IS NOT OPEN.

    A gillnetter was shown a Southeast section open for gillnetting two days
    before it opened. Gate 11 had guarded the far end of the window
    (ends < as_of -> closed) because that was the sighting that prompted it;
    nothing guarded the near end, so an EO published on the 3rd for a fishery
    opening on the 6th was stored "open" and painted green on the 4th. Six
    sections were live-wrong on the public page when this was caught.

    Rule, on the dataset the page will serve: no rec may display open or
    partial while its own start is AHEAD of the build clock. Both ends of every
    window, keyed on timestamps, never on a state label."""
    name = "no unstarted opening displayed (clock gate, both ends)"
    import json as _json
    path = os.path.join(ROOT, "data", "regions_data.json")
    if not os.path.exists(path):
        return {"name": name, "ok": False, "detail": "regions_data.json missing"}
    d = _json.load(open(path, encoding="utf-8"))
    as_of = str(d.get("as_of") or "")
    bad, checked = [], 0
    for akey, R in (d.get("regions") or {}).items():
        for g, m in (R.get("status") or {}).items():
            for code, r in (m or {}).items():
                if not isinstance(r, dict):
                    continue
                st = r.get("status")
                if st not in ("open", "partial"):
                    continue
                checked += 1
                starts = str(r.get("starts") or "")
                if starts and as_of and starts > as_of:
                    bad.append(f"{akey}/{g}/{code} shown {st} but starts {starts} (as_of {as_of})")
                # A WEEKLY FISHERY MUST CARRY ITS RECURRENCE (ledger #108).
                # Chinitna Bay read OPEN a minute after its Friday period closed
                # because the record had no window AND no pattern, so nothing
                # could re-check it at read time. An open/partial with neither a
                # window nor a weekly spec is a claim the page can never verify.
                per = (r.get("period_text") or "").lower()
                weekly_words = ("each week" in per or "weekly" in per
                                or any(d in per for d in ("mondays", "tuesdays", "wednesdays",
                                                          "thursdays", "fridays", "saturdays",
                                                          "sundays")))
                if weekly_words and not r.get("weekly"):
                    bad.append(f"{akey}/{g}/{code} shown {st} on a recurring schedule "
                               f"but carries no weekly pattern for the page to re-check")
    if bad:
        return {"name": name, "ok": False,
                "detail": f"{len(bad)} unstarted opening(s) displayed as open: " + "; ".join(bad[:6])}
    return {"name": name, "ok": True,
            "detail": f"{checked} open/partial recs checked against as_of {as_of}; every window has already started"}


def disposition_gate():
    """GATE 16 (axiom 37, ledger #109) — NOTHING THE AUTHORITY PUBLISHED IS DROPPED IN SILENCE.

    Four current salmon announcements — Lower Cook Inlet, Sand Point #26,
    Kodiak #45 and a Norton Sound closure — sat outside the app for days while
    every gate passed, because the ingest loop `continue`d past anything it
    could not use and kept no record. An unreadable PDF and a sea-cucumber
    notice were indistinguishable.

    Rule: every release the cycle looked at ends with an explicit disposition,
    and anything salmon-related that did not make it must be SURFACED on the
    page (never merely logged)."""
    name = "every announcement has a disposition; unread ones are surfaced"
    import json as _json
    led = os.path.join(ROOT, "data", "dispositions.json")
    if not os.path.exists(led):
        return {"name": name, "ok": True,
                "detail": "SKIPPED — no disposition ledger yet (written on the next refresh)"}
    d = _json.load(open(led, encoding="utf-8"))
    rel = d.get("releases") or {}
    if not rel:
        return {"name": name, "ok": True, "detail": "SKIPPED — ledger empty"}
    blank = [r for r, v in rel.items() if not (v or {}).get("disposition")]
    if blank:
        return {"name": name, "ok": False,
                "detail": f"{len(blank)} release(s) with no disposition recorded: {blank[:5]}"}
    # "no-units" IS AN UNREAD ANNOUNCEMENT (axiom 38, ledger #110). A release
    # we opened, read and placed NOTHING from is, to the captain, exactly as
    # absent from the chart as one we could not open — Kodiak #45 and Sand
    # Point #26 each announced live openings, each parsed to zero units, and
    # each was recorded "ingested" while this gate passed.
    needs = [r for r, v in rel.items()
             if (v or {}).get("disposition") in ("unreadable", "unplaceable",
                                                 "error", "no-units")]
    page = os.path.join(ROOT, "data", "SE_Openings.html")
    if needs and os.path.exists(page):
        with open(page, encoding="utf-8") as f:
            head = f.read(400_000)
        missing = [r for r in needs if r not in head]
        if missing:
            return {"name": name, "ok": False,
                    "detail": f"{len(missing)} unread/unplaceable announcement(s) not surfaced "
                              f"on the page: {missing[:5]}"}
    counts = {}
    for v in rel.values():
        k = (v or {}).get("disposition")
        counts[k] = counts.get(k, 0) + 1
    return {"name": name, "ok": True,
            "detail": f"{len(rel)} releases, all with a disposition {counts}; "
                      f"{len(needs)} needing a captain's attention are named on the page"}


def zero_yield_gate():
    """GATE 17 (axiom 38, ledger #110) — A PARSE THAT PLACES NOTHING IS A MISS,
    NOT A SUCCESS.

    The ingest loop used to declare a release "ingested" on the strength of a
    file being written, so an announcement that parsed to ZERO units counted as
    handled while nothing about it ever reached the chart. Two live openings —
    Kodiak #45's three fishing periods and Sand Point #26's three extensions —
    sat off the map with a green tick beside them.

    This gate proves the classification structurally (the loop cannot be run
    offline here without the network), and proves the two grammars that missed
    them now place their units."""
    name = "a release that places nothing is recorded no-units and surfaced"
    src = open(os.path.join(ROOT, "engine", "fetch_detect.py"), encoding="utf-8").read()
    problems = []
    # checked by MEANING, not by a literal that drifts: both paths must decide
    # a zero yield, classify WHY it was zero (ledger #113), and record it
    if src.count('why = openparse.classify_zero_yield(text)') < 2:
        problems.append("the ingest loop does not classify a zero yield on BOTH "
                        "the SE and non-SE paths")
    if src.count('"disposition": why or "no-units"') < 2:
        problems.append("a zero yield is not recorded on both paths")
    if 'if not rec.get("units"):' not in src:
        problems.append("no zero-unit test on the non-SE path")
    if 'if not _placed:' not in src or '_placed = any(' not in src:
        problems.append("no placed-nothing test on the SE path")
    if 'a.get("region_wide")' not in src or 'a.get("tha_pocket")' not in src:
        problems.append("the SE placed-nothing test still asks about coordinates "
                        "instead of placements (ledger #112)")
    bapp = open(os.path.join(ROOT, "pipeline", "build_app.py"), encoding="utf-8").read()
    if '"no-units"' not in bapp:
        problems.append("build_app does not surface no-units in the unread banner")

    # the two grammars, proved on the announcements that defeated them
    sys.path.insert(0, os.path.join(ROOT, "engine"))
    import openparse
    fx = os.path.join(HERE, "fixtures", "nseo_recon")
    cases = [("KOD45.txt", 20, {"izhut bay": "closed", "outer kitoi bay": "closed",
                                "inner kitoi bay": "closed", "uyak bay": "open",
                                "sharatin bay": "open", "outer karluk": "open",
                                "eastside kodiak district": "open",
                                "afognak district": "open"}),
              ("SANDPT26.txt", 10, {"unimak district": "open",
                                    "south central district": "open",
                                    "shumagin islands": "open",
                                    "east stepovak": "open",
                                    "ikatan bay": "open"})]
    # THE APP'S OWN EXTRACTION OUTRANKS A TRANSCRIPTION (ledger #115). The
    # Kodiak grammar was "fixed" against a transcribed fixture with no bullet
    # dashes, verified, shipped, and placed nothing on the client's machine,
    # whose real text reads "areas:\n\n- - -\n\nThe Outer Karluk Section".
    # This fixture is that record, byte-for-byte, off his computer.
    live = os.path.join(HERE, "fixtures", "nseo_live", "KOD45_live.txt")
    if os.path.exists(live):
        cases.append(("KOD45_live.txt", 20, {"outer karluk": "open", "sharatin bay": "open",
                                             "izhut bay": "closed", "afognak district": "open"}))
    detail = []
    for fn, floor, expect in cases:
        path = os.path.join(fx, fn) if not fn.endswith("_live.txt") else live
        if not os.path.exists(path):
            problems.append(f"missing fixture {fn}")
            continue
        r = openparse.parse(open(path, encoding="utf-8").read(), fn[:-4])
        got = {u["name"].lower(): u["status"] for u in r["units"]}
        if len(r["units"]) < floor:
            problems.append(f"{fn}: {len(r['units'])} units, expected at least {floor}")
        for k, v in expect.items():
            if got.get(k) != v:
                problems.append(f"{fn}: {k!r} is {got.get(k)!r}, expected {v!r}")
        detail.append(f"{fn}={len(r['units'])} units")
    # AN OPEN END IS NOT AN OPEN START (ledger #110). "extended from 9:00 p.m.
    # Sunday, September 6 until further notice", published September 4, must
    # start on the 6th — dating it to the publication day painted four Area M
    # districts open two days early.
    sys.path.insert(0, os.path.join(ROOT, "pipeline"))
    import timemodel
    st, en, conf = timemodel.parse_period(
        "purse seine and set gillnet gear allowed from 9:00 p.m. Sunday, "
        "September 6 until further notice", 2026, "2026-09-04T00:00")
    if st != "2026-09-06T21:00:00" or en is not None:
        problems.append(f"until-further-notice start is {st!r}/{en!r}, expected the stated 9 p.m. Sept 6 instant")
    if problems:
        return {"name": name, "ok": False, "detail": "; ".join(problems[:6])}
    return {"name": name, "ok": True,
            "detail": "zero-yield is classified no-units on both paths and surfaced; "
                      "an open-ended window still starts when the announcement says; "
                      + ", ".join(detail)}


def claimcheck_gate():
    """GATE 18 (axiom 39, ledger #111) — THE CLAIM CHECKER IS PRESENT AND WORKS.

    Ledger #110 was not a code defect. It was me stating a MECHANISM I had not
    verified, about artifacts that were on disk and said otherwise. Axioms 27
    and 35 already forbade it and did not stop it, because an axiom is a promise
    and this needs a machine. `tools/claimcheck.py` is that machine: it turns a
    draft sentence into resolvable claims, settles them against the artifacts,
    and refuses the ones the artifacts contradict.

    This gate exists so the checker cannot quietly rot or go missing — it runs
    the checker's own self-test, which is itself pinned to the exact false
    sentence that was sent to the client."""
    name = "the claim checker is present and refutes the sentence that was sent"
    p = os.path.join(ROOT, "tools", "claimcheck.py")
    if not os.path.exists(p):
        return {"name": name, "ok": False, "detail": "tools/claimcheck.py is missing"}
    import subprocess
    try:
        r = subprocess.run([sys.executable, p, "--selftest"],
                           capture_output=True, text=True, timeout=180, cwd=ROOT)
    except Exception as e:
        return {"name": name, "ok": False, "detail": f"could not run it: {e}"}
    out = (r.stdout or "") + (r.stderr or "")
    if r.returncode != 0 or "SELFTEST PASS" not in out:
        first = [l for l in out.splitlines() if "FAIL" in l][:3]
        return {"name": name, "ok": False,
                "detail": "claimcheck self-test FAILED: " + ("; ".join(first) or out[-200:])}
    # and it must be reachable the way it is actually used
    r2 = subprocess.run([sys.executable, p, "--say",
                         "Release 1833462759 is not in the app at all."],
                        capture_output=True, text=True, timeout=120, cwd=ROOT)
    if "absent:release:1833462759" not in (r2.stdout or ""):
        return {"name": name, "ok": False,
                "detail": "the extractor did not turn a plain absence sentence "
                          "into a checkable claim"}
    return {"name": name, "ok": True,
            "detail": "self-test passes (it refutes the real false sentence, "
                      "refuses to confirm an absence from an empty search, and "
                      "refuses a mechanism claim with no reproduction)"}


def selfaudit_gate():
    """GATE 19 (ledger #112) — THE APP CHECKS ITSELF, WITHOUT ME.

    The client: *"you need to run this synergistically and independently of me.
    the app should have this self checker and repairer on hand."* Eighteen
    gates guard this build; none of them run on a fisherman's machine at 3 a.m.
    when a two-hourly rebuild starts telling him something untrue.

    `engine/selfaudit.py` is that check made autonomous: six contradictions
    between what the app SAYS and what it HOLDS, repaired where a repair
    exists, surfaced on the page where none does. This gate runs its self-test
    (which is pinned to the #110 shape — a release held, perfect, and placed
    nowhere) and proves the wiring: refresh, boot, /api/health and the page all
    carry it."""
    name = "the app audits and repairs its own contradictions, unattended"
    import subprocess
    p = os.path.join(ROOT, "engine", "selfaudit.py")
    if not os.path.exists(p):
        return {"name": name, "ok": False, "detail": "engine/selfaudit.py is missing"}
    try:
        r = subprocess.run([sys.executable, p], capture_output=True, text=True,
                           timeout=180, cwd=os.path.join(ROOT, "engine"))
    except Exception as e:
        return {"name": name, "ok": False, "detail": f"could not run it: {e}"}
    out = (r.stdout or "") + (r.stderr or "")
    if r.returncode != 0 or "SELFTEST PASS" not in out:
        bad = [l.strip() for l in out.splitlines() if "FAIL" in l][:3]
        return {"name": name, "ok": False,
                "detail": "selfaudit self-test FAILED: " + ("; ".join(bad) or out[-200:])}
    # WIRED, not merely present — a guard nothing calls is decoration
    app = open(os.path.join(ROOT, "app.py"), encoding="utf-8").read()
    missing = [w for w, why in (
        ("import selfaudit", "not imported"),
        ("def _self_audit", "no wrapper"),
        ('sa = _self_audit(rebuild_ok=True)', "not called"),
        ('"audit": st.get("audit")', "not reported by /api/state"),
        ('d["audit"] =', "not folded into /api/health")) if w not in app]
    if missing:
        return {"name": name, "ok": False,
                "detail": "selfaudit exists but is not wired: " + "; ".join(missing[:3])}
    if app.count("sa = _self_audit(rebuild_ok=True)") < 2:
        return {"name": name, "ok": False,
                "detail": "the audit runs in only one place; it must run at BOOT "
                          "and after every REFRESH"}
    # THE AUDIT HAS NO DISPLAY SURFACE (ledger #116). It repairs inward; its
    # record is selfaudit.json and /api/state. The page must carry none of it.
    bapp = open(os.path.join(ROOT, "pipeline", "build_app.py"), encoding="utf-8").read()
    if "auditbar" in bapp or "__AUDIT__" in bapp:
        return {"name": name, "ok": False,
                "detail": "the page generator still surfaces the self-audit — it "
                          "is a repair loop, not a report"}
    page = os.path.join(ROOT, "data", "SE_Openings.html")
    if os.path.exists(page):
        with open(page, encoding="utf-8", errors="replace") as f:
            head = f.read(400_000)
        if "auditbar" in head or "could not put right" in head:
            return {"name": name, "ok": False,
                    "detail": "the built page carries self-audit text"}
    # and the loop must CONVERGE: a second pass on a repaired tree finds nothing
    import tempfile, shutil, json as _j
    sys.path.insert(0, os.path.join(ROOT, "engine"))
    import selfaudit
    tmp = tempfile.mkdtemp()
    try:
        os.makedirs(os.path.join(tmp, "areas")); os.makedirs(os.path.join(tmp, "raw"))
        _j.dump({"release_id": "1833224676", "region": "AYK", "units": [],
                 "full_text": "District 6 Subsistence and Personal Use Fishing Schedule. "
                              + "subsistence personal use " * 16},
                open(os.path.join(tmp, "areas", "1833224676.json"), "w"))
        _j.dump({"checked_at": "x", "releases": {"1833224676": {"disposition": "no-units"}}},
                open(os.path.join(tmp, "dispositions.json"), "w"))
        _j.dump({"as_of": "2099-01-01T00:00", "regions": {}},
                open(os.path.join(tmp, "regions_data.json"), "w"))
        open(os.path.join(tmp, "SE_Openings.html"), "w").write(
            '<meta name="afo-engine" content="x">let UNREAD_ALL = [];')
        selfaudit.run(tmp, "x", rebuild_fn=None, log=lambda *a: None)
        r2 = selfaudit.run(tmp, "x", rebuild_fn=None, log=lambda *a: None)
        if r2["contradictions"]:
            return {"name": name, "ok": False,
                    "detail": "the repair loop does not converge: a second pass still "
                              f"finds {[c['id'] for c in r2['contradictions']]} — two "
                              "repairs rewriting each other"}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    return {"name": name, "ok": True,
            "detail": "seven contradictions checked and repaired inward; the loop "
                      "converges; nothing about it reaches the page; wired at boot, "
                      "at every refresh, in /api/state and /api/health"}


def reparse_gate():
    """GATE 20 (ledger #113) — A SHIPPED GRAMMAR FIX REACHES RECORDS ALREADY HELD.

    Caught on the client's own machine minutes after he installed the build
    that fixed the Kodiak and Area M grammars: both announcements still held
    ZERO units, because parsing happens once, when a release first arrives, and
    the stored record is never revisited. Shipping a fix is not landing it.

    The announcement's own words ride with every record (ledger #89), so the
    fix needs no network — only a reason to re-derive. This gate proves the
    re-derivation works and that its safety rule holds: a re-parse may ADD
    placements and may never silently remove them all."""
    name = "a shipped grammar fix lands on announcements already held"
    import subprocess
    p = os.path.join(ROOT, "engine", "reparse.py")
    if not os.path.exists(p):
        return {"name": name, "ok": False, "detail": "engine/reparse.py is missing"}
    try:
        r = subprocess.run([sys.executable, p], capture_output=True, text=True,
                           timeout=240, cwd=os.path.join(ROOT, "engine"))
    except Exception as e:
        return {"name": name, "ok": False, "detail": f"could not run it: {e}"}
    out = (r.stdout or "") + (r.stderr or "")
    if r.returncode != 0 or "SELFTEST PASS" not in out:
        bad = [l.strip() for l in out.splitlines() if "FAIL" in l][:3]
        return {"name": name, "ok": False,
                "detail": "reparse self-test FAILED: " + ("; ".join(bad) or out[-200:])}
    app = open(os.path.join(ROOT, "app.py"), encoding="utf-8").read()
    if "import reparse" not in app or "reparse.run(" not in app:
        return {"name": name, "ok": False,
                "detail": "reparse exists but the app never calls it — a fix that "
                          "does not run is a fix that did not ship"}
    sa = open(os.path.join(ROOT, "engine", "selfaudit.py"), encoding="utf-8").read()
    if "c7_stale_parser" not in sa:
        return {"name": name, "ok": False,
                "detail": "nothing notices when records carry an older parser stamp"}
    return {"name": name, "ok": True,
            "detail": "records carry the fingerprint of the parser that made them; "
                      "a changed grammar re-derives them from their own stored "
                      "words, and never empties a record that was placing openings"}


def run():
    checks = [extractor_gate(), areastatus_gate(), inventory_gate(), doctor_gate(),
              scheduler_gate(), fetch_gate(), data_gate(), partial_floor_gate(),
              feature_floor_gate(), freshness_gate(), stale_status_gate(),
              publisher_gate(), announcement_text_gate(), page_engine_gate(),
              future_open_gate(), disposition_gate(), zero_yield_gate(), claimcheck_gate(), selfaudit_gate(), reparse_gate()]
    passed = sum(1 for c in checks if c["ok"])
    return {"ok": all(c["ok"] for c in checks),
            "passed": passed, "total": len(checks), "checks": checks}


if __name__ == "__main__":
    r = run()
    for c in r["checks"]:
        print(("PASS" if c["ok"] else "FAIL"), c["name"], "—", c["detail"])
    print(f"\n{r['passed']}/{r['total']} checks passed — {'OK' if r['ok'] else 'FAILED'}")
    sys.exit(0 if r["ok"] else 1)
