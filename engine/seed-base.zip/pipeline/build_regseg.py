#!/usr/bin/env python3
"""Reconstruct Kodiak (5 AAC 18) and Chignik (5 AAC 15) commercial-salmon
district/section boundaries from the PUBLIC regulation PDFs' text.

These two areas' salmon geometry is not published as GIS anywhere public (only
their crab is), and the authoritative service is credentialed. But the boundaries
ARE public — defined in the regulations as coordinate lines and named anchor
points. This parses that text, DISTRICT-AWARE, into every district's every
section: byte-clean anchor POINTS (name + lat/lon), coordinate LINE segments,
the full boundary text, and the section's parent district — which is what lets a
district-wide emergency order ("The Eastside Kodiak District will close…") map
onto its member sections.

COMPLETENESS RULES (v2 — the first cut dropped sections):
  * EVERY section in the regulation is kept, even one defined only by latitudes
    or shorelines with no plottable coordinate pair — it still exists for status
    mapping and in the section list, with its boundary text; it simply has no
    dots on the map. Dropping it silently hid real openings (Outer Karluk).
  * A named landmark written without its coordinates in one section but WITH
    them elsewhere in the same regulation is resolved from the file's own
    landmark table (the regulation uses one value per landmark throughout).
    Only this file's own digits are used — nothing is invented.
  * It does NOT fabricate closed polygons — boundaries following the shoreline
    or "midstream Shelikof Strait" cannot be reconstructed without a coastline —
    so these areas render as boundary reference (points + lines), never filled.

Pure stdlib.
"""
import re, json, sys, unicodedata

DEG = r"[°º]"
LAT = r"\d{1,3}\s*" + DEG + r"\s*\d{1,2}(?:\.\d+)?\s*['′]\s*[NS]"
LON = r"\d{1,3}\s*" + DEG + r"\s*\d{1,2}(?:\.\d+)?\s*['′]\s*[EW]"
PAIR = re.compile(r"(" + LAT + r")\s*\.?\s*(?:lat)?\.?\s*,?\s*(" + LON + r")", re.I)


def _dm(tok):
    m = re.match(r"(\d{1,3})\s*" + DEG + r"\s*(\d{1,2}(?:\.\d+)?)\s*['′]\s*([NSEW])", tok, re.I)
    if not m:
        return None, None
    d, mi, h = int(m.group(1)), float(m.group(2)), m.group(3).upper()
    val = d + mi / 60.0
    if h in ("S", "W"):
        val = -val
    return f"{d}°{mi:05.2f}′ {h}", val


def _points(seg):
    """Coordinate pairs in a span, each with the anchor name preceding it."""
    pts = []
    for m in PAIR.finditer(seg):
        pre = seg[:m.start()]
        nm = None
        am = (re.search(r"([A-Z][A-Za-z .'\-]{2,45}?)\s*(?:\(|at\s*)$", pre)
              or re.search(r"(?:from|to|of)\s+([A-Z][A-Za-z .'\-]{2,45}?)\s*$", pre))
        if am:
            nm = re.sub(r"\s+", " ", am.group(1)).strip(" ,;(")
        latdm, latv = _dm(m.group(1)); londm, lonv = _dm(m.group(2))
        if latv is None or lonv is None:
            continue
        pts.append({"name": (nm or None), "lat_dm": latdm, "lon_dm": londm,
                    "lon": round(lonv, 6), "lat": round(latv, 6)})
    return pts


def _segments(seg):
    lines = []
    for lm in re.finditer(r"line\s+(?:from|extending[^.]*?from|along)?\s*(.*?)(?=;|\.\s|line\s+from|\Z)", seg, re.I | re.S):
        p = _points(lm.group(1))
        if len(p) >= 2:
            lines.append([[q["lon"], q["lat"]] for q in p])
    return lines


def _lmkey(name):
    k = re.sub(r"[^a-z ]+", " ", unicodedata.normalize("NFKD", name or "").lower())
    return re.sub(r"\s+", " ", k).strip()


def _landmarks(region_text):
    """name -> point, from every named coordinate pair in the whole reg block."""
    tbl = {}
    for p in _points(region_text):
        k = _lmkey(p.get("name"))
        if k and len(k) >= 5 and k not in tbl:
            tbl[k] = p
    return tbl


_LM_REF = re.compile(r"(?:latitude|longitude) of ([A-Z][A-Za-z .'\-]{3,34}?)(?=[,.;)(]| and | to | in |$)")


def _resolve(body, pts, tbl):
    """Add landmark-resolved points for names the body references without
    coordinates but the regulation writes out elsewhere. Marked resolved:true."""
    have = {_lmkey(p.get("name")) for p in pts if p.get("name")}
    out = list(pts)
    for m in _LM_REF.finditer(body):
        k = _lmkey(m.group(1))
        if not k or k in have:
            continue
        hit = tbl.get(k)
        if hit:
            q = dict(hit); q["name"] = m.group(1).strip(); q["resolved"] = True
            out.append(q); have.add(k)
    return out


# district header — both observed forms:
#   Kodiak  (5 AAC 18): "(a) Afognak District: all waters ..."
#   Chignik (5 AAC 15): "(b) The Chignik Bay District includes all waters ..."
_DIST_HDR = re.compile(r"\(([a-z])\)\s+(?:The\s+)?([A-Z][A-Za-z0-9 '\-/]+?\s+District)\b\s*(?::|includes\b)")
_SECT_HDR = re.compile(r"\((\d+)\)\s+([A-Z][A-Za-z0-9 '\-/]+?)\s+Section\s*:")


def parse_reg(text, area_key, area_label, aac, start_marker, end_marker=None):
    flat = re.sub(r"COMMERCIAL SALMON|CHIGNIK AREA|ALASKA PENINSULA[^\n]*|_{3,}|\f", " ", text)
    flat = re.sub(r"\n?\s*\d+\s*\n", " ", flat)
    flat = re.sub(r"\s+", " ", flat)
    i = flat.find(start_marker)
    if i < 0:
        return None
    j = flat.find(end_marker, i) if end_marker else -1
    region = flat[i: j if j > 0 else i + 80000]
    tbl = _landmarks(region)

    dists = list(_DIST_HDR.finditer(region))
    sections = {}; order = []
    for di, dm in enumerate(dists):
        dname = re.sub(r"\s+", " ", dm.group(2)).strip()
        dend = dists[di + 1].start() if di + 1 < len(dists) else len(region)
        dbody = region[dm.end():dend]
        sects = list(_SECT_HDR.finditer(dbody))
        if not sects:
            # a district with no sections is itself the unit
            body = dbody
            cut = re.search(r"\([a-z]\)\s+[A-Z]|5 AAC \d", body)
            if cut:
                body = body[:cut.start()]
            pts = _resolve(body, _points(body), tbl)
            code = dname.replace(" District", "")
            sections[code] = {"code": code, "name": dname, "label": code,
                              "district_name": dname, "points": pts,
                              "lines": _segments(body),
                              "text": body.strip()[:600]}
            order.append(code)
            continue
        for k, h in enumerate(sects):
            name = re.sub(r"\s+", " ", h.group(2)).strip()
            end = sects[k + 1].start() if k + 1 < len(sects) else len(dbody)
            body = dbody[h.end():end]
            cut = re.search(r"5 AAC \d", body)
            if cut:
                body = body[:cut.start()]
            pts = _resolve(body, _points(body), tbl)
            code = name if name not in sections else f"{name} ({dname})"
            sections[code] = {"code": code, "name": name + " Section", "label": name,
                              "district_name": dname, "points": pts,
                              "lines": _segments(body),
                              "text": re.sub(r"\s+", " ", body).strip()[:600]}
            order.append(code)
    if not sections:
        return None
    xs = [p["lon"] for s in sections.values() for p in s["points"]]
    ys = [p["lat"] for s in sections.values() for p in s["points"]]
    bbox = [min(xs), min(ys), max(xs), max(ys)] if xs else None
    return {"sections": sections, "section_order": order, "bbox": bbox,
            "status": {"all": {}}, "closed_waters": {}, "gears": ["all"],
            "unit_label": "Section", "status_live": False, "geometry_kind": "reflines",
            "area_label": area_label,
            "source_note": f"Boundary reference reconstructed from {aac} (public regulation). "
                           f"Points and coordinate lines are the regulation's own; "
                           f"shoreline-following boundaries are not drawn."}


if __name__ == "__main__":
    kod = open(sys.argv[1] if len(sys.argv) > 1 else "/tmp/kodiak_reg.txt", encoding="utf-8", errors="replace").read()
    chi = open(sys.argv[2] if len(sys.argv) > 2 else "/tmp/akpen_chignik_reg.txt", encoding="utf-8", errors="replace").read()
    K = parse_reg(kod, "Kodiak", "Kodiak (5 AAC 18)", "5 AAC 18",
                  "18.200. Description of fishing districts and sections. (a)", "5 AAC 18.21")
    C = parse_reg(chi, "Chignik", "Chignik (5 AAC 15)", "5 AAC 15",
                  "15.200. Fishing districts, sections, and subsections. (a)", "5 AAC 15.21")
    for tag, R, fn in [("Kodiak", K, "Kodiak_reflines.json"), ("Chignik", C, "Chignik_reflines.json")]:
        if R:
            npts = sum(len(s["points"]) for s in R["sections"].values())
            nres = sum(1 for s in R["sections"].values() for p in s["points"] if p.get("resolved"))
            nopts = sum(1 for s in R["sections"].values() if not s["points"])
            dl = sorted({s["district_name"] for s in R["sections"].values()})
            print(f"{tag}: {len(R['sections'])} sections in {len(dl)} districts, "
                  f"{npts} points ({nres} landmark-resolved), {nopts} without plottable points")
            for d in dl:
                ss = [c for c in R["section_order"] if R["sections"][c]["district_name"] == d]
                print(f"    {d:32} {len(ss):2}: {', '.join(ss[:6])}{'…' if len(ss) > 6 else ''}")
            if len(sys.argv) > 3 and sys.argv[3] == "write":
                json.dump(R, open(fn, "w", encoding="utf-8"), separators=(",", ":"))
                print(f"    wrote {fn}")
        else:
            print(tag, "PARSE FAILED")
