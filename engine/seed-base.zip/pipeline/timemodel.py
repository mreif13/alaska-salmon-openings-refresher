#!/usr/bin/env python3
"""Work out what is actually IN FORCE right now.

A two-week-old announcement is worse than useless on a fishing chart, so every
rule carries a window and a state. Two mechanisms decide it:

  1. the period the announcement itself states ("6:00 a.m. Saturday, August 22
     through 9:00 p.m. Sunday, August 23, 2026")
  2. supersession — a newer announcement for the same fishery and region
     replaces an older one, which is how ADF&G actually works: each release
     restates the whole picture for its fishery.

Anything we cannot date is marked unknown and says so, rather than being
presented as current.
"""
import re, json, glob, datetime as dt

MONTHS = {m: i+1 for i, m in enumerate(
    ["january","february","march","april","may","june","july","august",
     "september","october","november","december"])}
MON_RE = "(" + "|".join(MONTHS) + ")"

def _mk(y, mo, d, hh, mm):
    try: return dt.datetime(y, mo, d, hh, mm)
    except ValueError: return None

def _time(h, m, ap):
    """ADF&G writes 'noon' and 'midnight' as often as a.m./p.m.

    Before this handled them, '12:00 noon' failed to parse and the whole period
    fell through to the open-ended branch — which meant seventeen areas, every
    Southeast drift-gillnet district among them, were marked open with no end
    and stayed 'in force' forever. Section 1-B closes at noon on a Friday and
    the chart would have gone on saying open all season.

    'midnight' is genuinely ambiguous (start or end of the named day). It is
    read as 00:00, the earlier reading, because for a closing instant the
    earlier reading expires the opening sooner. Every ambiguity in this file
    resolves toward 'do not fish'."""
    ap = (ap or "").lower().replace(".", "").replace(" ", "")
    if ap == "noon":     return 12, 0
    if ap == "midnight": return 0, 0
    h = int(h) if h is not None else 12
    m = int(m or 0)
    if ap.startswith("p") and h != 12: h += 12
    if ap.startswith("a") and h == 12: h = 0
    return h, m

TIME = r"(\d{1,2})?(?::(\d{1,2}))?\s*(a\.?\s?m\.?|p\.?\s?m\.?|noon|midnight)"
DATE = r"(?:\w+day,?\s*)?" + MON_RE + r"\s+(\d{1,2})(?:\s*,?\s*(\d{4}))?"
# ADF&G punctuates these sentences heavily: "12:01 p.m., Sunday, August 23,
# through 12:00 noon, Wednesday, August 26, 2026". Joining the pieces with \s*
# meant a single comma between the time and the weekday broke the whole range
# match, and the sentence fell through to the opening-instant branch — which
# gives a start and NO END. Fourteen Yakutat set-gillnet areas were left open
# with no closing time. Separators must tolerate commas.
SEP = r"[,\s]*"

def parse_period(text, default_year, published=None):
    """-> (start_iso, end_iso, confidence) ; either end may be None = open-ended."""
    if not text: return None, None, "none"
    t = " ".join(str(text).split())
    tl = t.lower()

    # A ... through/to ... B   (both a time and a date on each side)
    m = re.search(TIME + SEP + DATE + SEP + r"(?:through|to|until|thru)" + SEP + TIME + SEP + DATE, tl)
    if m:
        h1,m1,ap1,mo1,d1,y1, h2,m2,ap2,mo2,d2,y2 = m.groups()
        y2 = int(y2 or default_year); y1 = int(y1 or y2)
        H1,M1 = _time(h1,m1,ap1); H2,M2 = _time(h2,m2,ap2)
        s = _mk(y1, MONTHS[mo1], int(d1), H1, M1)
        e = _mk(y2, MONTHS[mo2], int(d2), H2, M2)
        if s and e: return s.isoformat(), e.isoformat(), "explicit"

    # "6:00 a.m. to 9:00 a.m. Saturday, August 22, 2026"  (one date, two times)
    m = re.search(TIME + SEP + r"(?:through|to|until|thru)" + SEP + TIME + SEP + DATE, tl)
    if m:
        h1,m1,ap1, h2,m2,ap2, mo,d,y = m.groups()
        y = int(y or default_year)
        H1,M1 = _time(h1,m1,ap1); H2,M2 = _time(h2,m2,ap2)
        s = _mk(y, MONTHS[mo], int(d), H1, M1); e = _mk(y, MONTHS[mo], int(d), H2, M2)
        if s and e: return s.isoformat(), e.isoformat(), "explicit"

    # a closing instant: "will close ... at 11:59 p.m., Monday, August 3, 2026"
    m = re.search(r"clos\w*[^.]{0,140}?" + TIME + SEP + DATE, tl)
    if m:
        h,mi,ap,mo,d,y = m.groups()
        y = int(y or default_year); H,M = _time(h,mi,ap)
        e = _mk(y, MONTHS[mo], int(d), H, M)
        if e: return None, e.isoformat(), "close_only"

    # an opening instant: "opens at 6:00 a.m. August 22"
    m = re.search(r"open\w*[^.]{0,140}?" + TIME + SEP + DATE, tl)
    if m:
        h,mi,ap,mo,d,y = m.groups()
        y = int(y or default_year); H,M = _time(h,mi,ap)
        s = _mk(y, MONTHS[mo], int(d), H, M)
        if s: return s.isoformat(), None, "open_only"

    # a bare date range with no times
    m = re.search(DATE + SEP + r"(?:through|to|thru|[-–])" + SEP + DATE, tl)
    if m:
        mo1,d1,y1, mo2,d2,y2 = m.groups()
        y2 = int(y2 or default_year); y1 = int(y1 or y2)
        s = _mk(y1, MONTHS[mo1], int(d1), 0, 0); e = _mk(y2, MONTHS[mo2], int(d2), 23, 59)
        if s and e: return s.isoformat(), e.isoformat(), "dates_only"

    # "... will be extended FROM 9:00 p.m. Sunday, September 6 UNTIL FURTHER
    # NOTICE" — AN OPEN END IS NOT AN OPEN START (ledger #110, axiom 30/34).
    # This sentence used to fall straight through to the until-further-notice
    # fallback below, which dated the start to the PUBLICATION day. Sand Point
    # #26 was published September 4 and opens the evening of September 6, so
    # the Unimak, Southwestern and South Central Districts and Ikatan Bay would
    # have been painted OPEN two days before a net could legally go in the
    # water. The stated start instant always wins over the publication date.
    m = re.search(r"(?:from|beginning|starting|effective|commencing)" + SEP + TIME + SEP + DATE
                  + r"[^.]{0,60}?until further notice", tl)
    if m:
        h, mi, ap, mo, d, y = m.groups()
        H, M = _time(h, mi, ap)
        st = _mk(int(y or default_year), MONTHS[mo], int(d), H, M)
        if st:
            return st.isoformat(), None, "from_until_further_notice"
    if re.search(r"until further notice|remains? open|remains? closed|closed until", tl):
        # LAST RESORT ONLY, AND NEVER EARLIER THAN A DATE THE TEXT STATES.
        # If the sentence names any instant at all, that instant bounds the
        # start; falling back to the publication date can only ever make a
        # window start EARLIER than the authority said, which is a wrong
        # opening. When a stated instant is later than publication, it wins.
        m = re.search(TIME + SEP + DATE, tl)
        if m:
            h, mi, ap, mo, d, y = m.groups()
            H, M = _time(h, mi, ap)
            st = _mk(int(y or default_year), MONTHS[mo], int(d), H, M)
            if st:
                pub = None
                try:
                    pub = dt.datetime.fromisoformat(published) if published else None
                except Exception:
                    pub = None
                if pub is None or st > pub:
                    return st.isoformat(), None, "until_further_notice"
        return (published or None), None, "until_further_notice"
    return None, None, "unparsed"

DAYS = {"monday":0,"tuesday":1,"wednesday":2,"thursday":3,
        "friday":4,"saturday":5,"sunday":6}
DAY_RE = re.compile(r"\b(" + "|".join(DAYS) + r")s?\b", re.I)

def weekly_pattern(text):
    """A THA fishery is often open only on named weekdays: 'the purse seine
    fishery will be open from 6:00 a.m. to 9:00 p.m., Sunday, Thursday and
    Friday of each week'. Read as a plain season window that is 'in force'
    from 15 August to 20 September, which is how this started, the chart says
    the seine fishery is open on a Tuesday when it is not. That is the
    dangerous direction.

    Returns (weekday_set, (start_h, start_m), (end_h, end_m)) or None. Only
    fires when the text really is a recurrence — a weekday list PLUS the
    'each week' / 'weekly' marker — so a one-off period naming its weekday
    ('6:00 a.m. Saturday, August 22') is left alone."""
    if not text: return None
    t = " ".join(str(text).split()).lower()
    # a PLURAL weekday ("on Tuesdays and Fridays from 7:00 a.m.") is a
    # recurrence even without the words "each week" — Upper Cook Inlet writes
    # its Chinitna Bay schedule exactly that way, and reading it as a plain
    # window would show the fishery open on a Sunday it does not fish.
    if not re.search(r"\b(?:of each week|each week|weekly|every week)\b", t) and \
       not re.search(r"\b(?:mon|tues|wednes|thurs|fri|satur|sun)days\b", t):
        return None
    m = re.search(TIME + SEP + r"(?:to|through|until|thru)" + SEP + TIME, t)
    if not m: return None

    # Read weekdays ONLY from the clause that owns the daily time window.
    # Scanning the whole paragraph pulled Saturday out of the season preamble
    # ("from Saturday, August 15") and out of the OTHER gears' schedules —
    # the seine fishery came back as Thu/Fri/Sat/Sun when it fishes Sun/Thu/Fri.
    tail = t[m.end(): m.end() + 220]
    tail = re.split(r"(?:\bpurse seine\b|\bdrift gillnet\b|\bset gillnet\b|\btroll\b|—|--)", tail)[0]

    days = set()
    for dm in DAY_RE.finditer(tail):
        # "Saturday, August 15" names a date, not a recurrence
        after = tail[dm.end(): dm.end() + 18]
        if re.match(r"[,\s]*(?:" + "|".join(MONTHS) + r")\b", after, re.I):
            continue
        days.add(DAYS[dm.group(1).lower()])
    # PLURAL weekdays are unambiguous recurrences wherever they sit — Upper Cook
    # Inlet writes the days BEFORE the window ("on Tuesdays and Fridays from
    # 7:00 a.m. until 7:00 p.m."), so the tail scan alone misses them.
    for dm in re.finditer(r"\b(" + "|".join(DAYS) + r")s\b", t):
        days.add(DAYS[dm.group(1).lower()])
    if not days: return None
    h1,m1,ap1,h2,m2,ap2 = m.groups()
    return days, _time(h1,m1,ap1), _time(h2,m2,ap2)

def open_now(text, start, end, now):
    """Is this area's gear actually fishing at `now`?

    Three conditions, all required: inside the season window, on a listed
    weekday, and inside the daily hours. Returns (bool, reason)."""
    pat = weekly_pattern(text)
    if not pat: return None, None                 # not a recurrence; caller uses the envelope
    days, (sh, sm), (eh, em) = pat
    if start and now < dt.datetime.fromisoformat(start): return False, "season has not started"
    if end and now > dt.datetime.fromisoformat(end):     return False, "season has ended"
    if now.weekday() not in days:
        names = [d.capitalize() for d, i in sorted(DAYS.items(), key=lambda kv: kv[1]) if i in days]
        return False, "fishes " + ", ".join(names) + " only"
    cur = now.hour * 60 + now.minute
    lo, hi = sh * 60 + sm, eh * 60 + em
    inside = (lo <= cur <= hi) if lo <= hi else (cur >= lo or cur <= hi)
    return (True, None) if inside else (False, f"today's period is {sh:02d}:{sm:02d}-{eh:02d}:{em:02d}")

def state_of(start, end, now):
    """in_force | upcoming | expired | unknown"""
    if not start and not end: return "unknown"
    s = dt.datetime.fromisoformat(start) if start else None
    e = dt.datetime.fromisoformat(end) if end else None
    if s and now < s: return "upcoming"
    if e and now > e: return "expired"
    return "in_force"

# Area offices write the region field freely: "Southeast" in one release and
# "District 15 (Lynn Canal, Haines Area, Southeast Alaska)" in the next. Keyed on
# the raw string those are different fisheries, so the newer release never
# superseded the older one and a lapsed announcement stayed on the chart
# asserting that 15-A and 15-C were open. Normalise to the area office.
REGION_ALIASES = [
    ("southeast",            ["southeast", "lynn canal", "haines", "district 15",
                              "district 1", "chatham", "icy strait", "clarence"]),
    ("yakutat",              ["yakutat", "situk", "tsiu", "alsek"]),
    ("prince william sound", ["prince william", "pws", "copper river", "coghill"]),
    ("kodiak",               ["kodiak", "afognak", "alitak"]),
    ("sand point",           ["sand point", "alaska peninsula", "area m", "south peninsula"]),
    ("norton sound",         ["norton sound", "nome", "unalakleet"]),
    ("kuskokwim",            ["kuskokwim", "bethel"]),
    ("yukon",                ["yukon"]),
    ("bristol bay",          ["bristol bay", "naknek", "nushagak", "egegik"]),
    ("cook inlet",           ["cook inlet", "kenai", "kasilof", "susitna"]),
]

def normalize_region(name):
    """Free-text region -> the area office that issues the announcement."""
    t = (name or "").lower()
    for canon, keys in REGION_ALIASES:
        if any(k in t for k in keys):
            return canon
    return t.strip() or "?"

THA_RE = re.compile(r"^(.*?)\s*(?:terminal harvest area|special harvest area|\bTHA\b|\bSHA\b)", re.I)

def tha_name(rel):
    """A terminal harvest area announcement governs ONE hatchery fishery, not the
    whole region. Keyed on (region, gear) alone, every Southeast troll THA
    collides: the region-wide summer troll announcement marked all twelve of them
    superseded, and Anita Bay — fishing through 10 November — was superseded by
    Deep Inlet purely because both are troll. Twenty of twenty-three THAs
    vanished. The THA's own name has to be part of its identity."""
    t = rel.get("title") or ""
    if not re.search(r"terminal harvest area|special harvest area|\bTHA\b|\bSHA\b", t, re.I):
        return None
    m = THA_RE.match(t)
    name = (m.group(1) if m else t).strip()
    name = re.sub(r"^\d{4}\s+", "", name)                  # drop a leading season year
    name = re.sub(r"[^a-z0-9]+", "", name.lower())
    return name or None

def fishery_key(rel):
    """Announcements supersede within a fishery: same area office, same gear set,
    and — for a terminal harvest area — the same THA.

    Keyed on the NORMALISED region (see REGION_ALIASES). Getting this wrong does
    not fail loudly: too broad and live announcements are erased as superseded,
    too narrow and an expired one stays on the chart."""
    return (normalize_region(rel.get("region")),
            ",".join(sorted(rel.get("gear") or [])) or "?",
            tha_name(rel) or "")
