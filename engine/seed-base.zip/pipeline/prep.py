import json, math, os
from datetime import datetime

SEC=json.load(open(os.path.join(os.environ["OPENINGS_SEEDS"],"ad.geojson")))
AD=json.load(open("app_data.json"))

def rdp(pts, eps):
    if len(pts)<3: return pts
    dmax=0; idx=0
    a,b=pts[0],pts[-1]
    for i in range(1,len(pts)-1):
        d=perp(pts[i],a,b)
        if d>dmax: dmax=d; idx=i
    if dmax>eps:
        L=rdp(pts[:idx+1],eps); R=rdp(pts[idx:],eps)
        return L[:-1]+R
    return [a,b]
def perp(p,a,b):
    (x,y),(x1,y1),(x2,y2)=p,a,b
    dx,dy=x2-x1,y2-y1
    if dx==0 and dy==0: return math.hypot(x-x1,y-y1)
    t=((x-x1)*dx+(y-y1)*dy)/(dx*dx+dy*dy)
    t=max(0,min(1,t)); px,py=x1+t*dx,y1+t*dy
    return math.hypot(x-px,y-py)

def simp_geom(geom, eps=0.0001, min_ring_pts=4):
    # returns list of polygons; each polygon = list of rings; ring = list of [lon,lat]
    t=geom["type"]; coords=geom["coordinates"]
    polys = coords if t=="MultiPolygon" else [coords]
    out=[]
    for poly in polys:
        rings=[]
        for ring in poly:
            pts=[(c[0],c[1]) for c in ring]
            s=rdp(pts,eps)
            if len(s)>=min_ring_pts:
                rings.append([[round(x,5),round(y,5)] for x,y in s])
        if rings:
            # keep only rings with meaningful area (outer at least)
            out.append(rings)
    return out

def bbox_of(polys):
    xs=[];ys=[]
    for poly in polys:
        for ring in poly:
            for x,y in ring: xs.append(x); ys.append(y)
    return [min(xs),min(ys),max(xs),max(ys)] if xs else None

# ---- sections geometry
sections={}
for f in SEC["features"]:
    p=f["properties"]; code=p["SECTION_CODE"]
    polys=simp_geom(f["geometry"])
    cpolys=simp_geom(f["geometry"], eps=0.0008)  # coarse for card thumbnails
    if code in sections:
        sections[code]["polys"]+=polys
        sections[code]["cpolys"]+=cpolys
        sections[code]["bbox"]=bbox_of(sections[code]["polys"])
    else:
        sections[code]={
            "code":code,
            "district_name":p.get("DISTRICT_NAME"),
            "name":p.get("SECTION_NAME") or ("Section "+code),
            "polys":polys, "cpolys":cpolys, "bbox":bbox_of(polys),
        }
# ---- districts geometry (for overview / context)
districts={}  # district geometry intentionally unused in output
# ---- status per gear
GEARS=["purse seine","drift gillnet","troll"]
# map district number/name -> district_name used in geojson
def dist_name(d):
    if d is None: return None
    d=str(d)
    if d.startswith("District"): return d
    if d.isdigit(): return "District "+d
    return d
# sections by district
secs_by_dist={}
for code,s in sections.items():
    secs_by_dist.setdefault(s["district_name"],[]).append(code)

now=AD.get("now") or datetime.utcnow().isoformat()
status={g:{} for g in GEARS}
def consider(rel, gear):
    if gear not in (rel.get("gear") or []): return
    pub=rel.get("published") or ""
    for a in rel.get("areas",[]):
        st=a.get("status"); ts=a.get("time_state")
        if st not in ("open","closed","partial"): continue
        subrules=[]
        for rr in (a.get("rules") or []):
            pts=[[round(pp["lon"],5),round(pp["lat"],5)] for pp in (rr.get("points") or []) if isinstance(pp,dict) and pp.get("lat") and pp.get("lon")]
            subrules.append({"subject":rr.get("subject"),"status":rr.get("status"),
                "geometry":rr.get("geometry"),"side":rr.get("side"),
                "distance_nmi":rr.get("distance_nmi"),"pts":pts,
                "pt_labels":[(pp.get("lat_dm") or "")+" "+(pp.get("lon_dm") or "") for pp in (rr.get("points") or []) if isinstance(pp,dict)],
                "text":(rr.get("text") or "")[:400]})
        rec={"status":st,"starts":a.get("starts"),"ends":a.get("ends"),
             "eo":rel.get("emergency_order"),"title":rel.get("title"),
             "published":pub,"time_state":ts,"url":rel.get("url"),
             "shore_only":a.get("shore_only"),"shore_bands":a.get("shore_bands") or [],
             "rules":subrules,"period_text":(a.get("period_text") or "")[:300]}
        codes=[]
        sec=a.get("section")
        if sec and sec in sections:
            codes=[sec]; rec["scope"]="section"
        elif sec is None:
            dn=dist_name(a.get("district"))
            codes=secs_by_dist.get(dn,[]); rec["scope"]="district"
        else:
            continue
        for c in codes:
            prev=status[gear].get(c)
            # prefer in_force over upcoming; then most recent published; section scope over district
            def rank(r): return (1 if r.get("time_state")=="in_force" else 0, 1 if r.get("scope")=="section" else 0, r.get("published") or "")
            if prev is None or rank(rec)>=rank(prev):
                r2=dict(rec); r2["scope"]=rec.get("scope"); status[gear][c]=r2

for rel in AD["releases"]:
    for g in GEARS: consider(rel,g)

# summary
print("as_of:", now)
for g in GEARS:
    from collections import Counter
    c=Counter(v["status"] for v in status[g].values())
    print(f"  {g:14s}: sections with status = {len(status[g])}  {dict(c)}")


# ---- standing closed-waters (permanent closures), keyed by section ----
CW=json.load(open(os.path.join(os.environ["OPENINGS_SEEDS"],"se_closedwaters.geojson")))
closed_waters={}
for f in CW["features"]:
    pr=f["properties"]; polys=simp_geom(f["geometry"], eps=0.0005, min_ring_pts=4)
    if not polys: continue
    secfield=(pr.get("section") or "").strip()
    codes=[c.strip() for c in secfield.split(",") if c.strip() and c.strip().lower() not in ("<null>","null","none")] if secfield else []
    rec={"name":(pr.get("closurename") or "").strip(),"type":pr.get("closuretype"),
         "regulation":pr.get("regulation"),"district":pr.get("district"),
         "polys":polys,"bbox":bbox_of(polys)}
    if codes:
        for c in codes: closed_waters.setdefault(c,[]).append(rec)
    else:
        # district-only closure -> attach to all sections of that district
        dn="District "+str(pr.get("district"))
        for code,sec in sections.items():
            if sec["district_name"]==dn: closed_waters.setdefault(code,[]).append(rec)
n_cw=sum(len(v) for v in closed_waters.values())
print("closed-waters attached:",n_cw,"across",len(closed_waters),"sections")

out={"generated":AD.get("generated"),"as_of":now,"region":"Southeast (5 AAC 33)",
     "gears":GEARS,"sections":sections,"districts":{},"status":status,"closed_waters":closed_waters,
     "section_order":sorted(sections.keys(), key=lambda c:(int(c.split('-')[0]), c.split('-')[1]))}
json.dump(out, open("se_openings_data.json","w"), separators=(",",":"))
import os
print("data.json size:", round(os.path.getsize("se_openings_data.json")/1024,1),"KB")
print("sections:",len(sections),"districts:",len(districts))
