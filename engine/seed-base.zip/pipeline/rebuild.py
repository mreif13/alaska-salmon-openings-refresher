"""Rebuild the served openings page after new announcements arrive.

Runtime chain (no source geojson needed — the geometry is static and already
lives in se_openings_data.json, extracted once from the shipped page):
    build_data.py  (data/raw/*.json         -> data/app_data.json)
    restatus.py    (app_data + geometry     -> data/se_openings_data.json)
    build_app.py   (se_openings_data.json   -> data/SE_Openings.html)

`prep.py` remains the first-construction tool (geojson -> geometry); it is used
in the container to build the shipped seed, not on the user's machine.
"""
import os, runpy, sys, io, contextlib


def rebuild(seeds_dir, data_dir, pipeline_dir, log=print):
    data_dir = os.path.abspath(data_dir); pipeline_dir = os.path.abspath(pipeline_dir)
    if seeds_dir:
        os.environ["OPENINGS_SEEDS"] = os.path.abspath(seeds_dir)
        # build_regions binds its GEO path at import time, and restatus imports
        # it (for the SE merges) BEFORE step 3 used to set this — leaving the
        # federal EEZ unit unmerged at status time. Set it up front.
        os.environ.setdefault("OPENINGS_STATEWIDE_GEO",
                              os.path.join(os.path.abspath(seeds_dir), "regions_geo"))
    cwd0 = os.getcwd(); sys.path.insert(0, pipeline_dir)
    try:
        os.chdir(data_dir)
        # 1) consolidate raw -> app_data.json
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            runpy.run_path(os.path.join(pipeline_dir, "build_data.py"), run_name="__main__")
        log("  build_data.py: " + (buf.getvalue().strip().splitlines()[-1] if buf.getvalue().strip() else "ok"))
        # 2) refresh SE status onto the existing geometry
        from restatus import restatus
        restatus(data_dir, log=log)
        # 3) assemble the multi-area dataset (SE fresh + the other areas' static geometry)
        if seeds_dir:
            os.environ.setdefault("OPENINGS_STATEWIDE_GEO", os.path.join(os.path.abspath(seeds_dir), "regions_geo"))
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            runpy.run_path(os.path.join(pipeline_dir, "build_regions.py"), run_name="__main__")
        log("  build_regions.py: " + (buf.getvalue().strip().splitlines()[-1] if buf.getvalue().strip() else "ok"))
        # 3b) lay LIVE open/closed status from the non-SE areas' announcements
        #     (data/areas/*.json) onto their geometry in regions_data.json
        try:
            import json as _json
            from areastatus import apply_all
            _rd = _json.load(open("regions_data.json", encoding="utf-8"))
            _live = apply_all(data_dir, _rd, log=log)
            _json.dump(_rd, open("regions_data.json", "w", encoding="utf-8"), separators=(",", ":"))
            log("  areastatus.py: live areas " + (", ".join(sorted(_live)) if _live else "none"))
        except Exception as _e:
            log("  areastatus.py skipped: " + str(_e))
        # 4) render the page
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            runpy.run_path(os.path.join(pipeline_dir, "build_app.py"), run_name="__main__")
        log("  build_app.py: " + (buf.getvalue().strip().splitlines()[-1] if buf.getvalue().strip() else "ok"))
    finally:
        os.chdir(cwd0)
    out = os.path.join(data_dir, "SE_Openings.html")
    return os.path.getsize(out) if os.path.exists(out) else 0


def rebuild_from_geojson(seeds_dir, data_dir, pipeline_dir, log=print):
    """First-construction path (container only): geojson -> geometry -> page.
    Runs prep.py instead of restatus.py. Requires the geojson in seeds_dir."""
    data_dir = os.path.abspath(data_dir); pipeline_dir = os.path.abspath(pipeline_dir)
    os.environ["OPENINGS_SEEDS"] = os.path.abspath(seeds_dir)
    cwd0 = os.getcwd(); sys.path.insert(0, pipeline_dir)
    try:
        os.chdir(data_dir)
        for script in ("build_data.py", "prep.py", "build_app.py"):
            buf = io.StringIO()
            with contextlib.redirect_stdout(buf):
                runpy.run_path(os.path.join(pipeline_dir, script), run_name="__main__")
            log(f"  {script}: " + (buf.getvalue().strip().splitlines()[-1] if buf.getvalue().strip() else "ok"))
    finally:
        os.chdir(cwd0)
    out = os.path.join(data_dir, "SE_Openings.html")
    return os.path.getsize(out) if os.path.exists(out) else 0
