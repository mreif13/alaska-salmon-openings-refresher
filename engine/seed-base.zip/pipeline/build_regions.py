#!/usr/bin/env python3
"""Assemble the multi-AREA openings dataset (Alaska > Areas > Sections).

Southeast keeps its full live status (from se_openings_data.json). Each other
area is built from its verified boundary geojson (geometry only for now — its
live open/closed status is wired from that area's announcements in a later pass;
until then it shows boundaries with an honest 'status pending' state).

Output: regions_data.json = {
  "areas": [{"key","label","status_live":bool}...],
  "regions": { <key>: {sections, section_order, bbox, status, closed_waters,
                        gears, unit_label} }
}
Each section: {code, name, label, district_name, polys(fine), cpolys(coarse), bbox}
Pure stdlib.
"""
import json, os, math, re

GEO = os.environ.get("OPENINGS_STATEWIDE_GEO",
                     "/home/claude/bof/statewide-geometry")
# SE block source: prefer the freshly-built se_openings_data.json in the working
# dir (produced by restatus at runtime); fall back to a built page or seed.
SE_DATA = os.environ.get("OPENINGS_SE_DATA",
                         "/home/claude/bof/openings-app/appsrc/seeds/SE_Openings.html")


def _rdp(pts, eps):
    if len(pts) < 3:
        return pts
    a, b = pts[0], pts[-1]; dmax = 0; idx = 0
    for i in range(1, len(pts) - 1):
        d = _perp(pts[i], a, b)
        if d > dmax:
            dmax = d; idx = i
    if dmax > eps:
        return _rdp(pts[:idx + 1], eps)[:-1] + _rdp(pts[idx:], eps)
    return [a, b]


def _perp(p, a, b):
    (x, y), (x1, y1), (x2, y2) = p, a, b
    dx, dy = x2 - x1, y2 - y1
    if dx == 0 and dy == 0:
        return math.hypot(x - x1, y - y1)
    t = ((x - x1) * dx + (y - y1) * dy) / (dx * dx + dy * dy); t = max(0, min(1, t))
    return math.hypot(x - (x1 + t * dx), y - (y1 + t * dy))


def _simp(geom, eps, minpts=4):
    t = geom["type"]; coords = geom["coordinates"]
    polys = coords if t == "MultiPolygon" else [coords]
    out = []
    for poly in polys:
        rings = []
        for ring in poly:
            pts = [(c[0], c[1]) for c in ring]
            s = _rdp(pts, eps)
            if len(s) >= minpts:
                rings.append([[round(x, 6), round(y, 6)] for x, y in s])
        if rings:
            out.append(rings)
    return out


def _bbox(polys):
    xs = []; ys = []
    for poly in polys:
        for ring in poly:
            for x, y in ring:
                xs.append(x); ys.append(y)
    return [min(xs), min(ys), max(xs), max(ys)] if xs else None


def _order_key(code):
    m = re.match(r"(\d+)\s*-?\s*([A-Za-z]*)", str(code))
    if m:
        return (0, int(m.group(1)), m.group(2))
    return (1, 0, str(code))


# ---------------------------------------------------------------- land backdrop
# Natural Earth 1:50m land (public domain), pre-clipped to the Alaska window at
# acquisition. Every map draws it under the management units so a captain can
# orient against the coast — colored shapes floating in blank space orient
# nobody (client, ledger #60).
def _clip_ring_rect(ring, x0, y0, x1, y1):
    def clip(pts, inside, inter):
        out = []
        n = len(pts)
        for i in range(n):
            a, b = pts[i], pts[(i + 1) % n]
            ia, ib = inside(a), inside(b)
            if ia:
                out.append(a)
                if not ib:
                    out.append(inter(a, b))
            elif ib:
                out.append(inter(a, b))
        return out
    p = ring
    for ins, itr in (
        (lambda q: q[0] >= x0, lambda a, b: [x0, a[1] + (b[1] - a[1]) * (x0 - a[0]) / (b[0] - a[0])]),
        (lambda q: q[0] <= x1, lambda a, b: [x1, a[1] + (b[1] - a[1]) * (x1 - a[0]) / (b[0] - a[0])]),
        (lambda q: q[1] >= y0, lambda a, b: [a[0] + (b[0] - a[0]) * (y0 - a[1]) / (b[1] - a[1]), y0]),
        (lambda q: q[1] <= y1, lambda a, b: [a[0] + (b[0] - a[0]) * (y1 - a[1]) / (b[1] - a[1]), y1]),
    ):
        p = clip(p, ins, itr)
        if len(p) < 3:
            return []
    return [[round(x, 4), round(y, 4)] for x, y in p]


def load_land():
    path = os.path.join(GEO, "alaska_land.json")
    if not os.path.exists(path):
        return None
    try:
        return json.load(open(path, encoding="utf-8"))
    except Exception:
        return None


def land_for_bbox(land, bbox, pad=0.18):
    """The land polygons cropped to an area's window (bbox + padding)."""
    if not land or not bbox:
        return []
    w = bbox[2] - bbox[0]; h = bbox[3] - bbox[1]
    x0, y0 = bbox[0] - w * pad, bbox[1] - h * pad
    x1, y1 = bbox[2] + w * pad, bbox[3] + h * pad
    out = []
    for poly in land["polys"]:
        rings = []
        for r in poly:
            c = _clip_ring_rect(r, x0, y0, x1, y1)
            if len(c) >= 4:
                rings.append(c)
        if rings:
            out.append(rings)
    return out


def _first(p, fields):
    """First non-empty property value among a comma-separated candidate list."""
    for f in (fields or "").split(","):
        f = f.strip()
        if f and p.get(f) not in (None, "", " "):
            return str(p.get(f)).strip()
    return ""


def build_area(path, code_field, name_field, dist_field, unit_word, area_label):
    """Turn one region's unit geojson into a sections block. code_field/name_field/
    dist_field may each be a comma-separated candidate list (first present wins)."""
    d = json.load(open(path, encoding="utf-8"))
    sections = {}
    for f in d["features"]:
        p = f["properties"]
        raw_name = _first(p, name_field)
        code = _first(p, code_field) or raw_name
        if not code:
            continue
        polys = _simp(f["geometry"], 0.00005)
        cpolys = _simp(f["geometry"], 0.0008)
        if not polys:
            continue
        label = raw_name or code
        label = re.sub(r"\s*(District|Section|Subdistrict)$", "", label, flags=re.I).strip() or code
        dn = _first(p, dist_field) or area_label
        # merge duplicate codes (multi-feature units)
        if code in sections:
            sections[code]["polys"] += polys; sections[code]["cpolys"] += cpolys
            sections[code]["bbox"] = _bbox(sections[code]["polys"])
        else:
            sections[code] = {"code": code, "name": raw_name or code, "label": label,
                              "district_name": dn or area_label,
                              "polys": polys, "cpolys": cpolys, "bbox": _bbox(polys)}
    order = sorted(sections.keys(), key=_order_key)
    allb = [sections[c]["bbox"] for c in sections]
    bbox = [min(b[0] for b in allb), min(b[1] for b in allb),
            max(b[2] for b in allb), max(b[3] for b in allb)] if allb else None
    return {"sections": sections, "section_order": order, "bbox": bbox,
            "status": {"all": {}}, "closed_waters": {},
            "gears": ["all"], "unit_label": unit_word, "status_live": False}


def load_se():
    # runtime: se_openings_data.json in the working dir is the fresh SE block
    if os.path.exists("se_openings_data.json"):
        se = json.load(open("se_openings_data.json", encoding="utf-8"))
    else:
        html = open(SE_DATA, encoding="utf-8").read()
        m = re.search(r"const DATA_ALL = (\{.*?\});", html, re.S) or re.search(r"const DATA = (\{.*?\});", html, re.S)
        obj = json.loads(m.group(1))
        se = obj["regions"]["SE"] if "regions" in obj else obj
    se["unit_label"] = "Section"; se["status_live"] = True
    _merge_se_districts(se)
    return se


def _merge_se_districts(se):
    """5 AAC 33.200 defines Districts 1-16 plus Dixon Entrance, but the GIS
    SECTIONS layer only carries districts that have sections — Districts 2, 4,
    5, and 16 have none and were missing from the map entirely, so their EO
    openings (District 4 was OPEN on the Aug 20 seine announcement) silently
    vanished. Their official district polygons are merged in as units of their
    own. Idempotent; a no-op when the geojson is absent or already merged."""
    path = os.path.join(GEO, "SE_Districts_missing.geojson")
    if not os.path.exists(path):
        return
    have = {s.get("district_name") for s in se["sections"].values()}
    have |= set(se["sections"].keys())
    try:
        d = json.load(open(path, encoding="utf-8"))
    except Exception:
        return
    added = []
    for f in d.get("features", []):
        name = (f["properties"].get("DISTRICT_NAME") or "").strip()
        if not name or name in have or name in se["sections"]:
            continue
        polys = _simp(f["geometry"], 0.00005)
        cpolys = _simp(f["geometry"], 0.0008)
        if not polys:
            continue
        se["sections"][name] = {"code": name, "name": name, "label": name.replace("District ", "D"),
                                "district_name": name, "polys": polys, "cpolys": cpolys,
                                "bbox": _bbox(polys)}
        added.append(name)
    if added:
        def _k(c):
            m = re.search(r"(\d+)", c)
            n = int(m.group(1)) if m else 99
            return (n, str(c))
        se["section_order"] = sorted(se["sections"].keys(), key=_k)
        allb = [s["bbox"] for s in se["sections"].values()
                if s.get("bbox") and not s.get("nofit")]
        se["bbox"] = [min(b[0] for b in allb), min(b[1] for b in allb),
                      max(b[2] for b in allb), max(b[3] for b in allb)]
        print(f"  SE: merged {len(added)} sectionless districts: {', '.join(added)}")
    _merge_se_federal(se)


def _merge_se_federal(se):
    """The FEDERAL troll water (Salmon FMP East Area, 50 CFR 679.2): the EEZ in
    the Gulf of Alaska east of Cape Suckling's longitude (143°53.6′ W), troll
    gear only, managed by ADF&G under federal delegation — the same SE/Yakutat
    troll announcements govern it (RIR 1J.2026.12). Client-caught omission: the
    map drew only the state district/section structure, so the federally-open
    troll grounds (Fairweather Ground and the whole offshore band) were
    invisible. Merged as a troll-only unit whose boundaries are BOEM's official
    Submerged Lands Act line (inner, where state waters end at 3 nm) and NOAA's
    200-nm EEZ / US–Canada maritime boundary (outer), both fetched byte-clean
    and clipped at the regulation's own meridian. Lines, never a fabricated
    fill. nofit keeps the default SE view on the sections; picking its
    'district' zooms to it. Idempotent."""
    path = os.path.join(GEO, "SE_Federal_EEZ.json")
    if not os.path.exists(path):
        return
    try:
        u = json.load(open(path, encoding="utf-8"))
    except Exception:
        return
    code = u.get("code") or "Federal EEZ (East Area)"
    if code in se["sections"]:
        return
    se["sections"][code] = u
    if code not in se.get("section_order", []):
        se.setdefault("section_order", []).append(code)
    print(f"  SE: merged federal troll unit ({u.get('eez_line_count',0)} EEZ + "
          f"{len(u.get('lines',[]))-u.get('eez_line_count',0)} SLA boundary segments)")


def _add_reg_units(blk, path, tag=""):
    """Merge a regulation-reconstructed reflines block's sections (points +
    coordinate lines, no polygons) into a polygon area as additional units."""
    if blk is None or not os.path.exists(path):
        return
    try:
        d = json.load(open(path, encoding="utf-8"))
    except Exception:
        return
    added = 0
    for code, sec in d.get("sections", {}).items():
        if code in blk["sections"]:
            continue
        blk["sections"][code] = sec
        added += 1
    if added:
        blk["unit_label"] = "Unit"
        blk["section_order"] = sorted(blk["sections"].keys(), key=_order_key)
        if not blk.get("source_note"):
            blk["source_note"] = d.get("source_note")
        print(f"  + {tag}: {added} units merged")


def _add_units(blk, path, name_field, dist_field, only=None, tag=""):
    """Merge a supplemental geojson layer's features into an area block as
    additional units. A unit whose name collides within its district gets the
    district appended to its code so lookups stay unambiguous ('General
    Subdistrict (Coghill District)'). Idempotent."""
    if blk is None or not os.path.exists(path):
        return
    try:
        d = json.load(open(path, encoding="utf-8"))
    except Exception:
        return
    added = 0
    for f in d.get("features", []):
        p = f["properties"]
        name = (p.get(name_field) or "").strip()
        dn = (p.get(dist_field) or "").strip() or name
        if not name or (only is not None and name not in only):
            continue
        code = name if name not in blk["sections"] else f"{name} ({dn})"
        if code in blk["sections"]:
            continue
        polys = _simp(f["geometry"], 0.00005)
        cpolys = _simp(f["geometry"], 0.0008)
        if not polys:
            continue
        blk["sections"][code] = {"code": code, "name": (name if code == name else code),
                                 "label": re.sub(r"\s*(District|Section|Subdistrict)$", "", name).strip() or name,
                                 "district_name": dn,
                                 "polys": polys, "cpolys": cpolys, "bbox": _bbox(polys)}
        added += 1
    if added:
        blk["unit_label"] = "Unit"          # districts + subdistricts mixed
        blk["section_order"] = sorted(blk["sections"].keys(), key=_order_key)
        allb = [s["bbox"] for s in blk["sections"].values() if s.get("bbox")]
        blk["bbox"] = [min(b[0] for b in allb), min(b[1] for b in allb),
                       max(b[2] for b in allb), max(b[3] for b in allb)]
        print(f"  + {tag}: {added} units merged")


def main():
    regions = {}
    regions["SE"] = load_se()
    specs = [
        ("PWS", "Prince William Sound", "Commercial_Salmon_PrinceWilliamSound_Districts.geojson",
         "DISTRICT_CODE", "DISTRICT_NAME", None, "District"),
        ("BristolBay", "Bristol Bay", "BristolBay_Sections.geojson",
         None, "SECTION_NAME", "DISTRICT_NAME", "Section"),
        ("CookInlet", "Cook Inlet (Upper)", "CookInlet_Sections.geojson",
         "SECTION_CODE", "SECTION_NAME", "DISTRICT_NAME", "Section"),
        ("Yakutat", "Yakutat", "Yakutat_Districts.geojson",
         "DISTRICT_CODE", "DISTRICT_NAME", None, "District"),
        ("AreaM", "Alaska Peninsula (Area M)", "AreaM_Salmon.geojson",
         "N_S_Name", "N_S_Name", "Area_Name", "Subarea"),
        ("AYK", "Arctic–Yukon–Kuskokwim", "Salmon_AYK_2017.geojson",
         "STAT_AREA", "SECTION_NA,DISTRICT_N", "DISTRICT_N,MANAGEMENT", "Stat area"),
    ]
    for key, label, fn, cf, nf, df, unit in specs:
        path = os.path.join(GEO, fn)
        if not os.path.exists(path):
            print("  MISSING", fn); continue
        blk = build_area(path, cf, nf, df, unit, label)
        blk["area_label"] = label
        regions[key] = blk
        print(f"  {key:11} {len(blk['sections']):3} {unit.lower()}s  bbox={['%.1f'%v for v in blk['bbox']]}")
    # ---- supplemental unit layers (the completeness fixes of ledger #60) ----
    # Bristol Bay: Egegik and Ugashik Districts have no sections in the reg, so
    # the sections layer omitted them — two of the five BB districts missing.
    _add_units(regions.get("BristolBay"), os.path.join(GEO, "BB_Districts.geojson"),
               name_field="DISTRICT_NAME", dist_field="DISTRICT_NAME",
               only={"Egegik District", "Ugashik District"}, tag="BB districts")
    # Upper Cook Inlet: the 8 subdistricts (Chinitna Bay, Kalgin Island, ...)
    # are what UCI announcements actually open; the set-gill sections alone
    # could not receive them.
    _add_units(regions.get("CookInlet"), os.path.join(GEO, "CI_Subdistricts.geojson"),
               name_field="SUBDISTRICT_NAME", dist_field="DISTRICT_NAME",
               tag="CI subdistricts")
    # PWS: the 19 subdistricts (Cannery Creek, Main Bay, ...) let a
    # subdistrict-scoped opening land on its own water instead of only
    # flagging the whole district partial.
    _add_units(regions.get("PWS"), os.path.join(GEO, "PWS_Subdistricts.geojson"),
               name_field="SUBDISTRICT_NAME", dist_field="DISTRICT_NAME",
               tag="PWS subdistricts")
    # Area M: 5 AAC 09.200 defines 6 districts / 36 sections with coordinate
    # anchors — reconstructed from the public regulation (same route as
    # Kodiak/Chignik) so Sand Point advisories land on real spatial units
    # instead of two half-peninsula polygons.
    _add_reg_units(regions.get("AreaM"), os.path.join(GEO, "AreaM_reflines.json"),
                   tag="Area M reg sections")
    # Prebuilt boundary-reference areas (Kodiak/Chignik, reconstructed from the
    # public regulation PDFs — points + lines, not polygons). Static JSON blocks.
    refline_specs = [("Kodiak", "Kodiak_reflines.json"), ("Chignik", "Chignik_reflines.json")]
    for key, fn in refline_specs:
        path = os.path.join(GEO, fn)
        if os.path.exists(path):
            blk = json.load(open(path, encoding="utf-8"))
            regions[key] = blk
            print(f"  {key:11} {len(blk['sections']):3} sections (reflines from regulation)")

    # ---- Westward WATER RIBBONS (ledger #76, client: "area m visuals
    # communicate almost nothing about where one can and can't fish") ----
    # ADF&G publishes no salmon-section GIS for Kodiak/Chignik/Area M, so
    # tools/coastal_ribbons.py reconstructs planning bands: the coast run
    # fenced by each section's OWN regulation coordinates, offset seaward a
    # fixed width against the public 1:10m coastline. Sections that got a
    # band gain polys (status now paints WATER, splits/rings/fly-to all
    # inherit) and carry reconstructed:true so the renderer draws them
    # dashed + lighter, with a banner naming the method. Sections without
    # enough of their own coordinates keep their dots — never a guess.
    rib_path = os.path.join(GEO, "westward_ribbons.json")
    if os.path.exists(rib_path):
        ribs = json.load(open(rib_path, encoding="utf-8")).get("areas", {})
        for ak, units in ribs.items():
            blk = regions.get(ak)
            if not blk:
                continue
            n = 0
            for code, r in units.items():
                sec = blk["sections"].get(code)
                if not sec or sec.get("polys"):
                    continue                     # never overwrite real GIS
                sec["polys"] = r["polys"]
                sec["cpolys"] = r["polys"]
                sec["reconstructed"] = True
                sec["bbox"] = _bbox(r["polys"])
                n += 1
            if n:
                allb = [s["bbox"] for s in blk["sections"].values() if s.get("bbox")]
                blk["bbox"] = [min(b[0] for b in allb), min(b[1] for b in allb),
                               max(b[2] for b in allb), max(b[3] for b in allb)]
                blk["has_reconstructed"] = True
                if blk.get("geometry_kind") == "reflines":
                    # polygons now exist: render through the normal area map
                    # (poly fills + dot fallbacks in one loop), not the
                    # points-only reference chart
                    blk["geometry_kind"] = "mixed"
                print(f"  + {ak}: {n} sections gained reconstructed water ribbons")

    # land backdrop: statewide for the Alaska home view, per-region crops for
    # every area map (reflines areas included — that IS their chart context)
    land = load_land()
    if land:
        for key, blk in regions.items():
            blk["land"] = land_for_bbox(land, blk.get("bbox"))
        print(f"  land backdrop attached ({sum(len(b.get('land') or []) for b in regions.values())} region crops)")

    # CHART NAMES (ledger #87): points, capes, bays from GNIS — pulled from
    # ADF&G's own public GNIS service (dfg_public/GNIS MapServer, FEATURE_CLASS
    # Cape/Bay), 5,387 features, transferred and verified BYTE-EXACT by sha256
    # against the hash computed inside the service's own origin. Coordinates
    # are the service's decimal fields verbatim — never retyped. Each region
    # carries the names inside its bbox (+0.3 deg); the page declutters at
    # draw time. Rows with 0,0 (GNIS unpositioned) and east-longitude features
    # (beyond the drawn windows) are excluded.
    gnis_path = os.path.join(GEO, "gnis_capes_bays_ak.tsv")
    if os.path.exists(gnis_path):
        rows = []
        for ln in open(gnis_path, encoding="utf-8"):
            f = ln.rstrip("\n").split("\t")
            if len(f) != 4:
                continue
            try:
                lat, lon = float(f[2]), float(f[3])
            except ValueError:
                continue
            if lat == 0 or lon == 0 or lon > 0:
                continue
            rows.append((f[0], f[1], lat, lon))
        total = 0
        for key, blk in regions.items():
            bb = blk.get("bbox")
            if not bb:
                continue
            m = 0.3
            sel = [[n, k2, la, lo] for (n, k2, la, lo) in rows
                   if bb[0] - m <= lo <= bb[2] + m and bb[1] - m <= la <= bb[3] + m]
            blk["chart_names"] = sel
            total += len(sel)
        print(f"  chart names attached: {total} placements from {len(rows)} GNIS capes/bays")

    ordered = ["SE"] + [s[0] for s in specs if s[0] in regions] + [k for k, _ in refline_specs if k in regions]
    label_of = {"SE": "Southeast Alaska"}
    for s in specs:
        label_of[s[0]] = s[1]
    for key, _ in refline_specs:
        if key in regions:
            label_of[key] = regions[key].get("area_label", key)
    areas = [{"key": k, "label": label_of.get(k, k), "status_live": (k == "SE")} for k in ordered]
    out = {"areas": areas, "regions": regions,
           "land_ak": (land["polys"] if land else []),
           "generated": regions["SE"].get("generated"), "as_of": regions["SE"].get("as_of")}
    json.dump(out, open("regions_data.json", "w", encoding="utf-8"), separators=(",", ":"))
    print("wrote regions_data.json:", round(os.path.getsize("regions_data.json") / 1024 / 1024, 2), "MB;",
          len(areas), "areas")


if __name__ == "__main__":
    main()
