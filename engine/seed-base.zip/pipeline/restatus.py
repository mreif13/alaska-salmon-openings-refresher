"""Refresh the openings map's STATUS layer without re-reading the raw geometry.

The regulation geometry (section polygons, permanent closed waters) is static —
it is shipped once, baked into the built page, and does not change when a new
announcement posts. Only the open/closed/partial STATUS of each section, and the
in-season closure rules, change. So on refresh we reuse the geometry already in
`se_openings_data.json` (extracted once from the shipped page) and recompute only
the status from the freshly-built `app_data.json`.

This is what lets the standalone app ship WITHOUT the ~11 MB of source geojson:
the geometry travels once, in the page. `prep.py` (which builds the geometry from
geojson) remains the tool of record for first construction; this is its
runtime-refresh twin. The status logic is a faithful port of prep.py's.
"""
import json, os
from collections import Counter
from datetime import datetime
from timemodel import tha_name

GEARS = ["purse seine", "drift gillnet", "troll"]


def dist_name(d):
    if d is None:
        return None
    d = str(d)
    if d.startswith("District"):
        return d
    if d.isdigit():
        return "District " + d
    return d


def recompute_status(sections, releases, now):
    secs_by_dist = {}
    for code, s in sections.items():
        secs_by_dist.setdefault(s.get("district_name"), []).append(code)
    status = {g: {} for g in GEARS}
    tha_notes = {}                          # pocket name -> newest words-only advisory

    def consider(rel, gear):
        if gear not in (rel.get("gear") or []):
            # a THA pocket advisory ("closed to ALL common property commercial
            # salmon fisheries") often names no gear — it applies to every
            # gear; let it through so its note is collected (deduped by name)
            if not any(a.get("tha_pocket") for a in rel.get("areas") or []):
                return
        pub = rel.get("published") or ""
        tha = tha_name(rel)
        for a in rel.get("areas", []):
            st = a.get("status"); ts = a.get("time_state")
            if st not in ("open", "closed", "partial"):
                continue
            # an ENDED opening is not an opening: SE fisheries open by
            # per-period EO, and once the window passes those waters are closed
            # to that gear until a new EO says otherwise. Leaving 13-B "partly
            # open until Aug 23" on Aug 30 is a wrong opening a week stale.
            # (The words and drawn lines stay — the captain sees WHAT expired.)
            # THE CLOCK IS THE AUTHORITY, NEVER A LABEL (axiom 30, ledger #74):
            # keying this on time_state=="expired" alone let records labeled
            # "superseded" — whose windows had ALSO ended — sail through and
            # show 9-B "partly open until Aug 23" a full week stale. Any
            # open/partial whose own end time is behind the build clock
            # displays CLOSED, whatever its label says.
            # A TIME CHECK RUNS IN BOTH DIRECTIONS (axiom 36, ledger #105).
            # The expired->closed rule above was written against the sighting
            # that prompted it and guarded ONE end of the window. An opening
            # announced on the 3rd for the 6th was therefore stored "open" and
            # painted green from the moment it was ingested — a gillnetter saw
            # a section shown open for gillnetting two days before it opened.
            # "Open" is a claim about NOW: before the start it is UPCOMING,
            # after the end it is CLOSED, and only between them is it open.
            _ends = a.get("ends")
            _starts = a.get("starts")
            if st in ("open", "partial") and (
                    ts == "expired" or (_ends and str(_ends) < str(now))):
                st = "closed"
            elif st in ("open", "partial") and (
                    ts == "upcoming" or (_starts and str(_starts) > str(now))):
                st = "upcoming"
            subrules = []
            for rr in (a.get("rules") or []):
                pts = [[round(pp["lon"], 5), round(pp["lat"], 5)]
                       for pp in (rr.get("points") or [])
                       if isinstance(pp, dict) and pp.get("lat") and pp.get("lon")]
                subrules.append({"subject": rr.get("subject"), "status": rr.get("status"),
                                 "geometry": rr.get("geometry"), "side": rr.get("side"),
                                 "distance_nmi": rr.get("distance_nmi"), "pts": pts,
                                 "pt_labels": [(pp.get("lat_dm") or "") + " " + (pp.get("lon_dm") or "")
                                               for pp in (rr.get("points") or []) if isinstance(pp, dict)],
                                 "text": (rr.get("text") or "")[:400]})
            rec = {"status": st, "starts": a.get("starts"), "ends": a.get("ends"),
                   "eo": rel.get("emergency_order"), "title": rel.get("title"),
                   "published": pub, "time_state": ts, "url": rel.get("url"),
                   "rel": rel.get("id"),
                   "shore_only": a.get("shore_only"), "shore_bands": a.get("shore_bands") or [],
                   "rules": subrules, "period_text": (a.get("period_text") or "")[:600]}
            sec = a.get("section")
            if tha:
                # A TERMINAL HARVEST AREA release governs a pocket, never whole
                # sections. Painting 12-A/12-B fully open off the Hidden Falls
                # THA opener was a wrong opening waiting for the day the
                # region-wide fishery closes around the pocket. A THA record
                # renders at most PARTIAL on its host sections, at the LOWEST
                # rank, so it only fills where nothing region/district/section
                # scoped speaks.
                if sec and sec in sections:
                    codes = [sec]
                elif a.get("district") is not None:
                    codes = secs_by_dist.get(dist_name(a.get("district")), [])
                else:
                    # no host named: the pocket statement surfaces as a NAMED
                    # advisory note (Deep Inlet THA closing to all common-
                    # property fisheries, ledger #70) — its words shown on the
                    # area page, no section painted (a pocket closure does not
                    # change the surrounding fishery's status)
                    import re as _re
                    nm = (a.get("tha_pocket") or tha or "THA").strip()
                    key = _re.sub(r"[^a-z0-9]+", "", nm.lower())
                    # an advisory whose own window has ended is history, not
                    # status — it never earns a note (Gunnuk's June opener).
                    # EXCEPT an until-further-notice closure: its "effective"
                    # date can misread as an end, and the closure stands until
                    # a new announcement lifts it.
                    _ufn = bool(_re.search(r"until further notice", a.get("period_text") or "", _re.I))
                    if (a.get("ends") or "") and str(a.get("ends")) < str(now) and not _ufn:
                        continue
                    old = tha_notes.get(key)
                    if old is None or (pub or "") >= (old.get("published") or ""):
                        disp = nm
                        if " " not in disp:
                            pm = _re.search(r"(?:The\s+)?([A-Z][A-Za-z' ]{2,40}?)\s+(?:Troll\s+)?(?:Terminal Harvest Area|THA)\b",
                                            a.get("period_text") or "")
                            if pm:
                                disp = pm.group(1).strip()
                            elif old and " " in (old.get("name") or ""):
                                disp = old["name"]
                        tha_notes[key] = {
                            "name": disp, "status": rec["status"],
                            "text": (a.get("period_text") or "")[:350],
                            "eo": rel.get("emergency_order"),
                            "published": pub, "url": rel.get("url"),
                            "rel": rel.get("id"),
                            # starts travels too: a pocket announced to open at
                            # a future datetime IS an opens-soon a captain
                            # positions on (Anita Bay, Sept 1 — ledger #73)
                            "starts": a.get("starts"),
                            "gear": ", ".join(rel.get("gear") or []) or None,
                            "ends": a.get("ends")}
                    continue
                rec = dict(rec); rec["scope"] = "tha"
                if rec["status"] == "open":
                    rec["status"] = "partial"       # a pocket open = some waters open
            elif a.get("region_wide") and sec is None and a.get("district") is None:
                # a region-wide fishery statement (e.g. the summer troll
                # opener/closure) governs every section for its gear
                codes = list(sections.keys()); rec = dict(rec); rec["scope"] = "region"
            elif sec and sec in sections:
                codes = [sec]; rec = dict(rec); rec["scope"] = "section"
            elif sec is None and a.get("district") is not None:
                codes = secs_by_dist.get(dist_name(a.get("district")), []); rec = dict(rec); rec["scope"] = "district"
            else:
                continue
            SCOPE_RANK = {"section": 3, "district": 2, "region": 1, "tha": 0}

            def rank(r):
                return (1 if r.get("time_state") == "in_force" else 0,
                        SCOPE_RANK.get(r.get("scope"), 0), r.get("published") or "")
            for c in codes:
                prev = status[gear].get(c)
                if prev is None or rank(rec) >= rank(prev):
                    status[gear][c] = dict(rec)

    for rel in releases:
        for g in GEARS:
            consider(rel, g)
    return status, sorted(tha_notes.values(), key=lambda n: n.get("published") or "", reverse=True)


def restatus(data_dir, log=print):
    """Rebuild se_openings_data.json from the existing geometry + new app_data.json."""
    prev_path = os.path.join(data_dir, "se_openings_data.json")
    ad_path = os.path.join(data_dir, "app_data.json")
    prev = json.load(open(prev_path, encoding="utf-8"))
    ad = json.load(open(ad_path, encoding="utf-8"))
    # the sectionless districts (2, 4, 5, 16, Dixon Entrance) must exist BEFORE
    # status mapping, or their EO statuses have nothing to land on — the very
    # miss that hid District 4's opening (ledger #60)
    try:
        from build_regions import _merge_se_districts
        _merge_se_districts(prev)
    except Exception as e:
        log(f"  (district merge skipped: {e})")
    now = ad.get("now") or datetime.utcnow().isoformat()
    status, tha_notes = recompute_status(prev["sections"], ad.get("releases", []), now)
    out = dict(prev)
    out["generated"] = ad.get("generated")
    out["as_of"] = now
    out["status"] = status
    out["tha_notes"] = tha_notes
    # ONE copy of each announcement's complete words, keyed by release; every
    # section rec points at its own by id (ledger #89). Stored once, never per
    # section — the whole SE fishery is a handful of releases.
    out["announcements"] = {
        r["id"]: {"title": r.get("title"), "published": r.get("published"),
                  "eo": r.get("emergency_order"), "url": r.get("url"),
                  "text": r.get("full_text")}
        for r in (ad.get("releases") or []) if r.get("id") and r.get("full_text")}
    log(f"  announcements with complete words: {len(out['announcements'])}"
        f" of {len(ad.get('releases') or [])}")
    json.dump(out, open(prev_path, "w", encoding="utf-8"), separators=(",", ":"))
    for g in GEARS:
        c = Counter(v["status"] for v in status[g].values())
        log(f"  {g:14s}: {len(status[g])} sections {dict(c)}")
    return prev_path


if __name__ == "__main__":
    import sys
    restatus(sys.argv[1] if len(sys.argv) > 1 else ".")
