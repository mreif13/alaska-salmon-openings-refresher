import os
import json

# THE PAGE SAYS WHICH ENGINE BUILT IT (axiom 33, ledger #85/#96).
# The installer preserves data/, and a rebuild only happens when new
# announcements arrive — so a freshly upgraded app served, and PUBLISHED, the
# previous version's page while /api/state reported the new engine. The engine
# version and the page version are two different facts and the page has to
# carry its own, or nothing on any screen can tell them apart.
def _engine_version():
    v = os.environ.get("AFO_ENGINE_VERSION", "").strip()
    if v:
        return v
    try:
        here = os.path.dirname(os.path.abspath(__file__))
        with open(os.path.join(here, "..", "app.py"), encoding="utf-8") as f:
            for line in f:
                t = line.strip()
                if t.startswith("VERSION") and "=" in t and '"' in t:
                    return t.split('"')[1]
    except Exception:
        pass
    return "unknown"

ENGINE_VERSION = _engine_version()


def _generator_fingerprint():
    """VERSION NAMES THE RELEASE; THIS NAMES THE BUILD (axiom 33 + 36).
    Two pages can carry the same version and different code — it happened
    within an hour of the axiom-36 fix: a page generated before the fix and one
    after both stamped 2.9.3, so the boot-time reconciliation compared equal
    strings and served the stale one. The stamp now carries a short hash of the
    generator itself, so ANY change to how a page is built forces a rebuild."""
    import hashlib
    h = hashlib.sha256()
    here = os.path.dirname(os.path.abspath(__file__))
    for fn in sorted(("build_app.py", "restatus.py", "areastatus.py", "timemodel.py")):
        try:
            with open(os.path.join(here, fn), "rb") as f:
                h.update(f.read())
        except Exception:
            pass
    return h.hexdigest()[:8]


ENGINE_STAMP = ENGINE_VERSION + "+" + _generator_fingerprint()


def _read_record(rid):
    for sub in ("areas", "raw"):
        try:
            with open(os.path.join(sub, rid + ".json"), encoding="utf-8") as f:
                return json.load(f) or {}
        except Exception:
            continue
    return {}


def _on_chart_ids():
    """The releases that actually REACHED THE CHART, read off the chart itself.

    "Parsed some units" is not the same claim as "a captain can see it"
    (ledger #114): a release can name four districts that this map has no
    geometry for and place nothing at all. Every status record carries the id
    of the release that produced it, so the chart can be asked directly instead
    of inferred from the parse — which is the whole discipline of this project
    applied to its own warning bar.
    """
    ids = set()
    try:
        with open("regions_data.json", encoding="utf-8") as f:
            D0 = json.load(f) or {}
    except Exception:
        return ids
    for R in (D0.get("regions") or {}).values():
        for st in (R.get("status") or {}).values():
            for rec in (st or {}).values():
                if rec.get("rel"):
                    ids.add(str(rec["rel"]))
        for n in (R.get("tha_notes") or []):
            if isinstance(n, dict) and n.get("rel"):
                ids.add(str(n["rel"]))
    return ids


def _pretty_date(iso):
    try:
        import datetime as _d
        d = _d.datetime.fromisoformat(str(iso)[:16])
        return d.strftime("%b %-d") if os.name != "nt" else d.strftime("%b %d").replace(" 0", " ")
    except Exception:
        return ""


def _unread_announcements():
    """Announcements ADF&G published that are NOT on this chart — named the way
    a person reads them, and only the ones that are still the current word.

    A captain must be told these exist (axiom 37); axiom 38 added the ones we
    read and placed nothing from. Ledger #114 is the client on what that list
    had become: twelve raw release ids, most of them Yukon subsistence
    schedules and superseded restatements. *"It doesn't help communicate to the
    human eye at a quick glance,"* and *"keep this section clean, without it
    detracting from the page."* He is right — a warning that lists everything
    warns about nothing, and one written in nine-digit ids warns nobody.

    Three rules, in order:
      1. A SUPERSEDED ANNOUNCEMENT IS NOT MISSING. If a NEWER release in the
         same series (Norton Sound #20 after #19) or a newer release for the
         same area that DID place its units (Kodiak #45 after #43) exists, the
         older one is answered, not absent.
      2. WHAT IS SHOWN IS NAMED — "Kodiak #45 · Sep 2", off the announcement's
         own letterhead, never a release id.
      3. The list is capped at four and SAYS SO. Silent truncation is the same
         silence this bar exists to break.
    """
    import datetime as _dt
    cut = (_dt.datetime.now() - _dt.timedelta(days=14)).isoformat(timespec="minutes")
    try:
        with open("dispositions.json", encoding="utf-8") as f:
            led = json.load(f) or {}
    except Exception:
        return []
    rel = led.get("releases") or {}

    on_chart = _on_chart_ids()
    cand, placed_by_region = [], {}
    for rid, d in rel.items():
        if not str(rid).isdigit():
            continue
        rec = _read_record(str(rid))
        text = rec.get("full_text") or ""
        lab = {}
        try:
            import openparse
            lab = openparse.announcement_label(text)
        except Exception:
            pass
        region = (d or {}).get("region") or rec.get("region") or ""
        pub = (d or {}).get("published") or rec.get("published") or ""
        if str(rid) in on_chart:
            k = str(rid)
            if k > placed_by_region.get(region, ""):
                placed_by_region[region] = k
            continue
        why = (d or {}).get("disposition")
        if why not in ("unreadable", "unplaceable", "error", "no-units"):
            continue                      # subsistence-only / not-salmon: correctly absent
        if why == "no-units" and pub and pub < cut:
            continue                      # long since answered by a newer announcement
        cand.append({"id": str(rid), "why": why, "region": region, "published": pub,
                     "series": lab.get("series") or "", "number": lab.get("number"),
                     "label": lab.get("label") or "",
                     "title": ((d or {}).get("title") or "")[:120]})

    # rule 1 — supersession, by series first (precise) then by area
    newest_in_series = {}
    for c in cand:
        if c["series"]:
            k = c["series"]
            if (c["number"] or 0) > (newest_in_series.get(k, (0, ""))[0] or 0):
                newest_in_series[k] = (c["number"] or 0, c["id"])
    keep = []
    for c in cand:
        if c["series"] and newest_in_series[c["series"]][1] != c["id"]:
            continue                      # an older number in the same series
        if c["id"] < placed_by_region.get(c["region"], ""):
            continue                      # a newer release for this area did place
        keep.append(c)

    keep.sort(key=lambda c: c["id"], reverse=True)
    total = len(keep)
    global UNREAD_ALL
    UNREAD_ALL = [c["id"] for c in keep]          # declared on the page for the self-audit
    # ALL of them travel to the page — the bar shows four and "and N more"
    # EXPANDS to the rest in place (ledger #115, the client: "6 more doesn't
    # expand"). A count you cannot open is a locked door with a sign on it.
    for c in keep:
        d8 = _pretty_date(c["published"])
        c["name"] = ((c["label"] or c["series"] or c["region"] or "ADF&G announcement")
                     + (" \u00b7 " + d8 if d8 else ""))
        c["total"] = total
    return keep


UNREAD_ALL = []
UNREAD = _unread_announcements()
D=json.load(open("regions_data.json", encoding="utf-8"))
DATA_JSON=json.dumps(D,separators=(",",":"))

HTML = r'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Alaska Salmon Openings</title>
<!-- THE PAGE CARRIES THE ENGINE THAT BUILT IT (axiom 33): the app compares
     this against its own VERSION at startup and rebuilds if they differ, so a
     freshly upgraded app can never serve or publish its predecessor's page. -->
<meta name="afo-engine" content="__ENGINE__">
<style>
:root{
  --bg:#eef1f3; --surface:#ffffff; --surface2:#f7f9fa; --ink:#101d25; --muted:#5c6c77; --line:#dde5ea;
  --open:#137a3a; --open-bg:#e4f3e9; --open-line:#9cd3ae;
  --closed:#c02626; --closed-bg:#fbe9e9; --closed-line:#e9a8a8;
  --partial:#b4560a; --partial-bg:#fbefe1; --partial-line:#eec49a;
  --upcoming:#2a6db5; --upcoming-bg:#edf3f9; --upcoming-line:#bdd3e6;
  --waterfoot:#8db8d9; --waterfoot-line:#5d8fbb; /* the client-approved chart-blue water
     (v2.2.8 comparison); his "baby blue" complaint was the DARK theme's cyan header, not this (ledger #84) */
  --unknown:#8792a6; --unknown-bg:#eef1f6; --unknown-line:#cdd5e2;
  --none:#7d8c96; --none-bg:#eef2f4; --none-line:#d3dce1;
  --ref:#3f6070; --ref-bg:#e7eef1; --ref-line:#b6cbd6;
  --accent:#0b5563; --accent-ink:#083c47; --water:#e8eef1; --land:#e3e8dd; --land-line:#c9d3c2;
  --aselink:#083c47; /* ink INSIDE the white area-picker pill — the pill's background is
     always white, so its ink must always be dark; in dark mode it goes full black
     (client, ledger #86: "in dark mode, southeast alaska should be in black") */
  --shadow:0 1px 2px rgba(16,29,37,.06),0 2px 8px rgba(16,29,37,.06);
}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){
  --waterfoot:#46565f; --waterfoot-line:#5f7683; /* slate-grey — dark water must not read blue (ledger #84) */
  --bg:#0c1417; --surface:#131f24; --surface2:#0f1a1e; --ink:#eaf2f5; --muted:#9db0b9; --line:#243238;
  --open:#4cc172; --open-bg:#123020; --open-line:#255c3b;
  --closed:#f0736b; --closed-bg:#331616; --closed-line:#6a2a2a;
  --partial:#e8974a; --partial-bg:#331f0d; --partial-line:#6a4622;
  --upcoming:#5fa2e0; --upcoming-bg:#0f2033; --upcoming-line:#264a6e;
  --unknown:#98a2b3; --unknown-bg:#1a2029; --unknown-line:#2c3543;
  --none:#8598a1; --none-bg:#1a262b; --none-line:#2c3c43;
  --accent:#12333d; --accent-ink:#bfe4ec; /* dark petrol header — never a blue banner (ledger #84) */ --water:#0f1b20; --land:#1c2622; --land-line:#2d3b34;
  --aselink:#111; /* black ink in the always-white area-picker pill (ledger #86) */
  --shadow:0 1px 2px rgba(0,0,0,.4);
}}
:root[data-theme="dark"]{
  --waterfoot:#46565f; --waterfoot-line:#5f7683; /* slate-grey — dark water must not read blue (ledger #84) */
  --bg:#0c1417; --surface:#131f24; --surface2:#0f1a1e; --ink:#eaf2f5; --muted:#9db0b9; --line:#243238;
  --open:#4cc172; --open-bg:#123020; --open-line:#255c3b;
  --closed:#f0736b; --closed-bg:#331616; --closed-line:#6a2a2a;
  --partial:#e8974a; --partial-bg:#331f0d; --partial-line:#6a4622;
  --upcoming:#5fa2e0; --upcoming-bg:#0f2033; --upcoming-line:#264a6e;
  --unknown:#98a2b3; --unknown-bg:#1a2029; --unknown-line:#2c3543;
  --none:#8598a1; --none-bg:#1a262b; --none-line:#2c3c43;
  --accent:#12333d; --accent-ink:#bfe4ec; /* dark petrol header — never a blue banner (ledger #84) */ --water:#0f1b20; --land:#1c2622; --land-line:#2d3b34;
  --aselink:#111; /* black ink in the always-white area-picker pill (ledger #86) */
  --shadow:0 1px 2px rgba(0,0,0,.4);
}
*{box-sizing:border-box}
html,body{margin:0}
body{background:var(--bg);color:var(--ink);
  font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
  font-size:15px;line-height:1.45;-webkit-text-size-adjust:100%}
.wrap{max-width:1180px;margin:0 auto;padding:0 16px 64px}

/* header */
header{position:sticky;top:0;z-index:20;background:var(--accent);color:#fff;
  box-shadow:0 2px 10px rgba(0,0,0,.12)}
.hd{max-width:1180px;margin:0 auto;padding:12px 16px 0}
.h-title{display:flex;align-items:baseline;gap:10px;flex-wrap:wrap}
.h-title h1{font-size:19px;margin:0;font-weight:800;letter-spacing:.2px}
.h-title .sub{font-size:12.5px;opacity:.85;font-weight:500}
.verchip{font-size:11px;font-weight:750;letter-spacing:.02em;border-radius:99px;
  padding:2px 8px;border:1px solid rgba(255,255,255,.35);background:rgba(255,255,255,.12);
  color:#fff;white-space:nowrap;font-variant-numeric:tabular-nums}
.asof{margin-left:auto;font-size:12px;opacity:.9;font-variant-numeric:tabular-nums}
.asof b{font-weight:700}
.areasel{font:inherit;font-weight:700;font-size:14px;color:var(--aselink);background:#fff;border:0;border-radius:8px;padding:5px 10px;cursor:pointer}
.areabanner{background:var(--surface);border:1px solid var(--line);border-left:4px solid var(--partial);color:var(--muted);border-radius:10px;padding:10px 14px;margin:14px 0 0;font-size:13px;font-weight:500;box-shadow:var(--shadow)}
.areabanner b{color:var(--ink)}
.gearrow{display:flex;gap:6px;margin:10px 0 0;flex-wrap:wrap}
.gearbtn{appearance:none;border:0;background:rgba(255,255,255,.14);color:#fff;
  font:inherit;font-weight:650;font-size:13.5px;padding:8px 15px;border-radius:9px 9px 0 0;cursor:pointer;
  display:flex;align-items:center;gap:7px}
.gearbtn .n{font-size:11.5px;background:rgba(255,255,255,.22);border-radius:20px;padding:1px 7px;font-variant-numeric:tabular-nums}
.gearbtn[aria-selected="true"]{background:var(--bg);color:var(--ink)}
/* THE TAB NUMBER IS AN OPENING COUNT, NEVER A COVERAGE COUNT (ledger #93).
   Green = open right now. Blue = announced to open. Grey 0 = nothing open
   and nothing announced. A captain reads this number as "places I can
   fish", so it wears the colour of the state it reports. */
.gearbtn .n.n-open{background:var(--open);color:#fff}
.gearbtn .n.n-up{background:var(--upcoming);color:#fff}
.gearbtn .n.n-zero{background:rgba(255,255,255,.20);color:#fff;font-weight:600}
.gearbtn[aria-selected="true"] .n.n-zero{background:var(--line);color:var(--muted)}

/* controls */
.controls{display:flex;gap:10px;align-items:center;flex-wrap:wrap;padding:14px 0 4px}
.seg{display:inline-flex;background:var(--surface2);border:1px solid var(--line);border-radius:9px;overflow:hidden}
.seg button{appearance:none;border:0;background:transparent;color:var(--muted);font:inherit;font-weight:600;
  font-size:13px;padding:7px 13px;cursor:pointer}
.seg button[aria-pressed="true"]{background:var(--surface);color:var(--ink);box-shadow:var(--shadow)}
select,.search{font:inherit;font-size:13.5px;padding:8px 11px;border:1px solid var(--line);border-radius:9px;
  background:var(--surface);color:var(--ink)}
.search{min-width:170px}
.spacer{flex:1}
.pins{display:flex;align-items:center;gap:8px;flex-wrap:wrap;padding:10px 0 2px}
.pins-lab{font-size:12.5px;color:var(--muted);font-weight:600}
.pinchip{appearance:none;border:1px solid var(--line);background:var(--surface);color:var(--muted);font:inherit;font-size:12.5px;font-weight:600;padding:5px 10px;border-radius:20px;cursor:pointer}
.pinchip[aria-pressed="true"]{background:var(--accent);color:#fff;border-color:var(--accent)}
.pinchip[aria-pressed="true"]::before{content:"\2605 ";font-size:11px}
.pinned-hd{grid-column:1/-1;font-size:12px;font-weight:800;text-transform:uppercase;letter-spacing:.5px;color:var(--accent);margin:4px 0 -4px;display:flex;align-items:center;gap:8px}
.pinned-hd::after{content:"";flex:1;height:1px;background:var(--line)}
.legend{display:flex;gap:14px;flex-wrap:wrap;font-size:12.5px;color:var(--muted);padding:2px 0 0}
.legend span{display:inline-flex;align-items:center;gap:6px}
.dot{width:11px;height:11px;border-radius:3px;display:inline-block}
.d-open{background:var(--open)}.d-closed{background:var(--closed)}.d-partial{background:var(--partial)}.d-upcoming{background:var(--upcoming)}.d-unknown{background:var(--unknown)}.d-none{background:var(--none)}

/* summary */
.summary{display:flex;gap:10px;flex-wrap:wrap;padding:12px 0 2px}
.stat{flex:1;min-width:120px;background:var(--surface);border:1px solid var(--line);border-radius:12px;padding:12px 14px;box-shadow:var(--shadow)}
.stat .big{font-size:26px;font-weight:800;line-height:1;font-variant-numeric:tabular-nums}
.stat .lab{font-size:12px;color:var(--muted);margin-top:5px;font-weight:600;text-transform:uppercase;letter-spacing:.4px}
.stat.open .big{color:var(--open)} .stat.partial .big{color:var(--partial)}
.stat.closed .big{color:var(--closed)} .stat.none .big{color:var(--none)} .stat.ref .big{color:var(--ref)} .stat.upcoming .big{color:var(--upcoming)} .stat.unknown .big{color:var(--unknown)}

/* grid */
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:14px;padding:16px 0 0}
.card{background:var(--surface);border:1px solid var(--line);border-radius:14px;overflow:hidden;box-shadow:var(--shadow);
  display:flex;flex-direction:column;cursor:pointer;transition:transform .08s ease,box-shadow .08s ease}
.card:hover{transform:translateY(-2px);box-shadow:0 6px 18px rgba(16,29,37,.12)}
.card.s-open{border-color:var(--open-line)} .card.s-closed{border-color:var(--closed-line)}
.card.s-partial{border-color:var(--partial-line)} .card.s-none{border-color:var(--none-line)} .card.s-ref{border-color:var(--ref-line)} .card.s-upcoming{border-color:var(--upcoming-line)} .card.s-unknown{border-color:var(--unknown-line)}
.map{position:relative;aspect-ratio:16/10;background:var(--water);border-bottom:1px solid var(--line)}
.map svg{position:absolute;inset:0;width:100%;height:100%}
.statusband{position:absolute;left:10px;top:10px;display:inline-flex;align-items:center;gap:6px;
  padding:4px 10px;border-radius:20px;font-size:12px;font-weight:800;letter-spacing:.3px;text-transform:uppercase;
  box-shadow:0 1px 3px rgba(0,0,0,.15)}
.s-open .statusband{background:var(--open);color:#fff}
.s-closed .statusband{background:var(--closed);color:#fff}
.s-partial .statusband{background:var(--partial);color:#fff}
.s-none .statusband{background:var(--none);color:#fff}
.s-upcoming .statusband{background:var(--upcoming);color:#fff}
.s-unknown .statusband{background:var(--unknown);color:#fff}
.s-ref .statusband{background:var(--ref);color:#fff}
.cbody{padding:11px 13px 13px;display:flex;flex-direction:column;gap:3px}
.cname{font-size:16px;font-weight:750;line-height:1.15}
.cdist{font-size:12px;color:var(--muted);font-weight:600}
.ctime{margin-top:6px;font-size:13.5px;font-weight:650;font-variant-numeric:tabular-nums;display:flex;align-items:center;gap:6px}
.s-open .ctime{color:var(--open)} .s-closed .ctime{color:var(--closed)} .s-partial .ctime{color:var(--partial)} .s-none .ctime{color:var(--muted)} .s-upcoming .ctime{color:var(--upcoming)} .s-unknown .ctime{color:var(--muted)}
.cfoot{margin-top:8px;font-size:11.5px;color:var(--muted);display:flex;gap:8px;flex-wrap:wrap;border-top:1px solid var(--line);padding-top:8px}
.cfoot .eo{font-weight:600}
.empty{padding:60px 20px;text-align:center;color:var(--muted)}

/* detail modal */
.modal{position:fixed;inset:0;background:rgba(8,16,20,.5);display:none;align-items:center;justify-content:center;z-index:50;padding:16px}
.modal.on{display:flex}
.sheet{background:var(--surface);border-radius:16px;max-width:900px;width:100%;max-height:92vh;overflow:auto;box-shadow:0 20px 60px rgba(0,0,0,.35)}
.sheet .shmap{aspect-ratio:3/2;min-height:360px;background:var(--water);position:relative;border-bottom:1px solid var(--line)}
.sheet .shmap svg{position:absolute;inset:0;width:100%;height:100%}
.shbody{padding:18px 20px 22px}
.shbody h2{margin:0 0 2px;font-size:22px}
.zc{position:absolute;left:12px;bottom:12px;display:flex;flex-direction:column;gap:4px;z-index:3}
.zc button{width:34px;height:34px;border:1px solid var(--line);background:var(--surface);color:var(--ink);font-size:18px;font-weight:700;border-radius:8px;cursor:pointer;box-shadow:var(--shadow);line-height:1}
.zhint{position:absolute;right:12px;bottom:12px;font-size:11px;color:var(--muted);background:var(--surface);opacity:.85;padding:3px 8px;border-radius:6px;z-index:3;pointer-events:none}
.shmap svg{touch-action:none}
.shclose{position:absolute;right:12px;top:12px;background:rgba(0,0,0,.35);color:#fff;border:0;border-radius:50%;
  width:34px;height:34px;font-size:18px;cursor:pointer;z-index:2}
.kv{display:flex;gap:10px;padding:9px 0;border-bottom:1px solid var(--line);font-size:14px}
.kv .k{color:var(--muted);min-width:110px;font-weight:600}
.kv .v{font-weight:600;font-variant-numeric:tabular-nums}
.notice{background:var(--partial-bg);border:1px solid var(--partial-line);color:var(--partial);
  border-radius:10px;padding:10px 12px;font-size:12.5px;margin:12px 0 0;font-weight:600}
.pockets{margin:12px 0 0;background:var(--surface2);border:1px solid var(--line);border-radius:10px;padding:12px 14px}.pk-h{font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.4px;color:var(--closed);margin-bottom:6px}.pockets ul{margin:6px 0 0;padding:0;list-style:none} .pockets li{font-size:13.5px;margin:6px 0;font-variant-numeric:tabular-nums;display:flex;gap:9px;align-items:flex-start;line-height:1.35}.pockets .num{flex:none;width:20px;height:20px;border-radius:50%;background:var(--closed);color:#fff;font-weight:800;font-size:12px;display:flex;align-items:center;justify-content:center;margin-top:1px}.pockets .num.tx{background:transparent;color:var(--muted);font-size:16px}.pk-sub{font-size:13px;color:var(--ink);background:var(--open-bg);border:1px solid var(--open-line);border-radius:8px;padding:8px 10px;margin:2px 0 4px}.pk-note{font-size:11.5px;color:var(--muted);margin-top:8px}.foothint{color:var(--muted);font-size:12px;padding:22px 0 0;text-align:center;line-height:1.6}
@media (max-width:640px){ .sheet{max-width:100%;max-height:100vh;border-radius:0} .sheet .shmap{min-height:300px} }
/* area overview map — where each section sits in the area */
.areawrap{margin:16px 0 0;background:var(--surface);border:1px solid var(--line);border-radius:14px;box-shadow:var(--shadow);overflow:hidden}
.areahd{display:flex;align-items:center;gap:10px;padding:11px 14px;border-bottom:1px solid var(--line);flex-wrap:wrap}
.areahd h2{font-size:15.5px;margin:0;font-weight:800}
.areahd h2 .a-area{color:var(--accent)}
.areahd .hint{font-size:12px;color:var(--muted);margin-left:auto}
.areamap{position:relative;background:var(--water);height:min(64vh,600px)}
.areamap svg{width:100%;height:100%;display:block;touch-action:none;cursor:grab}
.amsec{cursor:pointer;transition:fill-opacity .08s}
.amsec:hover{fill-opacity:1}
.amlabel{font-weight:800;fill:var(--ink);paint-order:stroke;stroke:var(--surface);stroke-width:2.6px;stroke-linejoin:round;pointer-events:none;font-variant-numeric:tabular-nums}
.annfull{margin-top:10px;border:1px solid var(--line);border-radius:10px;background:var(--surface2);overflow:hidden}
.annfull>summary{cursor:pointer;padding:9px 12px;font-size:12.5px;font-weight:700;color:var(--accent);list-style:none;display:flex;align-items:center;gap:6px}
.annfull>summary::-webkit-details-marker{display:none}
.annfull>summary::before{content:"\25B8";font-size:11px;transition:transform .12s}
.annfull[open]>summary::before{transform:rotate(90deg)}
.annbody{max-height:46vh;overflow:auto;padding:0 12px 11px;font-size:12.5px;line-height:1.55;color:var(--ink);white-space:pre-wrap;-webkit-overflow-scrolling:touch}
.annmeta{padding:0 12px 9px;font-size:11.5px;color:var(--muted)}
.coordtbl{width:100%;border-collapse:collapse;font-size:12px;margin-top:2px}
.coordtbl td{padding:3px 6px 3px 0;vertical-align:top;border-bottom:1px solid var(--line)}
.coordtbl td.dm{white-space:nowrap;font-weight:600}
.coordtbl td.dec{white-space:nowrap;color:var(--muted);font-variant-numeric:tabular-nums}
.coordtbl tr:last-child td{border-bottom:0}
.cdot{display:inline-block;width:7px;height:7px;border-radius:50%;margin-right:5px;vertical-align:middle}
.chartnames{pointer-events:none}
.chartname text{fill:var(--muted);font-style:italic;paint-order:stroke;stroke:var(--water);stroke-width:2px}
.chartname circle{fill:var(--muted);fill-opacity:0.75}
.amdist{font-weight:800;fill:var(--accent);paint-order:stroke;stroke:var(--surface);stroke-width:3.4px;stroke-linejoin:round;pointer-events:none;text-transform:uppercase;letter-spacing:.5px;opacity:.9}
@media (max-width:560px){ .h-title h1{font-size:17px} .asof{width:100%;margin:4px 0 0} .grid{grid-template-columns:1fr 1fr;gap:10px} .cname{font-size:14.5px} .areamap{height:56vh} }
@media (max-width:380px){ .grid{grid-template-columns:1fr} }
</style>
</head>
<body>
<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>
  <pattern id="permhatch" width="6" height="6" patternTransform="rotate(45)" patternUnits="userSpaceOnUse">
    <rect width="7" height="7" fill="var(--closed)" fill-opacity="0.18"/>
    <line x1="0" y1="0" x2="0" y2="7" stroke="var(--closed)" stroke-width="2.4"/>
  </pattern>
</defs></svg>
<script>/* THEME IS THE USER'S CHOICE (ledger #84): default LIGHT everywhere —
  the same approved look on phone and desktop — with a header toggle like the
  NSRAA tracker; the OS's dark mode never silently restyles the chart again.
  Stamped before first paint so there is no flash. */
(function(){var t=null;try{t=localStorage.getItem("afo_theme")}catch(e){}
/* DARK BY DEFAULT (client, ledger #117: "lets have it start as the dark screen
   with the option to turn it light"). Still the USER'S choice and still
   remembered — only the starting point changed. Ledger #84's rule stands: the
   OS setting never decides this; the app does, and the person can override. */
document.documentElement.dataset.theme=(t==="light")?"light":"dark";})();</script>
<header>
 <div class="hd">
  <div class="h-title">
    <h1>Alaska &mdash; Salmon Openings</h1>
    <select id="areasel" class="areasel" aria-label="Management area"></select>
    <span class="asof">snapshot as of <b id="asof">—</b></span>
    <span class="verchip" id="verchip" title="the version of the app that built this page">v__ENGINE__</span>
    <!-- A LABEL, NOT A SYMBOL (ledger #117, the client: "make it a bit more
         obvious so an old fisherman would have a label to look to"). The button
         says what it will DO — "Light screen" on the dark page, "Dark screen"
         on the light one — in words a person reads without decoding an icon. -->
    <button id="themebtn" aria-label="Switch between light and dark screen" title="Switch between light and dark screen"
      style="appearance:none;border:1.5px solid rgba(255,255,255,.55);background:rgba(255,255,255,.14);color:#fff;border-radius:9px;padding:5px 12px;font:inherit;font-size:13.5px;font-weight:700;letter-spacing:.01em;cursor:pointer;white-space:nowrap;display:inline-flex;align-items:center;gap:7px"><span id="themeglyph" aria-hidden="true" style="font-size:15px;line-height:1">&#9728;</span><span id="themelabel">Light screen</span></button>
  </div>
  <div class="gearrow" id="gearrow" role="tablist"></div>
 </div>
</header>
<div id="unreadbar" hidden style="background:#8a3b00;color:#fff;padding:6px 16px;font-weight:500;font-size:12.5px;line-height:1.45"></div>
<div id="stalebar" hidden style="background:#b3261e;color:#fff;padding:9px 16px;font-weight:700;font-size:13.5px;line-height:1.45"></div>
<div class="wrap">
  <div class="controls">
    <div class="seg" id="filterseg">
      <button data-f="all" aria-pressed="true">All sections</button>
      <button data-f="upcoming">Opening soon</button>
      <button data-f="active">Open / Closed only</button>
    </div>
    <select id="distsel"><option value="">All districts</option></select>
    <input class="search" id="search" placeholder="Find a section…">
    <span class="spacer"></span>
  </div>
  <div class="areabanner" id="areabanner" hidden></div>
  <div class="areabanner" id="fedbanner" hidden style="border-left-color:var(--ref)"></div>
  <div class="pockets upcpanel" id="upcshelf" hidden style="background:var(--surface);border:1px solid var(--line);border-left:4px solid var(--upcoming);border-radius:12px;padding:12px 16px;margin:14px 0 0;box-shadow:var(--shadow)"></div>
  <div class="pins" id="pins"><span class="pins-lab">Pin your districts:</span><span id="pinchips"></span></div>
  <div class="legend">
    <span><i class="dot d-open"></i>Open</span>
    <span><i class="dot d-partial"></i>Partly open</span>
    <span><i class="dot d-closed"></i>Closed</span>
    <span><i class="dot d-upcoming"></i>Opens soon</span>
    <span><i class="dot d-unknown"></i>No current announcement</span>
    <span><i class="dot d-none"></i>No opening announced</span>
    <span><svg width="12" height="12" style="border-radius:2px"><rect width="12" height="12" fill="url(#permhatch)" stroke="var(--closed)" stroke-width="1"/></svg>Permanent closed waters</span>
  </div>
  <div class="summary" id="summary"></div>
  <section class="areawrap">
    <div class="areahd">
      <h2>Where each <span id="am-unit">section</span> sits &mdash; <span class="a-area" id="am-area">Southeast Alaska</span></h2>
      <span class="hint">tap a section to open it &middot; scroll / pinch to zoom &middot; drag to pan</span>
    </div>
    <div class="areamap" id="areamap"></div>
  </section>
  <!-- hatchery terminal-area advisories read AFTER the regional map, every
       area (client call: orient on the chart first, then the pocket words) -->
  <div class="pockets" id="thashelf" hidden style="background:var(--surface);border:1px solid var(--line);border-left:4px solid var(--closed);border-radius:12px;padding:12px 16px;margin:14px 0 0;box-shadow:var(--shadow)"></div>
  <div class="grid" id="grid"></div>
  <div class="empty" id="empty" hidden>No sections match.</div>
  <div class="foothint">
    Boundaries: ADF&amp;G official 5&nbsp;AAC&nbsp;33 salmon section polygons (offline). Status from ADF&amp;G emergency-order announcements.<br>
    A snapshot for planning &mdash; <b>confirm against the current ADF&amp;G announcement before setting gear.</b>
    <span id="publink" hidden> &middot; <a href="/publish">Auto-publish settings</a> (push this map to your public phone page on every refresh)</span>
  </div>
  <script>/* the settings link exists only when served by the DESKTOP APP —
    never on the public phone page itself */
    if(location.hostname==="127.0.0.1"){ const pl=document.getElementById("publink"); if(pl) pl.hidden=false; }</script>
</div>

<div class="modal" id="modal"><div class="sheet" id="sheet"></div></div>

<script>
let UNREAD_ALL = __UNREAD_ALL__;
let UNREAD = __UNREAD__;   /* let, not const: the gauntlet drives this banner with a stubbed list */
const DATA_ALL = __DATA__;
const AREAS = DATA_ALL.areas;
let area = "";                                   // "" = the all-Alaska home view
let DATA = DATA_ALL.regions["SE"];               // placeholder until an area is chosen
let GEARS = DATA.gears;
const GEAR_LABEL = {"purse seine":"Seine","drift gillnet":"Drift gillnet","set gillnet":"Set gillnet","troll":"Troll","all":"All gear"};
let ORDER = DATA.section_order;
// THE DEFAULT GEAR IS THE ONE WITH FISHING ON IT (ledger #93). Landing on
// whichever gear an announcement happens to MENTION most is the same lie the
// tab badge told: Area M opens on Seine because 22 sections are named there,
// every one of them closed. Rank by open now, then by announced-to-open, and
// only then fall back to coverage so a fully-closed area still lands somewhere.
function pickGear(){
  const key=g=>{ const t=gearTally(g);
    return t.open*1e6 + t.up*1e3 + Object.keys((DATA.status||{})[g]||{}).length; };
  return GEARS.reduce((a,g)=> key(g)>key(a) ? g : a, GEARS[0]);
}
let gear = pickGear();
function relIn(ms){ // "in 18 h" / "in 2 d 4 h" / "in 40 min" — the countdown a
  // captain positions by
  if(ms<=0) return "now";
  const m=Math.round(ms/60000);
  if(m<60) return "in "+m+" min";
  const h=Math.floor(m/60);
  if(h<24) return "in "+h+" h";
  const d=Math.floor(h/24);
  return "in "+d+" d"+(h%24?" "+(h%24)+" h":"");
}
function upcomingSoon(hours, onlyArea){
  const now=Date.now(), lim=now+hours*3600e3, out=[];
  for(const a of AREAS){ if(onlyArea&&a.key!==onlyArea) continue;
    const R=DATA_ALL.regions[a.key]; if(!R||!R.status) continue;
    for(const g in R.status){ for(const c in R.status[g]){ const r=R.status[g][c];
      if(!r||liveStatus(r)!=="upcoming"||!r.starts) continue;
      const t=new Date(r.starts).getTime(); if(isNaN(t)||t<now-3600e3||t>lim) continue;
      const s=(R.sections||{})[c]||{};
      const d=new Date(t);
      out.push({t, area:a.key, areaLabel:(a.label||"").replace(/\s*\(.*\)$/,""), code:c,
        name:s.name||c, gear:g, rel:relIn(t-now),
        when:d.toLocaleDateString(undefined,{weekday:"short"})+" "+d.toLocaleTimeString(undefined,{hour:"numeric",minute:"2-digit"})});
    } } }
  // hatchery terminal-area pockets announced to open at a future datetime are
  // opens-soon too — a captain positions on Anita Bay's Sept 1 opener exactly
  // like a section opener (client call, ledger #73). Advisory rows carry
  // tha:true and no section code; they never paint a section.
  for(const a of AREAS){ if(onlyArea&&a.key!==onlyArea) continue;
    const R=DATA_ALL.regions[a.key]; if(!R) continue;
    for(const n of (R.tha_notes||[])){
      if(!n||!n.starts) continue;
      const t=new Date(n.starts).getTime(); if(isNaN(t)||t<now-3600e3||t>lim) continue;
      const d=new Date(t);
      out.push({t, area:a.key, areaLabel:(a.label||"").replace(/\s*\(.*\)$/,""), code:null, tha:true,
        name:n.name+" THA", gear:n.gear||"", rel:relIn(t-now),
        when:d.toLocaleDateString(undefined,{weekday:"short"})+" "+d.toLocaleTimeString(undefined,{hour:"numeric",minute:"2-digit"})});
    } }
  out.sort((x,y)=>x.t-y.t||String(x.name).localeCompare(String(y.name)));
  return out;
}
function setArea(k,_nohist){ area=k;
  if(k){ DATA=DATA_ALL.regions[k]; GEARS=DATA.gears; ORDER=DATA.section_order; gear=pickGear(); }
  dist=""; q="";
  const ds=document.getElementById("distsel"); if(ds){ds.innerHTML='<option value="">All '+(DATA.unit_label==="Section"?"districts":"areas")+'</option>'; ds.dataset.built=""; ds.dataset.builtFor="";}
  render(); focusMap(); if(!_nohist) navPush(); }

// THE CHART IS WHAT THE CAPTAIN CAME FOR (ledger #89). Entering an area used to
// land him on the filter chips, the federal-waters notice and the opening-soon
// board, with the map itself below the fold — he had to scroll to see the one
// thing he opened the area for. Landing now puts the chart directly under the
// sticky header, every area, and every step back: back to an area lands on that
// area's chart, back to the top lands on Alaska. Nothing is removed — the
// filters and boards are one scroll up, exactly where they were.
let _focusTok=0;
// A DEFERRED SCROLL MUST NEVER MOVE THE PAGE UNDER A FINGER (ledger #89, caught
// by the gauntlet): the settle-passes below fire 60 ms and 240 ms after landing,
// and a captain who taps an area inside that window would have the chart slide
// out from under his thumb — the tap lands on open water. Any real input voids
// the pending passes; the immediate scroll has already happened by then.
["pointerdown","touchstart","wheel","keydown"].forEach(function(ev){
  addEventListener(ev, function(){ _focusTok++; }, {passive:true, capture:true}); });
function focusMap(){
  const card=document.querySelector(".areawrap"); if(!card) return;
  const tok=++_focusTok;
  let h0=-1;                              // the page height this landing last saw
  const go=function(first){
    if(tok!==_focusTok) return;          // superseded by a later landing or a real tap
    // ...and a settle-pass only ever corrects ITS OWN scroll. If the page has
    // moved since we placed it — the captain scrolled, or anything else did —
    // the landing is over and we leave the view exactly where he put it.
    // A pass stops the moment the chart is actually in place, and every later
    // pass for this landing is cancelled with it. That is what keeps a settle
    // pass from ever fighting a scroll someone else makes afterwards — while
    // still letting it CORRECT itself when the layout moves under it, which is
    // exactly what happens stepping back to all-of-Alaska: the header shrinks
    // (no gear tabs) and the page shortens, so the first scroll overshoots and
    // the captain lands below the map. (Caught on the live site, ledger #92.)
    const hdr=document.querySelector("header");
    const off=(hdr?hdr.getBoundingClientRect().height:0)+6;
    const top=card.getBoundingClientRect().top;
    const h=document.documentElement.scrollHeight;
    if(Math.abs(top-off)<=8){ h0=h; return; }   // in place: leave it, keep watching
    // OFF TARGET — and only ONE of two things can have done that. If the page
    // itself reflowed (this map is megabytes of SVG; stepping home also drops
    // the gear tabs, so the header shrinks and everything shifts), the landing
    // is still in progress and we correct it. If the page has NOT changed
    // height, then something else moved the view — the captain scrolled, or
    // reached for a section — and we take our hands off for good.
    if(!first && h===h0){ _focusTok++; return; }
    h0=h;
    const y=top + (window.pageYOffset||document.documentElement.scrollTop||0) - off;
    try{ window.scrollTo(0, Math.max(0, Math.round(y))); }catch(e){}
  };
  // the sheet is a modal over a locked page; scrolling under it would be wrong
  const modal=document.getElementById("modal");
  if(modal&&modal.classList.contains("on")) return;
  go(true);                               // now, before a frame is even asked for
  setTimeout(go,60); setTimeout(go,240);  // and again as the map's layout settles,
  setTimeout(go,600); setTimeout(go,1200);// through to the last reflow of a big chart
}

// THE BACK BUTTON IS A REAL CONTROL (ledger #89). The whole app lives at one
// URL, so entering an area and opening a section changed nothing the browser
// knew about \u2014 back walked the captain off the site instead of out one level.
// Every move now writes a history entry: section \u2192 back \u2192 the area \u2192 back \u2192
// all of Alaska. Phone back-swipe, browser back button and the sheet's \u00d7 all
// travel the same path, because the \u00d7 pops history rather than just hiding.
let _openCode=null, _hist=false;
function navPush(){ if(_hist) return;
  try{ history.pushState({v:"afo",area:area,code:_openCode}, "", location.pathname+location.search+location.hash); }catch(e){} }
// WE OWN WHERE EVERY HISTORY ENTRY LANDS (ledger #92, proven on the live site).
// With the browser's default "auto" restoration it re-applies the scroll each
// entry had LAST time and does it AFTER popstate — so the landing scrolled the
// chart into place and the browser then threw the captain 452 px down the page,
// below the map, every time he stepped back to all-of-Alaska. Our own scroll is
// the correct one for these entries, because we place it on the chart.
try{ if("scrollRestoration" in history) history.scrollRestoration="manual"; }catch(e){}
try{ history.replaceState({v:"afo",area:null,code:null}, "", location.pathname+location.search+location.hash); }catch(e){}
addEventListener("popstate", function(e){
  const stt=(e.state&&e.state.v==="afo")?e.state:{v:"afo",area:null,code:null};
  _hist=true;
  try{
    if(_openCode && stt.code!==_openCode) closeDetail(true);
    if((stt.area||null)!==(area||null)) setArea(stt.area||null, true);
    if(stt.code && stt.code!==_openCode) openDetail(stt.code, true);
    else if(!stt.code) focusMap();
  }catch(err){}
  _hist=false;
});
let filter="all", dist="", q="";
let pins=new Set(); try{pins=new Set(JSON.parse(localStorage.getItem("se_pins")||"[]"));}catch(e){}
function savePins(){ try{localStorage.setItem("se_pins",JSON.stringify([...pins]));}catch(e){} }
function districtsList(){ return [...new Set(ORDER.filter(c=>gearOK(c)).map(c=>DATA.sections[c].district_name))]
  .sort((a,b)=>{const na=parseInt((a.match(/\d+/)||[999])[0]),nb=parseInt((b.match(/\d+/)||[999])[0]);return na-nb;}); }

function fmtAsOf(s){ if(!s) return "—"; const d=new Date(s); if(isNaN(d)) return s.slice(0,10);
  return d.toLocaleDateString(undefined,{month:"short",day:"numeric"})+", "+d.toLocaleTimeString(undefined,{hour:"numeric",minute:"2-digit"}); }
function areaLive(){ const a=AREAS.find(x=>x.key===area); return a?a.status_live!==false:true; }
// THE CLOCK IS JUDGED WHEN THE PAGE IS READ, NOT WHEN IT WAS BUILT
// (axiom 36, ledger #105). This page is a published snapshot: the cloud
// refresh runs every two hours, so even a perfectly built page is up to two
// hours old the moment a captain opens it — and if publishing stalls it can be
// days old. A stored "open" is therefore a claim about the BUILD's clock, and
// the captain is reading it on his own. Every displayed status is re-derived
// here, in his browser, from the window's own timestamps against HIS clock:
// before the start it is UPCOMING, after the end it is CLOSED, and only
// between them is it open. A page that cannot reach the network still cannot
// show a fishery open that closed an hour ago.
function liveStatus(r){
  if(!r) return null;
  const st=r.status;
  if(st!=="open"&&st!=="partial"&&st!=="upcoming") return st;
  const now=Date.now();
  const s=r.starts?new Date(r.starts).getTime():null;
  const e=r.ends?new Date(r.ends).getTime():null;
  // RE-DERIVATION ONLY EVER MOVES TOWARD THE SAFE DIRECTION (axiom 36 cl. 4).
  // An earlier draft of this function also promoted a stored "upcoming" to
  // "open" once its start had passed. That would have manufactured a wrong
  // opening on the weekly fisheries: a Tuesday/Friday fishery is stored
  // "upcoming" on a Wednesday while its ENVELOPE (June–September) is wide
  // open, so the promotion would paint it green on a day nobody may fish it.
  // The window on a record is the envelope, not today's period — so the clock
  // may CLOSE a status here, and may hold one back, but may never open one.
  // A missed opening costs a day; a wrong opening costs a citation.
  if(e&&isFinite(e)&&e<now) return "closed";
  if(s&&isFinite(s)&&s>now) return "upcoming";
  // A WEEKLY FISHERY IS JUDGED ON THE DAY AND THE HOUR (axiom 36, ledger #108).
  // "Tuesdays and Fridays from 7:00 a.m. until 7:00 p.m." has no date window to
  // compare — the status was computed once at build time and then froze, so
  // Chinitna Bay read OPEN one minute after its Friday period closed and would
  // have read open all weekend. The recurrence now travels with the record and
  // is evaluated here, in ALASKA time (the times in an EO are Alaska local, and
  // the captain may be reading from anywhere).
  if(r.weekly&&Array.isArray(r.weekly.days)&&(st==="open"||st==="partial")){
    try{
      const f=new Intl.DateTimeFormat("en-US",{timeZone:"America/Anchorage",
        weekday:"short",hour:"2-digit",minute:"2-digit",hour12:false});
      const parts={}; for(const p of f.formatToParts(new Date(now))) parts[p.type]=p.value;
      const wd={Mon:0,Tue:1,Wed:2,Thu:3,Fri:4,Sat:5,Sun:6}[parts.weekday];
      const mins=parseInt(parts.hour,10)*60+parseInt(parts.minute,10);
      const [fh,fm]=String(r.weekly.from||"00:00").split(":").map(Number);
      const [th,tm]=String(r.weekly.to||"23:59").split(":").map(Number);
      const lo=fh*60+fm, hi=th*60+tm;
      const today=r.weekly.days.indexOf(wd)>=0;
      const inside=(lo<=hi)?(mins>=lo&&mins<=hi):(mins>=lo||mins<=hi);
      if(!(today&&inside)) return "upcoming";
    }catch(err){ return "upcoming"; }   // cannot verify the hour -> do not claim open
  }
  return st;
}
function statusOf(code){ if(!areaLive()) return "ref"; const r=(DATA.status[gear]||{})[code]; return r? liveStatus(r) : (DATA.comprehensive===false?"unknown":"none"); }
function recOf(code){ return (DATA.status[gear]||{})[code] || null; }
// the same rule for any code path that reads a record's status directly
function recStatus(r){ return liveStatus(r); }

// THE TAB NUMBER COUNTS OPENINGS, NEVER COVERAGE (ledger #93, the client:
// "it says seine 16 ... there is only 8 ... those numbers should read 0
// unless their announcements are showing something open or something about
// to open"). How many sections an announcement happens to MENTION is not a
// reason to open the app; printing that as the tab number announces
// openings that do not exist — the one failure this build exists to make
// impossible. So: open now (open or partly open) if there are any; else the
// count announced to open (including a hatchery pocket with a future start
// under this gear, the same signal the home digest counts); else 0.
function gearTally(g){
  const out={open:0,up:0};
  if(!areaLive()) return out;
  const st=(DATA.status||{})[g]||{};
  for(const c of ORDER){
    const s=DATA.sections[c]; if(s&&s.gears&&!s.gears.includes(g)) continue;
    const r=st[c]; if(!r) continue;
    const ls=liveStatus(r);
    if(ls==="open"||ls==="partial") out.open++;
    else if(ls==="upcoming") out.up++;
  }
  const now=Date.now();
  for(const n of (DATA.tha_notes||[])){
    if(!n||!n.starts) continue;
    if(n.gear && String(n.gear).split(/\s*,\s*/).indexOf(g)<0) continue;
    const t=new Date(n.starts).getTime();
    if(isFinite(t)&&t>now) out.up++;
  }
  return out;
}

// --- metric projection (x scaled by cos(lat)) so clipping is correct ---
function makeProj(bbox,W,H,pad){
  const k=Math.cos((bbox[1]+bbox[3])/2*Math.PI/180);
  const mminx=bbox[0]*k, mmaxx=bbox[2]*k, mminy=bbox[1], mmaxy=bbox[3];
  const bw=(mmaxx-mminx)||1e-6, bh=(mmaxy-mminy)||1e-6;
  const sc=Math.min((W-2*pad)/bw,(H-2*pad)/bh);
  const ox=(W-sc*bw)/2, oy=(H-sc*bh)/2;
  return {k, toM:p=>[p[0]*k,p[1]], X:m=>ox+(m[0]-mminx)*sc, Y:m=>oy+(mmaxy-m[1])*sc,
          pb:[ox,oy,sc*bw,sc*bh]};   // the pixel rect the fitted bbox occupies
}
function vbFit(pr,W,H,m){ // OPENING VIEW = THE CONTENT (ledger #87): crop the
  // initial viewBox to the rectangle the projection actually filled, so every
  // map opens zoomed-and-centered on its area instead of floating small
  // inside the canvas's dead margins (the client's phone screenshots:
  // "slightly more zoomed in and centered... apply this logic to all areas").
  // Reset and double-tap return to THIS view; pan/zoom work from it.
  const p=pr.pb;
  const x0=Math.max(0,p[0]-m), y0=Math.max(0,p[1]-m);
  const x1=Math.min(W,p[0]+p[2]+m), y1=Math.min(H,p[1]+p[3]+m);
  return [x0,y0,x1-x0,y1-y0].map(n=>+n.toFixed(1));
}
// CHART NAMES (ledger #87): the client's ask — "point names and bay names,
// easily grabbed off a chart, something to give more context for captains."
// GNIS capes/bays (via ADF&G's own GNIS service, byte-verified) ride each
// region as DATA.chart_names [[name,kind,lat,lon],...]. Drawn as small
// italic labels with a dot — the chart convention — decluttered greedily
// (shortest names first, min pixel spacing, clear of section-label anchors),
// pointer-events:none so a tap always reaches the water under them.
function chartNameLayer(pr,CV,opts){
  const rows=(DATA.chart_names||[]); if(!rows.length) return "";
  const minD=opts.minD||64, cap=opts.cap||28, fs=opts.fs||8;
  const taken=(opts.taken||[]).map(t=>[t[0],t[1],30]);
  const cand=rows.slice().sort((a,b)=>a[0].length-b[0].length||(a[0]<b[0]?-1:1));
  let out="",n=0;
  for(const r of cand){
    if(n>=cap) break;
    const m=pr.toM([r[3],r[2]]), x=pr.X(m), y=pr.Y(m);
    if(x<CV[0]+8||x>CV[0]+CV[2]-8||y<CV[1]+10||y>CV[1]+CV[3]-6) continue;
    let ok=true;
    for(const t of taken){ if(Math.hypot(x-t[0],y-t[1])<(t[2]||minD)){ok=false;break;} }
    if(!ok) continue;
    taken.push([x,y,minD]);
    out+=`<g class="chartname"><circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="1.6"/><text x="${(x+3.2).toFixed(1)}" y="${(y+3).toFixed(1)}" font-size="${fs}">${r[0].replace(/&/g,"&amp;").replace(/</g,"&lt;")}</text></g>`;
    n++;
  }
  return out?`<g class="chartnames">${out}</g>`:"";
}
function ringPath(ringM,pr){let d="M";for(let i=0;i<ringM.length;i++){d+=(i?"L":"")+pr.X(ringM[i]).toFixed(2)+" "+pr.Y(ringM[i]).toFixed(2);}return d+"Z";}
function polysPath(polys,pr){return polys.map(poly=>poly.map(r=>ringPath(r.map(pr.toM),pr)).join(" ")).join(" ");}
function clipRing(ringM,a,n){ // keep half-plane dot(p-a,n)>=0 (Sutherland-Hodgman)
  const N=ringM.length; if(!N) return []; const out=[];
  const ins=p=>(p[0]-a[0])*n[0]+(p[1]-a[1])*n[1]>=0;
  const isect=(p,q)=>{const dp=(p[0]-a[0])*n[0]+(p[1]-a[1])*n[1],dq=(q[0]-a[0])*n[0]+(q[1]-a[1])*n[1],t=dp/(dp-dq);return [p[0]+t*(q[0]-p[0]),p[1]+t*(q[1]-p[1])];};
  for(let i=0;i<N;i++){const cur=ringM[i],prev=ringM[(i+N-1)%N],ci=ins(cur),pi=ins(prev);
    if(ci){if(!pi)out.push(isect(prev,cur));out.push(cur);}else if(pi){out.push(isect(prev,cur));}}
  return out;
}
function sideNormal(a,b,side){
  const dx=b[0]-a[0],dy=b[1]-a[1]; const n1=[-dy,dx],n2=[dy,-dx]; let t=[0,0]; const sd=(side||"").toLowerCase();
  if(sd.includes("north"))t[1]+=1; if(sd.includes("south"))t[1]-=1; if(sd.includes("east"))t[0]+=1; if(sd.includes("west"))t[0]-=1;
  if(!t[0]&&!t[1])t=[0,1]; const dot=(u,v)=>u[0]*v[0]+u[1]*v[1];
  return dot(n1,t)>=dot(n2,t)?n1:n2;
}
function clippedPieces(section,rule,pr){
  if(!rule.pts||rule.pts.length<2) return [];
  const a=pr.toM(rule.pts[0]), b=pr.toM(rule.pts[1]); const n=sideNormal(a,b,rule.side); const paths=[];
  for(const poly of section.polys){ const cl=clipRing(poly[0].map(pr.toM),a,n); if(cl.length>=3) paths.push(ringPath(cl,pr)); }
  return paths;
}
function districtBBox(distName){
  let b=[999,999,-999,-999];
  for(const c of ORDER){const s=DATA.sections[c];if(s.district_name!==distName)continue;
    b=[Math.min(b[0],s.bbox[0]),Math.min(b[1],s.bbox[1]),Math.max(b[2],s.bbox[2]),Math.max(b[3],s.bbox[3])];}
  return b;
}
const COLOR={open:"var(--open)",closed:"var(--closed)",partial:"var(--partial)",upcoming:"var(--upcoming)",unknown:"var(--unknown)",none:"var(--none)",ref:"var(--ref)"};
function sectionBBox(code){ const b=DATA.sections[code].bbox.slice();
  const px=(b[2]-b[0])*0.12+1e-4, py=(b[3]-b[1])*0.12+1e-4; return [b[0]-px,b[1]-py,b[2]+px,b[3]+py]; }
function centroidPx(ringM,pr){ let x=0,y=0; for(const m of ringM){x+=pr.X(m);y+=pr.Y(m);} return [x/ringM.length,y/ringM.length]; }
function drawMap(code,W,H,opts){
  opts=opts||{}; const detail=!!opts.detail;
  if(isRef()) return drawRefMap(W,H,code);
  const s=DATA.sections[code], dn=s.district_name;
  if(!(s.polys&&s.polys.length)){
    // a regulation-defined unit with anchor points but no polygon (Area M
    // sections): its dots and coordinate lines over the area's own polygons
    // and the coast, never a fabricated fill
    const pts=(s.points||[]).filter(p=>p.lon!=null&&p.lat!=null);
    let bb=s.bbox||DATA.bbox;
    if(!s.bbox&&pts.length){ const xs=pts.map(p=>p.lon), ys=pts.map(p=>p.lat);
      const px=Math.max(0.35,(Math.max(...xs)-Math.min(...xs))*0.8), py=Math.max(0.2,(Math.max(...ys)-Math.min(...ys))*0.8);
      bb=[Math.min(...xs)-px,Math.min(...ys)-py,Math.max(...xs)+px,Math.max(...ys)+py]; }
    const pr=makeProj(bb,W,H,detail?14:8);
    let out=landPaths(pr, DATA.land);
    for(const c2 of ORDER){ const t=DATA.sections[c2]; if(!(t.polys&&t.polys.length)) continue;
      out+=`<path d="${polysPath(t.cpolys||t.polys,pr)}" fill="var(--none-bg)" fill-opacity="0.5" stroke="var(--none-line)" stroke-width="0.8"/>`; }
    const st=statusOf(code);
    for(const ln of (s.lines||[])){ let d="M"; ln.forEach((pt,i)=>{const m=pr.toM(pt); d+=(i?"L":"")+pr.X(m).toFixed(1)+" "+pr.Y(m).toFixed(1);});
      out+=`<path d="${d}" fill="none" stroke="${COLOR[st]}" stroke-width="${detail?2.6:1.8}"/>`; }
    let labels="";
    pts.forEach(p=>{ const m=pr.toM([p.lon,p.lat]);
      out+=`<circle cx="${pr.X(m).toFixed(1)}" cy="${pr.Y(m).toFixed(1)}" r="${detail?5:3.4}" fill="${COLOR[st]}" stroke="#fff" stroke-width="1"/>`;
      if(detail&&p.name) labels+=`<text x="${pr.X(m).toFixed(1)}" y="${(pr.Y(m)-8).toFixed(1)}" text-anchor="middle" font-size="10" fill="var(--ink)">${p.name}</text>`; });
    const CV=vbFit(pr,W,H,detail?14:12);
    const cn=detail?chartNameLayer(pr,CV,{minD:52,cap:18,fs:9}):"";
    return `<svg viewBox="${CV.join(" ")}" preserveAspectRatio="xMidYMid meet">${out}${cn}${labels}</svg>`;
  }
  const bb = detail ? sectionBBox(code) : districtBBox(dn);
  const pr=makeProj(bb,W,H,detail?14:8);
  let out="";
  for(const c of ORDER){const t=DATA.sections[c];if(t.district_name!==dn||c===code)continue;
    const tg=t.cpolys||t.polys; if(!(tg&&tg.length)) continue;   // mixed areas: dot-only siblings have no polygon
    out+=`<path d="${polysPath(tg,pr)}" fill="var(--none-bg)" stroke="var(--none-line)" stroke-width="0.8"/>`;}
  const st=statusOf(code), rec=recOf(code);
  const rules=(rec&&rec.rules)?rec.rules:[];
  const openR=rules.filter(r=>r.status==="open"&&r.pts&&r.pts.length>=2);
  const closedR=rules.filter(r=>r.status==="closed"&&r.pts&&r.pts.length>=2);
  // an OPEN boundary rule means the rest is closed -> base closed
  let base=st; if(st==="partial") base=openR.length?"closed":"open";
  out+=`<path d="${polysPath((detail?s.polys:s.cpolys)||s.polys,pr)}" fill="${COLOR[base]}" fill-opacity="${base==='none'?0.32:0.8}" stroke="${COLOR[st]}" stroke-width="1.5"/>`;
  let labels="";
  if(st==="partial"){
    // paint the OPEN side green — never for a geo-attached (foreign) line
    for(const rule of openR){ if(rule.attached) continue;
      for(const pth of clippedPieces(s,rule,pr)) out+=`<path d="${pth}" fill="var(--open)" fill-opacity="0.82"/>`; }
  } else if(openR.length){
    // not open right now (upcoming/closed) but the EO limits WHERE fishing
    // occurs when it is — draw the boundary line only, never a green fill
    // that would read as open water today.
    for(const rule of openR){ const a=pr.toM(rule.pts[0]),b=pr.toM(rule.pts[1]);
      out+=`<line x1="${pr.X(a).toFixed(1)}" y1="${pr.Y(a).toFixed(1)}" x2="${pr.X(b).toFixed(1)}" y2="${pr.Y(b).toFixed(1)}" stroke="var(--open)" stroke-width="${detail?2.6:1.8}" stroke-dasharray="6 3" stroke-linecap="round"/>`; }
  }
  if(st==="partial"||closedR.length){
    // paint each CLOSED pocket; FILL only unambiguous single-cardinal sides (diagonal/compound -> line only, never a possibly-wrong fill)
    closedR.forEach((rule,i)=>{
      let big=null,bigN=0;
      const a=pr.toM(rule.pts[0]),b=pr.toM(rule.pts[1]);
      // never FILL from a geo-attached (foreign) rule — Lost River's markers
      // drawn on the Yakutat District close only ITS waters; extending that
      // short line across the whole host and flooding one side red would
      // paint open-scheduled water closed. Line + number + words only.
      const single=!rule.attached&&/^(north|south|east|west)$/.test((rule.side||'').trim().toLowerCase());
      if(single){ const n=sideNormal(a,b,rule.side);
        for(const poly of s.polys){ const cl=clipRing(poly[0].map(pr.toM),a,n);
          if(cl.length>=3){ out+=`<path d="${ringPath(cl,pr)}" fill="var(--closed)" fill-opacity="0.85"/>`; if(cl.length>bigN){bigN=cl.length;big=cl;} } } }
      out+=`<line x1="${pr.X(a).toFixed(1)}" y1="${pr.Y(a).toFixed(1)}" x2="${pr.X(b).toFixed(1)}" y2="${pr.Y(b).toFixed(1)}" stroke="var(--closed)" stroke-width="${detail?2.6:1.8}" stroke-linecap="round"/>`;
      const lc = big?centroidPx(big,pr):[(pr.X(a)+pr.X(b))/2,(pr.Y(a)+pr.Y(b))/2];
      if(detail){ labels+=`<g><circle cx="${lc[0].toFixed(1)}" cy="${lc[1].toFixed(1)}" r="11" fill="#fff" stroke="var(--closed)" stroke-width="2"/><text x="${lc[0].toFixed(1)}" y="${(lc[1]+4).toFixed(1)}" text-anchor="middle" font-size="13" font-weight="800" fill="var(--closed)">${i+1}</text></g>`; }
    });
  }
  const cwd=(DATA.closed_waters||{})[code]||[];
  for(const c of cwd){ out+=`<path d="${polysPath(c.polys,pr)}" fill="url(#permhatch)" stroke="#7d1414" stroke-width="${detail?2:1.2}" stroke-dasharray="${detail?'5 2':'2 1.5'}"/>`; }
  const defs=`<defs><pattern id="permhatch" width="6" height="6" patternTransform="rotate(45)" patternUnits="userSpaceOnUse"><rect width="6" height="6" fill="#c02626" fill-opacity="0.28"/><line x1="0" y1="0" x2="0" y2="6" stroke="#7d1414" stroke-width="2.2"/></pattern></defs>`;
  // OPENING VIEW = THE CONTENT applies to the SHEET maps too (the client's
  // 9-B screenshot: the section floated off-center in dead margin) — and the
  // sheet gains its local chart names, denser than the area map.
  const CV=vbFit(pr,W,H,detail?14:12);
  const cn=detail?chartNameLayer(pr,CV,{minD:52,cap:18,fs:9}):"";
  return `<svg viewBox="${CV.join(" ")}" preserveAspectRatio="xMidYMid meet">${defs}${out}${cn}${labels}</svg>`;
}
const miniSVG=(c,W,H)=>drawMap(c,W,H,{detail:false});

function landPaths(pr, polys){
  // the coast under everything — orientation first, then management lines
  let out="";
  for(const poly of (polys||[])){
    for(const ring of poly){
      let d="M"; ring.forEach((pt,i)=>{const m=pr.toM(pt); d+=(i?"L":"")+pr.X(m).toFixed(1)+" "+pr.Y(m).toFixed(1);});
      out+=`<path d="${d}Z" fill="var(--land)"/>`;
    }
  }
  return out;
}
// --- AREA overview map: every section of the area in place, so a captain can
// orient where a section (e.g. 1-F, 9-B) actually is before drilling in. ---
// a section limited to specific gears (the federal EEZ troll unit) appears
// only under its own gear tabs — a seiner must never be shown federal water
const gearOK=c=>{const s=DATA.sections[c];return !s.gears||s.gears.includes(gear);};
function areaBBox(){ let b=[999,999,-999,-999];
  for(const c of ORDER){const s=DATA.sections[c];
    if(s.nofit) continue;    // the EEZ band must not zoom the default view out
    let sb=s.bbox;
    if(!sb&&s.points&&s.points.length){ const xs=s.points.map(p=>p.lon).filter(x=>x!=null), ys=s.points.map(p=>p.lat).filter(y=>y!=null);
      if(xs.length) sb=[Math.min(...xs),Math.min(...ys),Math.max(...xs),Math.max(...ys)]; }
    if(!sb) continue;
    b=[Math.min(b[0],sb[0]),Math.min(b[1],sb[1]),Math.max(b[2],sb[2]),Math.max(b[3],sb[3])];}
  return (b[0]<999)?b:(DATA.bbox||[-180,50,-128,72]); }
function biggestRing(polys){ let best=null,bl=0;
  for(const poly of (polys||[])){ const r=poly[0]; if(r&&r.length>bl){bl=r.length;best=r;} } return best; }
function ringCentroidLL(ring){ // area-weighted centroid in lon/lat (falls back to mean)
  let a=0,cx=0,cy=0; for(let i=0;i<ring.length-1;i++){const [x0,y0]=ring[i],[x1,y1]=ring[i+1];
    const f=x0*y1-x1*y0; a+=f; cx+=(x0+x1)*f; cy+=(y0+y1)*f;}
  if(Math.abs(a)<1e-12){let x=0,y=0;for(const p of ring){x+=p[0];y+=p[1];}return [x/ring.length,y/ring.length];}
  a*=0.5; return [cx/(6*a), cy/(6*a)]; }
function shortCode(c){ return c; }              // section codes are already short (e.g. "1-F")
function isRef(){ return DATA.geometry_kind==="reflines"; }
function drawRefMap(W,H,focus){
  // boundary-reference areas (Kodiak/Chignik): plot the regulation's coordinate
  // points + coordinate-defined lines, each section a clickable group.
  const bb=(focus&&DATA.sections[focus]&&DATA.sections[focus].points.length)
      ? (function(){const ps=DATA.sections[focus].points;let x0=180,y0=90,x1=-180,y1=-90;
          for(const p of ps){x0=Math.min(x0,p.lon);y0=Math.min(y0,p.lat);x1=Math.max(x1,p.lon);y1=Math.max(y1,p.lat);}
          const px=(x1-x0)*0.3+0.05,py=(y1-y0)*0.3+0.05;return [x0-px,y0-py,x1+px,y1+py];})()
      : DATA.bbox;
  const bb2=(!focus&&dist&&districtBBox(dist))||bb;
  const pr=makeProj(bb2,W,H,16); let g=landPaths(pr, DATA.land),labels="";
  const live=areaLive();
  for(const c of ORDER){ const s=DATA.sections[c]; if(!s.points.length) continue;
    const dim=(focus&&c!==focus)||(!focus&&dist&&s.district_name!==dist); const op=dim?0.15:1;
    const st=live?statusOf(c):"ref"; const col=COLOR[st]||"var(--ref)";
    const strong=live&&st!=="unknown"&&st!=="none";
    let seg="";
    for(const ln of (s.lines||[])){ let d="M"; ln.forEach((pt,i)=>{const m=pr.toM(pt);d+=(i?"L":"")+pr.X(m).toFixed(1)+" "+pr.Y(m).toFixed(1);});
      seg+=`<path d="${d}" fill="none" stroke="${col}" stroke-width="${focus===c?3:(strong?2.4:1.4)}" stroke-opacity="${op}"/>`; }
    let dots="";
    for(const p of s.points){ const m=pr.toM([p.lon,p.lat]); dots+=`<circle cx="${pr.X(m).toFixed(1)}" cy="${pr.Y(m).toFixed(1)}" r="${focus===c?5:(strong?4.4:2.6)}" fill="${col}" fill-opacity="${op}" stroke="#fff" stroke-width="0.9"/>`; }
    g+=`<g class="amsec" data-code="${c}"${pxBox(s,pr)} style="opacity:${op}"><title>${s.name}${live?" — "+STLAB[st]:""}</title>${seg}${dots}</g>`;
    const p0=s.points[0]; const m0=pr.toM([p0.lon,p0.lat]);
    labels+=`<text class="amlabel" x="${pr.X(m0).toFixed(1)}" y="${(pr.Y(m0)-6).toFixed(1)}" text-anchor="middle" font-size="7" opacity="${op}">${s.label}</text>`;
  }
  const CV=vbFit(pr,W,H,14);
  const cnames=chartNameLayer(pr,CV,{minD:70,cap:22,fs:8});
  return `<svg viewBox="${CV.join(" ")}" preserveAspectRatio="xMidYMid meet">${g}${cnames}${labels}</svg>`;
}
function districtBBox(dn){ let b=[999,999,-999,-999], any=false;
  for(const c of ORDER){ const s=DATA.sections[c]; if(s.district_name!==dn) continue;
    let sb=s.bbox;
    if(!sb&&s.points&&s.points.length){ const xs=s.points.map(p=>p.lon), ys=s.points.map(p=>p.lat);
      sb=[Math.min(...xs),Math.min(...ys),Math.max(...xs),Math.max(...ys)]; }
    if(!sb) continue; any=true;
    b=[Math.min(b[0],sb[0]),Math.min(b[1],sb[1]),Math.max(b[2],sb[2]),Math.max(b[3],sb[3])]; }
  return any?b:null; }
function pxBox(s,pr){
  // a unit's box in pixel space, for the tap fly-to (bbox, else its points)
  let bb=s.bbox;
  if(!bb&&s.points&&s.points.length){ const xs=s.points.map(p=>p.lon).filter(x=>x!=null), ys=s.points.map(p=>p.lat).filter(y=>y!=null);
    if(xs.length) bb=[Math.min(...xs),Math.min(...ys),Math.max(...xs),Math.max(...ys)]; }
  if(!bb) return "";
  const m0=pr.toM([bb[0],bb[1]]), m1=pr.toM([bb[2],bb[3]]);
  const x=Math.min(pr.X(m0),pr.X(m1)), y=Math.min(pr.Y(m0),pr.Y(m1));
  const w=Math.max(6,Math.abs(pr.X(m1)-pr.X(m0))), h=Math.max(6,Math.abs(pr.Y(m1)-pr.Y(m0)));
  return ` data-bx="${x.toFixed(1)}" data-by="${y.toFixed(1)}" data-bw="${w.toFixed(1)}" data-bh="${h.toFixed(1)}"`;
}
function drawAreaMap(W,H){
  if(isRef()) return drawRefMap(W,H,null);
  // a chosen district ZOOMS AND ISOLATES: project to its own bbox, fade the rest
  const bb=(dist&&districtBBox(dist))||areaBBox(); const pr=makeProj(bb,W,H,10);
  let paths=landPaths(pr, DATA.land), labels=""; const _lblPts=[];
  // OPENS-SOON ON THE MAP (ledger #75): a section announced to open inside
  // 72 h in ANY gear wears a blue dashed ring — visible even from another
  // gear's tab, because a captain scanning the chart plans across fisheries
  const _unow=Date.now(), _ulim=_unow+72*3600e3;
  const upIn72=(c)=>{ for(const g2 in (DATA.status||{})){ const r=(DATA.status[g2]||{})[c];
    if(r&&liveStatus(r)==="upcoming"&&r.starts){ const t=new Date(r.starts).getTime();
      if(isFinite(t)&&t>=_unow-3600e3&&t<=_ulim) return true; } } return false; };
  // a unit whose box covers most of the area (Area M's two half-peninsula
  // subareas) floods the chart if filled — render it as a light outline
  // UNDER everything, keeping it real and tappable without drowning the
  // section ribbons that carry the actual where (ledger #76)
  const _ab=DATA.bbox||[0,0,1,1], _aA=Math.max(1e-9,(_ab[2]-_ab[0])*(_ab[3]-_ab[1]));
  // scope: ONLY in reconstructed (ribbon) areas — Yakutat's two honest
  // district polygons also cover most of their area, and outlining them
  // silently killed the partial split (caught by the gauntlet, not shipped)
  const isGiant=(s)=>{ const b=s.bbox; if(!DATA.has_reconstructed||!b) return false;
    return ((b[2]-b[0])*(b[3]-b[1]))/_aA > 0.40; };
  const drawOrder=[...ORDER].sort((a,b)=>(isGiant(DATA.sections[b])?1:0)-(isGiant(DATA.sections[a])?1:0));
  for(const c of drawOrder){ const s=DATA.sections[c]; if(!gearOK(c)) continue; const st=statusOf(c);
    if(isGiant(s)&&(s.cpolys||s.polys)){
      const gg=s.cpolys||s.polys;
      paths+=`<path class="amsec" data-code="${c}"${pxBox(s,pr)} d="${polysPath(gg,pr)}" fill="${COLOR[st]}" fill-opacity="0.05" stroke="${COLOR[st]}" stroke-width="0.9" stroke-opacity="0.5"><title>${s.name} — ${STLAB[st]}</title></path>`;
      continue;
    }
    const g=(s.cpolys||s.polys);
    const dim=dist&&s.district_name!==dist;
    if(!(g&&g.length)){
      const pts=(s.points||[]).filter(p=>p.lon!=null&&p.lat!=null);
      if(!pts.length&&!(s.lines&&s.lines.length)) continue;
      let seg="";
      for(const ln of (s.lines||[])){ let d="M"; ln.forEach((pt,i)=>{const m=pr.toM(pt);d+=(i?"L":"")+pr.X(m).toFixed(1)+" "+pr.Y(m).toFixed(1);});
        seg+=`<path d="${d}" fill="none" stroke="${COLOR[st]}" stroke-width="${dim?0.8:1.6}" stroke-opacity="${dim?0.15:0.9}"/>`; }
      let dots="";
      for(const p of pts){ const m=pr.toM([p.lon,p.lat]);
        dots+=`<circle cx="${pr.X(m).toFixed(1)}" cy="${pr.Y(m).toFixed(1)}" r="${(st!=='unknown'&&st!=='none')?4.2:2.6}" fill="${COLOR[st]}" fill-opacity="${dim?0.15:1}" stroke="#fff" stroke-width="0.9"/>`; }
      paths+=`<g class="amsec" data-code="${c}"${pxBox(s,pr)} style="opacity:${dim?0.2:1}"><title>${s.name} — ${STLAB[st]}</title>${seg}${dots}</g>`;
      if(!dim&&pts.length){ const m0=pr.toM([pts[0].lon,pts[0].lat]);
        labels+=`<text class="amlabel" x="${pr.X(m0).toFixed(1)}" y="${(pr.Y(m0)-6).toFixed(1)}" text-anchor="middle" font-size="7">${s.label||c}</text>`; _lblPts.push([pr.X(m0),pr.Y(m0)]); }
      continue;
    }
    if(st==='partial'&&!dim){
      // a PARTLY-OPEN section shows its WHERE right on the area map — the
      // open/closed split a captain needs is visible BEFORE any tap (client
      // call, ledger #74), exactly as the detail sheet draws it: green only
      // where the EO's own line opens water, red pockets where it closes,
      // orange outline saying "this section is split".
      const rec=recOf(c); const rules=(rec&&rec.rules)?rec.rules:[];
      const openR=rules.filter(r=>r.status==="open"&&r.pts&&r.pts.length>=2&&!r.attached);
      const closedR=rules.filter(r=>r.status==="closed"&&r.pts&&r.pts.length>=2);
      const base=openR.length?"closed":"open";
      let inner=`<path d="${polysPath(g,pr)}" fill="${COLOR[base]}" fill-opacity="0.62" stroke="none"/>`;
      for(const rule of openR){ for(const pth of clippedPieces(s,rule,pr)) inner+=`<path d="${pth}" fill="var(--open)" fill-opacity="0.72"/>`; }
      closedR.forEach(rule=>{
        const a=pr.toM(rule.pts[0]),b=pr.toM(rule.pts[1]);
        const single=!rule.attached&&/^(north|south|east|west)$/.test((rule.side||'').trim().toLowerCase());
        if(single){ const n=sideNormal(a,b,rule.side);
          for(const poly of (s.polys||[])){ const cl=clipRing(poly[0].map(pr.toM),a,n);
            if(cl.length>=3) inner+=`<path d="${ringPath(cl,pr)}" fill="var(--closed)" fill-opacity="0.78"/>`; } }
        inner+=`<line x1="${pr.X(a).toFixed(1)}" y1="${pr.Y(a).toFixed(1)}" x2="${pr.X(b).toFixed(1)}" y2="${pr.Y(b).toFixed(1)}" stroke="var(--closed)" stroke-width="1.3" stroke-linecap="round"/>`; });
      paths+=`<g class="amsec" data-code="${c}" data-split="1"${pxBox(s,pr)}><title>${s.name} — ${STLAB[st]}</title>${inner}`+
             `<path d="${polysPath(g,pr)}" fill="none" stroke="${COLOR.partial}" stroke-width="1.4"/></g>`;
    } else {
    // a RECONSTRUCTED planning band draws dashed and lighter — honest about
    // being the regulation's coastline fence, not an official GIS boundary
    const rc=s.reconstructed;
    paths+=`<path class="amsec" data-code="${c}"${pxBox(s,pr)} d="${polysPath(g,pr)}" fill="${COLOR[st]}" `+
           `fill-opacity="${dim?0.08:((st==='none'||st==='unknown')?0.30:(rc?0.55:0.74))}" stroke="${rc?COLOR[st]:'var(--surface)'}" stroke-width="${rc?1:0.6}"${rc?' stroke-dasharray="4 3"':''}>`+
           `<title>${s.name} — ${STLAB[st]}${rc?' (planning band)':''}</title></path>`;
    }
    if(dim) continue;
    if(upIn72(c)&&st!=="upcoming")
      paths+=`<path class="upring" d="${polysPath(g,pr)}" fill="none" stroke="var(--upcoming)" stroke-width="1.8" stroke-dasharray="5 3" pointer-events="none"><title>${s.name} — announced to open within 72 hours</title></path>`;
    const ring=biggestRing(g);
    if(ring){ const ll=ringCentroidLL(ring); const X=pr.X(pr.toM(ll)), Y=pr.Y(pr.toM(ll));
      const lab=(s.label||c); labels+=`<text class="amlabel" x="${X.toFixed(1)}" y="${(Y+2.4).toFixed(1)}" text-anchor="middle" font-size="7">${lab}</text>`; _lblPts.push([X,Y]); }
  }
  // a hatchery pocket announced to open inside 72 h shows ON the map as a
  // blue callout (Anita Bay class). Its official boundary coordinates aren't
  // in the byte-clean set, so the callout is honestly non-spatial — named,
  // timed, and a tap leads to the advisory's exact words; no invented pin.
  let thabadge="";
  const upTha=(DATA.tha_notes||[]).filter(n=>{ if(!n.starts) return false;
    const t=new Date(n.starts).getTime(); return isFinite(t)&&t>=_unow-3600e3&&t<=_ulim; });
  const CV=vbFit(pr,W,H,12);
  if(upTha.length){
    const d=new Date(upTha[0].starts);
    const when=d.toLocaleDateString(undefined,{weekday:"short"})+" "+d.toLocaleTimeString(undefined,{hour:"numeric",minute:"2-digit"});
    const txt=`Opens soon: ${upTha.map(n=>n.name+" THA").join(", ")} — ${when}`;
    const w=Math.min(CV[2]-20, txt.length*6.4+26);
    const bx=CV[0]+10, by=CV[1]+10;   // pinned to the OPENING view's corner (crop-aware)
    thabadge=`<g class="thabadge" style="cursor:pointer"><rect x="${bx.toFixed(1)}" y="${by.toFixed(1)}" rx="9" width="${w.toFixed(0)}" height="26" fill="var(--surface)" fill-opacity="0.95" stroke="var(--upcoming)" stroke-width="1.3"/><rect x="${bx.toFixed(1)}" y="${by.toFixed(1)}" width="4" height="26" rx="2" fill="var(--upcoming)"/><text x="${(bx+12).toFixed(1)}" y="${(by+17).toFixed(1)}" font-size="11.5" font-weight="700" fill="var(--upcoming)">${txt.replace(/</g,"&lt;")}</text><title>Hatchery pocket opener — tap for the advisory's exact words</title></g>`;
  }
  // RED-DETAIL PARITY (ledger #87, the client: "any red shading on the
  // detailed section visuals should be present in the view of the larger
  // area as a whole"): every permanent/regulatory closed-waters pocket that
  // the detail sheets draw is drawn HERE too, same hatch, byte-clean polys.
  let cwOut="";
  for(const c in (DATA.closed_waters||{})){
    for(const cw of DATA.closed_waters[c]||[]){
      if(!(cw.polys&&cw.polys.length)) continue;
      cwOut+=`<path d="${polysPath(cw.polys,pr)}" fill="url(#permhatch)" stroke="#7d1414" stroke-width="0.9"><title>${(cw.name||"Closed waters")} — always closed</title></path>`;
    }
  }
  if(cwOut) cwOut=`<g style="pointer-events:none">${cwOut}</g>`;
  const cwDefs=cwOut?`<defs><pattern id="permhatch" width="6" height="6" patternTransform="rotate(45)" patternUnits="userSpaceOnUse"><rect width="6" height="6" fill="#c02626" fill-opacity="0.28"/><line x1="0" y1="0" x2="0" y2="6" stroke="#7d1414" stroke-width="2.2"/></pattern></defs>`:"";
  const cnames=chartNameLayer(pr,CV,{minD:64,cap:26,fs:8,taken:_lblPts});
  return `<svg viewBox="${CV.join(" ")}" preserveAspectRatio="xMidYMid meet">${cwDefs}${paths}${cwOut}${cnames}${labels}${thabadge}</svg>`;
}
// --- the ALL-ALASKA home view: the whole state, each management area in place;
// tap an area to enter it. Orientation starts at Alaska, not at an area. ---
function drawAlaska(W,H){
  // the WHOLE state, centered — the land layer runs to Point Barrow (71.4°N)
  // and the western Aleutians; the old window cut the top of Alaska off
  const pr=makeProj([-170.6,52.2,-130.2,71.4],W,H,8);
  let out=landPaths(pr, DATA_ALL.land_ak||[]);
  let labels="";
  for(const a of AREAS){
    const R=DATA_ALL.regions[a.key]; if(!R||!R.bbox) continue;
    let shape="";
    if(R.geometry_kind==="reflines"){
      for(const c of R.section_order){ const s0=R.sections[c];
        for(const pt of (s0.points||[])){ const m=pr.toM([pt.lon,pt.lat]);
          shape+=`<circle cx="${pr.X(m).toFixed(1)}" cy="${pr.Y(m).toFixed(1)}" r="1.6" fill="var(--waterfoot-line)" fill-opacity="0.9"/>`; } }
    } else {
      for(const c of R.section_order){ const s0=R.sections[c]; const g=(s0.cpolys||s0.polys);
        if(!g){
          // line-only unit (the federal EEZ troll water): its boundary draws on
          // the all-Alaska map too, colored by its LIVE troll status — the
          // same green line the SE tab shows when the troll fishery is open
          if(s0.lines&&s0.lines.length){
            const rec=((R.status||{})["troll"]||{})[c];
            const col=rec?COLOR[liveStatus(rec)]:"var(--upcoming)";
            // the line names itself on hover — its southern run is the
            // US–Canada A–B line, which ADF&G's own Dixon Entrance District
            // polygon ALSO follows, so the two meeting is two official
            // boundaries coinciding, not a drawing error (ledger #80)
            const fedtt=`<title>Federal EEZ troll boundary (Salmon FMP East Area)${rec?" — troll "+STLAB[liveStatus(rec)].toLowerCase():""}. Its southern edge is the US–Canada A–B line, shared with ADF&amp;G's Dixon Entrance District.</title>`;
            for(const ln of s0.lines){ let d="M"; ln.forEach((pt,i)=>{const m=pr.toM(pt); d+=(i?"L":"")+pr.X(m).toFixed(1)+" "+pr.Y(m).toFixed(1);});
              shape+=`<path class="fedline" d="${d}" fill="none" stroke="${col}" stroke-width="0.9" stroke-opacity="0.8">${fedtt}</path>`; }
          }
          continue;
        }
        // a GIANT unit's footprint (Area M's half-peninsula subareas) draws
        // dotted and faint: its long straight offshore edge read as a route
        // line continuing the federal boundary (ledger #81) — dots say
        // "administrative outline", solid stays for real coastal water
        const RB=R.bbox, RA=Math.max(1e-9,(RB[2]-RB[0])*(RB[3]-RB[1]));
        const sb=s0.bbox, giant=sb&&((sb[2]-sb[0])*(sb[3]-sb[1]))/RA>0.40;
        shape+=`<path d="${polysPath(g,pr)}" fill="var(--waterfoot)" fill-opacity="${giant?0.16:0.55}" stroke="var(--waterfoot-line)" stroke-opacity="${giant?0.55:0.8}" stroke-width="0.5"${giant?' stroke-dasharray="1.5 2.5"':''}><title>${(s0.name||c)} — ${a.label}</title></path>`; }
    }
    const cx=(R.bbox[0]+R.bbox[2])/2, cy=(R.bbox[1]+R.bbox[3])/2;
    // de-collide the Gulf cluster: small fixed pixel offsets per label so
    // Cook Inlet / PWS and Chignik / Alaska Peninsula never overlap
    const NUDGE={CookInlet:[-34,-24],PWS:[30,-22],Chignik:[46,22],AreaM:[-56,18],Kodiak:[26,14],Yakutat:[16,-6]};
    const nd=NUDGE[a.key]||[0,0];
    const m=pr.toM([cx,cy]); const X=pr.X(m)+nd[0], Y=pr.Y(m)+nd[1];
    // the area's box in PIXEL space, carried on the element so a tap can
    // animate the viewBox into it before entering the area
    const m0=pr.toM([R.bbox[0],R.bbox[1]]), m1=pr.toM([R.bbox[2],R.bbox[3]]);
    const bx=Math.min(pr.X(m0),pr.X(m1)), by=Math.min(pr.Y(m0),pr.Y(m1));
    const bw=Math.abs(pr.X(m1)-pr.X(m0)), bh=Math.abs(pr.Y(m1)-pr.Y(m0));
    out+=`<g class="amsec akarea" data-area="${a.key}" data-bx="${bx.toFixed(1)}" data-by="${by.toFixed(1)}" data-bw="${bw.toFixed(1)}" data-bh="${bh.toFixed(1)}"><title>${a.label}${a.status_live?" — live status":" — boundaries"}</title>${shape}</g>`;
    // OPENS-SOON ON THE MAP (client call, ledger #75): any area with an
    // announced opener inside 72 h — any gear, hatchery pockets included —
    // wears a blue count badge on its label pill, statewide at a glance
    const nUpMap=upcomingSoon(72,a.key).length;
    const badge=nUpMap?`<g class="upbadge"><circle cx="${(X+54).toFixed(1)}" cy="${(Y-11).toFixed(1)}" r="8.5" fill="var(--upcoming)" stroke="var(--surface)" stroke-width="1.6"/><text x="${(X+54).toFixed(1)}" y="${(Y-7.6).toFixed(1)}" text-anchor="middle" font-size="9.5" font-weight="800" fill="#fff">${nUpMap}</text><title>${nUpMap} announced opening${nUpMap>1?"s":""} in the next 72 hours</title></g>`:"";
    // NEUTRAL pill borders (ledger #81): green-bordered pills strung along
    // the Gulf visually CONTINUED the federal troll line into Area M's
    // footprint — the client read them as one line. Live-ness is now a small
    // green dot INSIDE the pill; only the map's own linework wears map color.
    labels+=`<g class="aklab" data-area="${a.key}" style="cursor:pointer"><rect x="${(X-56).toFixed(1)}" y="${(Y-11).toFixed(1)}" width="112" height="22" rx="11" fill="var(--surface)" fill-opacity="0.92" stroke="var(--line)" stroke-width="1.1"/>`+
      `<circle class="akdot" cx="${(X-47).toFixed(1)}" cy="${Y.toFixed(1)}" r="3.4" fill="${a.status_live?'var(--open)':'var(--ref)'}"><title>${a.status_live?"live status":"boundaries shown"}</title></circle>`+
      `<text x="${(X+5).toFixed(1)}" y="${(Y+4).toFixed(1)}" text-anchor="middle" font-size="10" font-weight="700" fill="var(--ink)">${a.label.replace(/\s*\(.*\)$/,"")}</text>${badge}</g>`;
  }
  const CV=vbFit(pr,W,H,12);
  return `<svg viewBox="${CV.join(" ")}" preserveAspectRatio="xMidYMid meet">${out}${labels}</svg>`;
}
function renderAreaMap(){
  const host=document.getElementById("areamap"); if(!host) return;
  if(!area){
    const au=document.getElementById("am-unit"); if(au) au.textContent="management area";
    const aa=document.getElementById("am-area"); if(aa) aa.textContent="Alaska";
    host.innerHTML = drawAlaska(1000,640) +
      `<div class="zc" id="areazc"><button data-z="in" aria-label="Zoom in">+</button>`+
      `<button data-z="out" aria-label="Zoom out">−</button><button data-z="reset" aria-label="Reset">↺</button></div>`;
    const svg=host.querySelector("svg"); if(!svg) return;
    setupZoom(svg, host.querySelector("#areazc"));
    let dx0=0,dy0=0,moved=0;
    svg.addEventListener("pointerdown",e=>{dx0=e.clientX;dy0=e.clientY;moved=0;});
    svg.addEventListener("pointermove",e=>{ if(e.buttons) moved=Math.max(moved,Math.hypot(e.clientX-dx0,e.clientY-dy0)); });
    svg.addEventListener("click",e=>{ if(moved>6) return;
      // second layer vs click retargeting (pointer capture, ledger #72):
      // if the click reports the svg itself, resolve the element actually
      // under the finger and use THAT
      let t=e.target;
      if(t===svg&&isFinite(e.clientX)){ const el=document.elementFromPoint(e.clientX,e.clientY); if(el&&svg.contains(el)) t=el; }
      const g=t.closest("[data-area]"); if(!g||!g.dataset.area) return;
      const key=g.dataset.area;
      // fly into the tapped area, then enter it
      const src=svg.querySelector(`.akarea[data-area="${key}"]`)||g;
      const b=[+src.dataset.bx,+src.dataset.by,+src.dataset.bw,+src.dataset.bh];
      if(svg.__zoomTo) svg.__zoomTo(b,450,()=>setArea(key)); else setArea(key); });
    return;
  }
  const cur=AREAS.find(a=>a.key===area)||{};
  const au=document.getElementById("am-unit"); if(au) au.textContent=(DATA.unit_label||"section").toLowerCase();
  const aa=document.getElementById("am-area"); if(aa) aa.textContent=(dist? dist+" — ":"")+(cur.label||"Alaska");
  host.innerHTML = drawAreaMap(1000,680) +
    `<div class="zc" id="areazc"><button data-z="in" aria-label="Zoom in">+</button>`+
    `<button data-z="out" aria-label="Zoom out">−</button><button data-z="reset" aria-label="Reset">↺</button></div>`;
  const svg=host.querySelector("svg"); if(!svg) return;
  setupZoom(svg, host.querySelector("#areazc"));
  // click-to-open, but not after a pan-drag
  let dx0=0,dy0=0,moved=0;
  svg.addEventListener("pointerdown",e=>{dx0=e.clientX;dy0=e.clientY;moved=0;});
  svg.addEventListener("pointermove",e=>{ if(e.buttons) moved=Math.max(moved,Math.hypot(e.clientX-dx0,e.clientY-dy0)); });
  svg.addEventListener("click",e=>{ if(moved>6) return;
    let t=e.target;   // same retargeting guard as the home map (ledger #72)
    if(t===svg&&isFinite(e.clientX)){ const el=document.elementFromPoint(e.clientX,e.clientY); if(el&&svg.contains(el)) t=el; }
    if(t.closest(".thabadge")){ const th=document.getElementById("thashelf");
      if(th&&!th.hidden) th.scrollIntoView({behavior:"smooth",block:"center"}); return; }
    const p=t.closest(".amsec");
    if(!p||!p.dataset.code) return;
    // fly into the tapped section, then open its detail — the map behind the
    // sheet stays centered on it
    const b=[+p.dataset.bx,+p.dataset.by,+p.dataset.bw,+p.dataset.bh];
    if(svg.__zoomTo&&b.every(isFinite)) svg.__zoomTo(b,420,()=>openDetail(p.dataset.code));
    else openDetail(p.dataset.code); });
}

const STLAB={open:"Open",closed:"Closed",partial:"Partly open",upcoming:"Opens soon",unknown:"No announcement",none:"No opening",ref:"Boundary"};
function fmtWhen(rec){
  if(!rec) return "No opening announced";
  const st=liveStatus(rec);
  const end=rec.ends?new Date(rec.ends):null, start=rec.starts?new Date(rec.starts):null;
  const df=d=>d.toLocaleDateString(undefined,{weekday:"short",month:"short",day:"numeric"})+", "+d.toLocaleTimeString(undefined,{hour:"numeric",minute:"2-digit"});
  if(st==="open"||st==="partial"){ if(end&&!isNaN(end)) return (st==="partial"?"Some waters open until ":"Open until ")+df(end); return st==="partial"?"Partly open":"Open"; }
  if(st==="upcoming"){ if(start&&!isNaN(start)){ const ms=start.getTime()-Date.now();
      return "Opens "+df(start)+(ms>0&&ms<72*3600e3?" · "+relIn(ms):""); } return "Opens soon"; }
  if(st==="closed") return "Closed"+(end&&!isNaN(end)?" (through "+df(end)+")":"");
  if(st==="unknown") return "No current announcement — confirm with ADF&G";
  return "No opening announced";
}

function render(){
  document.getElementById("asof").textContent=fmtAsOf(DATA_ALL.as_of||(DATA&&DATA.as_of));
  // ANNOUNCEMENTS WE COULD NOT READ ARE NAMED, NOT HIDDEN (axiom 37).
  try{
    const ub=document.getElementById("unreadbar");
    if(ub){
      if(UNREAD&&UNREAD.length){
        ub.hidden=false;
        const esc=t=>String(t||"").replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
        // NAMED THE WAY A PERSON READS IT, never a release id (ledger #114)
        const link=u=>`<a href="https://www.adfg.alaska.gov/static/applications/dcfnewsrelease/${u.id}.pdf" target="_blank" rel="noopener" style="color:#fff;text-decoration:underline">${esc(u.name||u.label||u.id)}</a>`;
        const SHOW=4, open=!!window.__unreadOpen;
        const head=UNREAD.slice(0,SHOW), rest=UNREAD.slice(SHOW);
        ub.innerHTML="<span style=\"opacity:.85;font-weight:600\">Not on this chart \u2014 read before you fish:</span> "+
          head.map(link).join(" &nbsp;|&nbsp; ")+
          (rest.length && !open ? ` <a href="#" id="unreadmore" style="color:#fff;opacity:.9;text-decoration:underline">and ${rest.length} more</a>` : "")+
          (rest.length && open ? " &nbsp;|&nbsp; "+rest.map(link).join(" &nbsp;|&nbsp; ")+` <a href="#" id="unreadless" style="color:#fff;opacity:.9;text-decoration:underline">show fewer</a>` : "");
        const mo=document.getElementById("unreadmore"); if(mo) mo.onclick=e=>{e.preventDefault(); window.__unreadOpen=true; render();};
        const le=document.getElementById("unreadless"); if(le) le.onclick=e=>{e.preventDefault(); window.__unreadOpen=false; render();};
      } else ub.hidden=true;
    }
  }catch(e){}
  // THE SELF-AUDIT HAS NO DISPLAY SURFACE (ledger #116, the client: "the
  // checker is not for display purposes, its supposed to go inward with that
  // information and fix the problem"). What it repairs, it repairs; what it
  // cannot, it records in selfaudit.json and /api/state for the maintainer.
  // A captain acts on the chart and on the "not on this chart" line — content,
  // never a report about the app's own bookkeeping.
  // A SNAPSHOT SAYS HOW OLD IT IS (axiom 36). The refresh runs every two
  // hours; if it stalls, nothing on this page would otherwise tell a captain
  // he is reading yesterday's chart. Statuses are already re-judged against
  // his clock, but an old snapshot can still MISS an opening or a closure
  // announced since — so the page says its own age out loud once it is stale.
  try{
    const _ao=new Date(DATA_ALL.as_of||(DATA&&DATA.as_of)); const _sb=document.getElementById("stalebar");
    const hrs=(Date.now()-_ao.getTime())/3600000;
    if(_sb){
      if(isFinite(hrs)&&hrs>6){
        _sb.hidden=false;
        _sb.textContent="This chart was last refreshed "+(hrs<48?Math.round(hrs)+" hours":Math.round(hrs/24)+" days")+
          " ago. Openings or closures announced since are not on it — confirm with ADF&G before you set.";
      } else _sb.hidden=true;
    }
  }catch(e){}
  // area selector (built once) — Alaska first, then the areas
  const asel=document.getElementById("areasel");
  if(asel && !asel.options.length){
    const o0=document.createElement("option"); o0.value=""; o0.textContent="Select area (e.g. Southeast Alaska)"; asel.appendChild(o0);
    AREAS.forEach(a=>{const o=document.createElement("option");o.value=a.key;o.textContent=a.label;asel.appendChild(o);});
    asel.onchange=()=>setArea(asel.value); }
  if(asel) asel.value=area;
  const chrome=["gearrow","pins","summary"]; const ctr=document.querySelector(".controls"); const lg=document.querySelector(".legend");
  if(!area){
    // ALL-ALASKA HOME: the state map with every management area in place
    document.getElementById("areabanner").hidden=true;
    document.getElementById("fedbanner").hidden=true;
    const _us=document.getElementById("upcshelf"); if(_us){_us.hidden=true;_us.innerHTML="";}
    const _ts=document.getElementById("thashelf"); if(_ts){_ts.hidden=true;_ts.innerHTML="";}
    for(const id of chrome){ const el=document.getElementById(id); if(el) el.style.display="none"; }
    if(ctr) ctr.style.display="none"; if(lg) lg.style.display="none";
    renderAreaMap();
    const g=document.getElementById("grid"); g.innerHTML="";
    AREAS.forEach(a=>{
      const R=DATA_ALL.regions[a.key]; const n=R?R.section_order.length:0;
      const live=a.status_live;
      // the area's live digest across ALL its gears: how many waters are open
      // now, how many are announced to open, and the soonest opening time —
      // the read a captain filters on before steaming anywhere
      let nOpen=0, nUp=0, nextT=null;
      if(live&&R&&R.status){ const seen={};
        for(const gk in R.status){ for(const c in R.status[gk]){ const r=R.status[gk][c];
          if(!r) continue;
          const ls=liveStatus(r);
          if(ls==="open"||ls==="partial"){ if(!seen["o|"+c]){nOpen++; seen["o|"+c]=1;} }
          if(ls==="upcoming"){ if(!seen["u|"+c]){nUp++; seen["u|"+c]=1;}
            if(r.starts){ const tt=new Date(r.starts).getTime();
              if(!isNaN(tt)&&tt>Date.now()&&(nextT===null||tt<nextT)) nextT=tt; } } } } }
      // hatchery pockets announced to open at a future time join the digest —
      // Anita Bay's Sept 1 opener is a positioning signal like any other
      if(live&&R){ for(const nn of (R.tha_notes||[])){
        if(!nn||!nn.starts) continue; const tt=new Date(nn.starts).getTime();
        if(isNaN(tt)||tt<=Date.now()) continue;
        nUp++; if(nextT===null||tt<nextT) nextT=tt; } }
      const nx=nextT?new Date(nextT):null;
      const nxs=nx?nx.toLocaleDateString(undefined,{weekday:"short"})+" "+nx.toLocaleTimeString(undefined,{hour:"numeric",minute:"2-digit"}):null;
      const card=document.createElement("div"); card.className="card s-"+(live?"open":"ref");
      card.innerHTML=`<div class="cbody"><div class="cname">${a.label}</div>
        <div class="cdist">${n} ${(R&&R.unit_label||"unit").toLowerCase()}${n===1?"":"s"}</div>
        ${live?`<div class="ctime" style="display:flex;gap:12px;flex-wrap:wrap">
           <span style="color:var(--open);font-weight:700">${nOpen} open now</span>
           <span style="color:var(--upcoming);font-weight:700">${nUp} opening soon${nxs?" · next "+nxs:""}</span></div>`
         :`<div class="ctime" style="color:var(--ref)">Official boundaries shown</div>`}</div>`;
      card.onclick=()=>setArea(a.key);
      g.appendChild(card);
    });
    document.getElementById("empty").hidden=true;
    return;
  }
  for(const id of chrome){ const el=document.getElementById(id); if(el) el.style.display=""; }
  if(ctr) ctr.style.display=""; if(lg) lg.style.display="";
  const cur=AREAS.find(a=>a.key===area)||{};
  // per-area banner: non-live areas show boundaries only, honestly
  const bn=document.getElementById("areabanner");
  if(!cur.status_live){ bn.hidden=false; bn.innerHTML=`<b>${cur.label}:</b> official ADF&amp;G boundaries shown for orientation. Live open/closed status for this area is being wired from ADF&amp;G announcements — until then, tap a ${DATA.unit_label.toLowerCase()} for its boundary and confirm openings with ADF&amp;G.`; }
  else if(DATA.comprehensive===false){ bn.hidden=false; bn.style.borderLeftColor="var(--upcoming)";
    bn.innerHTML=`<b>${cur.label}:</b> live status is shown for the ${DATA.unit_label.toLowerCase()}s named in the latest ADF&amp;G advisories. A ${DATA.unit_label.toLowerCase()} marked <b>No announcement</b> is not covered by the current advisory — it is not a closure; confirm with ADF&amp;G.`; }
  else if(DATA.has_reconstructed){ bn.hidden=false; bn.style.borderLeftColor="var(--upcoming)";
    bn.innerHTML=`<b>${cur.label}:</b> ADF&amp;G publishes no official GIS boundaries for this area's salmon sections, so the shaded waters are <b>planning bands</b> — the coastline fenced by each section's own regulation coordinates, extended a fixed distance seaward (drawn dashed). Exact along the shore; indicative offshore. The printed regulation and the announcement govern — confirm with ADF&amp;G before you set.`; }
  else { bn.hidden=true; bn.style.borderLeftColor=""; }
  // FEDERAL (EEZ) WATERS — this map draws the STATE district/section structure.
  // Two fisheries extend beyond it, and silence would overstate completeness:
  // SE troll also operates in the adjacent EEZ (Salmon FMP East Area, managed
  // by ADF&G under federal delegation — the same troll announcements govern);
  // the Cook Inlet EEZ corridor (>3 nm) has a SEPARATE federally-managed
  // salmon fishery whose periods NMFS announces — not shown here.
  const FED_NOTES={
    "SE|troll":"Troll also operates in <b>federal EEZ waters</b> — the Salmon FMP East Area (EEZ east of Cape Suckling, 143°53.6′ W; troll gear only), managed by ADF&amp;G under federal delegation, so the same troll announcements govern there. It is on this map: the <b>Federal EEZ</b> unit (pick “Federal waters (EEZ)” in the district menu) draws where state waters end (3 nm, BOEM) and the 200-nm/US–Canada limits (NOAA), colored by the current troll status.",
    "CookInlet|drift gillnet":"The <b>Cook Inlet EEZ</b> (federal waters beyond 3 nm) has a separate <b>federally managed</b> salmon fishery — NMFS sets and announces its fishing periods and harvest limits, and those openings do <b>not</b> appear in the ADF&amp;G announcements this map reads. Check NOAA Fisheries (Cook Inlet EEZ salmon) before fishing the EEZ corridor."};
  // WEST AREA truth (ledger #82, client-prompted): west of Cape Suckling the
  // EEZ is the Salmon FMP WEST AREA — closed to ALL commercial salmon
  // fishing (net since 1952, troll since 1973; Amendment 12, 77 FR 75570)
  // except historic pockets removed from the FMP. Any-gear banner per area.
  const WEST_NOTE_BASE="Federal waters here (the EEZ, beyond 3 nm) are the Salmon FMP <b>West Area — closed to all commercial salmon fishing</b> (net since 1952, troll since 1973). This map's status colors apply to state waters.";
  const FED_NOTES_AREA={
    "Kodiak":WEST_NOTE_BASE,
    "Chignik":WEST_NOTE_BASE,
    "BristolBay":WEST_NOTE_BASE,
    "AreaM":WEST_NOTE_BASE+" Exception: the historic <b>Alaska Peninsula EEZ pocket</b> was removed from the federal plan and state-managed fishing continues there beyond 3 nm (the June South Unimak/Shumagin fisheries) — follow the ADF&amp;G announcement's own boundaries."};
  const fb=document.getElementById("fedbanner");
  const fn=FED_NOTES[area+"|"+gear]||FED_NOTES_AREA[area];
  if(fn){ fb.hidden=false; fb.innerHTML=fn; } else { fb.hidden=true; }
  // gear tabs (hidden when an area has no per-gear status yet)
  const gr=document.getElementById("gearrow"); gr.innerHTML=""; gr.style.display=cur.status_live?"flex":"none";
  GEARS.forEach(g=>{ const t=gearTally(g);
    const n = t.open || t.up || 0;
    const kind = t.open ? "open" : (t.up ? "up" : "zero");
    const b=document.createElement("button"); b.className="gearbtn"; b.setAttribute("role","tab");
    b.setAttribute("aria-selected", g===gear);
    b.title = t.open ? `${t.open} open now${t.up?` · ${t.up} opening soon`:""}`
            : (t.up ? `${t.up} opening soon — nothing open right now`
                    : `Nothing open and nothing announced to open under ${GEAR_LABEL[g]||g}`);
    b.innerHTML=`${GEAR_LABEL[g]||g} <span class="n n-${kind}" data-tally="${t.open}/${t.up}">${n}</span>`;
    b.onclick=()=>{gear=g;render()}; gr.appendChild(b); });
  // my-districts chips (hidden when an area has only one district — no use pinning)
  document.getElementById("pins").hidden = districtsList().length<=1;
  const pc=document.getElementById("pinchips"); pc.innerHTML="";
  districtsList().forEach(d=>{ const b=document.createElement("button"); b.className="pinchip";
    b.setAttribute("aria-pressed",pins.has(d)); b.textContent=d.replace("District ","D");
    b.title=d; b.onclick=()=>{ pins.has(d)?pins.delete(d):pins.add(d); savePins(); render(); };
    pc.appendChild(b); });
  // district dropdown
  // rebuilt when the gear changes: a gear-scoped unit's district (the federal
  // EEZ, troll-only) must not be offered under a gear that cannot fish it
  const ds=document.getElementById("distsel"); if(ds.dataset.builtFor!==area+"|"+gear){
    ds.innerHTML='<option value="">All '+(DATA.unit_label==="Section"?"districts":"areas")+'</option>';
    const dn=[...new Set(ORDER.filter(c=>gearOK(c)).map(c=>DATA.sections[c].district_name))].sort((a,b)=>{
      const na=parseInt((a.match(/\d+/)||[999])[0]), nb=parseInt((b.match(/\d+/)||[999])[0]); return na-nb;});
    dn.forEach(d=>{const o=document.createElement("option");o.value=d;o.textContent=d;ds.appendChild(o);});
    if(dist&&!dn.includes(dist)){dist="";}
    ds.value=dist||"";
    ds.dataset.builtFor=area+"|"+gear;
    ds.onchange=()=>{dist=ds.value;render()};
  }
  // OPENING SOON — the positioning board, REGIONAL (client call: captains plan
  // within their area). Every announced opening in THIS area in the next 72
  // hours, any gear, soonest first, with the announcement's exact time and a
  // countdown; tap a row to open that unit's detail in its gear.
  const upHost=document.getElementById("upcshelf");
  if(upHost){
    const ups=upcomingSoon(72, area);
    if(ups.length){
      upHost.hidden=false;
      upHost.innerHTML=`<div class="pk-h" style="color:var(--upcoming)">Opening soon in ${(cur.label||"this area")} — next 72 hours</div>
        <ul style="list-style:none;margin:8px 0 0;padding:0">${ups.map(u=>
          `<li class="uprow" data-a="${u.area}" data-g="${u.gear}" ${u.tha?'data-tha="1"':'data-c="'+String(u.code).replace(/"/g,'&quot;')+'"'} style="display:flex;gap:10px;align-items:baseline;padding:7px 4px;border-top:1px solid var(--line);cursor:pointer">
             <b style="color:var(--upcoming);white-space:nowrap">${u.when}</b>
             <span style="color:var(--upcoming);font-weight:700;white-space:nowrap">${u.rel}</span>
             <span style="font-weight:700">${u.name.replace(/</g,'&lt;')}</span>
             <span style="color:var(--muted)">${u.tha?('hatchery pocket'+(u.gear?' — '+u.gear:'')):(GEAR_LABEL[u.gear]||u.gear)}</span></li>`).join("")}</ul>
        <div class="pk-note">Times are the announcement's own opening times (Alaska time). Tap a row for that water's chart and exact words — confirm with ADF&amp;G before you set.</div>`;
      upHost.onclick=e=>{ const r=e.target.closest(".uprow"); if(!r) return;
        if(r.dataset.tha){ const t=document.getElementById("thashelf"); if(t&&!t.hidden) t.scrollIntoView({behavior:"smooth",block:"center"}); return; }
        gear=r.dataset.g; render(); openDetail(r.dataset.c); };
    } else { upHost.hidden=true; upHost.innerHTML=""; }
  }
  // TERMINAL HARVEST AREA advisories with no mappable host (Deep Inlet):
  // the pocket's own words, named, newest per pocket — never painted onto
  // the surrounding sections, which a pocket closure does not change
  const thHost=document.getElementById("thashelf");
  if(thHost){
    const notes=(DATA.tha_notes||[]);
    if(notes.length){
      thHost.hidden=false;
      thHost.innerHTML=`<div class="pk-h">Hatchery terminal-area advisories</div>
        <ul style="list-style:none;margin:8px 0 0;padding:0">${notes.map(n=>{
          // both ends here too (axiom 36): a pocket whose window has ENDED
          // was still printing OPEN on the advisories shelf.
          const _ns=n.starts?new Date(n.starts).getTime():null, _ne=n.ends?new Date(n.ends).getTime():null;
          const fut=_ns&&isFinite(_ns)&&_ns>Date.now();
          const done=_ne&&isFinite(_ne)&&_ne<Date.now();
          return `<li style="display:flex;gap:10px;align-items:baseline;padding:7px 4px;border-top:1px solid var(--line)">
             <b style="white-space:nowrap;color:${(n.status==='closed'||done)?'var(--closed)':fut?'var(--upcoming)':'var(--open)'}">${(n.status==='closed'||done)?'CLOSED':fut?'OPENS SOON':'OPEN'}</b>
             <span><b>${String(n.name).replace(/</g,'&lt;')} THA</b> — <i>“${String(n.text||'').replace(/</g,'&lt;')}”</i>${n.eo?' (EO '+n.eo+')':''}</span></li>`;}).join("")}</ul>
        <div class="pk-note">A terminal-area advisory governs the hatchery pocket only — the surrounding sections' status is unchanged. Verbatim from the ADF&amp;G announcement.</div>`;
    } else { thHost.hidden=true; thHost.innerHTML=""; }
  }
  // summary
  const sm=document.getElementById("summary");
  if(!areaLive()){
    const unit=(DATA.unit_label||"unit"); const plural=ORDER.length===1?unit:unit+"s";
    sm.innerHTML=`<div class="stat ref"><div class="big">${ORDER.length}</div><div class="lab">${plural} — boundaries shown</div></div>`;
  } else {
    const counts={open:0,upcoming:0,partial:0,closed:0,none:0,unknown:0};
    ORDER.forEach(c=>{if(!gearOK(c))return; const st=statusOf(c); if(counts[st]!==undefined)counts[st]++;});
    const tiles=[["open","Open"],["upcoming","Opens soon"],["partial","Partly open"],["closed","Closed"],["none","No opening"],["unknown","No announcement"]]
      .filter(([k])=> k==="open"||k==="upcoming"||k==="closed" || counts[k]>0);
    // hatchery pockets announced to open inside 72 h count toward the
    // Opens-soon tile's story (they are not sections, so they are named
    // in the label, not folded into the section count)
    const thaUp=upcomingSoon(72, area).filter(u=>u.tha).length;
    sm.innerHTML=tiles
      .map(([k,l])=>`<div class="stat ${k}"><div class="big">${counts[k]}</div><div class="lab">${l}${k==="upcoming"&&thaUp?" + "+thaUp+" hatchery pocket"+(thaUp>1?"s":""):""}</div></div>`).join("");
  }
  // area overview map (redraws for the current gear)
  renderAreaMap();
  // cards
  const g=document.getElementById("grid"); g.innerHTML="";
  let shown=0;
  const RANK={open:0,upcoming:1,partial:2,closed:3,none:4,unknown:5};
  const pinOf=c=>pins.has(DATA.sections[c].district_name)?0:1;
  const sorted=[...ORDER].sort((a,b)=>{ const p=pinOf(a)-pinOf(b); if(p) return p;
    const r=RANK[statusOf(a)]-RANK[statusOf(b)]; if(r) return r;
    const na=parseInt(a),nb=parseInt(b); if(na!==nb) return na-nb; return a<b?-1:1; });
  let pinnedHdDone=false, unpinnedHdDone=false;
  sorted.forEach(code=>{
    const s=DATA.sections[code]; const st=statusOf(code); const rec=recOf(code);
    if(!gearOK(code)) return;
    if(dist && s.district_name!==dist) return;
    if(filter==="active" && (st==="none"||st==="unknown")) return;
    if(filter==="upcoming" && st!=="upcoming") return;
    if(q){ const hay=(s.name+" "+s.district_name+" "+code).toLowerCase(); if(!hay.includes(q)) return; }
    if(pins.size){ const isPin=pins.has(s.district_name);
      if(isPin&&!pinnedHdDone){ const h=document.createElement("div"); h.className="pinned-hd"; h.textContent="\u2605 Your districts"; g.appendChild(h); pinnedHdDone=true; }
      if(!isPin&&!unpinnedHdDone){ const h=document.createElement("div"); h.className="pinned-hd"; h.style.color="var(--muted)"; h.textContent="Other districts"; g.appendChild(h); unpinnedHdDone=true; } }
    shown++;
    const card=document.createElement("div"); card.className="card s-"+st;
    card.innerHTML=`<div class="map">${miniSVG(code,320,200)}<span class="statusband">${STLAB[st]}</span></div>
      <div class="cbody">
        <div class="cname">${s.name.replace(/^Section /,'Section ')}</div>
        <div class="cdist">${s.district_name}</div>
        <div class="ctime">${st==="ref"?"Boundary reference · live status not wired yet":fmtWhen(rec)}</div>
        <div class="cfoot">${rec&&rec.eo?`<span class="eo">EO ${rec.eo}</span>`:''}<span>${st==="ref"?(DATA.unit_label||"Boundary"):GEAR_LABEL[gear]}</span>${rec&&rec.scope==='district'?'<span>district-wide order</span>':''}</div>
      </div>`;
    card.onclick=()=>openDetail(code);
    g.appendChild(card);
  });
  document.getElementById("empty").hidden=shown>0;
}
function setupZoom(svg, controls){
  const vb0=svg.getAttribute("viewBox").split(" ").map(Number);
  let vb=vb0.slice();
  const MAXIN=40;
  const pat=svg.querySelector("#permhatch");
  function apply(){ svg.setAttribute("viewBox", vb.map(n=>n.toFixed(2)).join(" "));
    if(pat){ const k=vb[2]/vb0[2]; pat.setAttribute("patternTransform","rotate(45) scale("+k.toFixed(4)+")"); } }
  function zoomAt(px,py,f){ // px,py in 0..1 of element
    let nw=vb[2]*f, nh=vb[3]*f;
    nw=Math.min(Math.max(nw,vb0[2]/MAXIN),vb0[2]); nh=Math.min(Math.max(nh,vb0[3]/MAXIN),vb0[3]);
    vb[0]+=px*(vb[2]-nw); vb[1]+=py*(vb[3]-nh); vb[2]=nw; vb[3]=nh; apply();
  }
  svg.style.cursor="grab";
  svg.addEventListener("wheel",e=>{ e.preventDefault(); const r=svg.getBoundingClientRect();
    zoomAt((e.clientX-r.left)/r.width,(e.clientY-r.top)/r.height, e.deltaY<0?0.83:1/0.83); },{passive:false});
  // CAPTURE ONLY ONCE A DRAG IS REAL (ledger #72). Capturing on pointerdown
  // retargeted the pointerup AND the derived click to the svg itself, so
  // e.target.closest("[data-area]"/".amsec") found nothing and every REAL
  // tap on an area or section died — while the harness's synthetic
  // dispatchEvent (which never goes through capture) kept passing. A
  // stationary tap must never be captured; capture begins only after the
  // pointer has actually moved (it exists to keep a pan alive when the
  // pointer leaves the svg mid-drag, nothing else).
  let drag=false,lx,ly,sx,sy,capd=false;
  svg.addEventListener("pointerdown",e=>{drag=true;lx=sx=e.clientX;ly=sy=e.clientY;capd=false;svg.style.cursor="grabbing";});
  svg.addEventListener("pointermove",e=>{ if(!drag)return;
    if(!capd&&Math.hypot(e.clientX-sx,e.clientY-sy)>5){capd=true;try{svg.setPointerCapture(e.pointerId)}catch(_){}}
    const r=svg.getBoundingClientRect();
    vb[0]-=(e.clientX-lx)/r.width*vb[2]; vb[1]-=(e.clientY-ly)/r.height*vb[3]; lx=e.clientX;ly=e.clientY; apply(); });
  svg.addEventListener("pointerup",()=>{drag=false;capd=false;svg.style.cursor="grab";});
  svg.addEventListener("pointercancel",()=>{drag=false;capd=false;});
  svg.addEventListener("dblclick",e=>{e.preventDefault(); vb=vb0.slice(); apply();});
  let pd=0;
  svg.addEventListener("touchmove",e=>{ if(e.touches.length===2){ e.preventDefault();
    const dx=e.touches[0].clientX-e.touches[1].clientX, dy=e.touches[0].clientY-e.touches[1].clientY, d=Math.hypot(dx,dy);
    if(pd){ const r=svg.getBoundingClientRect();
      zoomAt(((e.touches[0].clientX+e.touches[1].clientX)/2-r.left)/r.width,((e.touches[0].clientY+e.touches[1].clientY)/2-r.top)/r.height, pd/d); }
    pd=d; } },{passive:false});
  svg.addEventListener("touchend",()=>{pd=0;});
  if(controls) controls.onclick=e=>{ const z=e.target.dataset.z; if(!z)return;
    if(z==="reset"){vb=vb0.slice();apply();} else zoomAt(0.5,0.5, z==="in"?0.7:1/0.7); };
  // animated fly-to: tap an area on the Alaska map (or a section on an area
  // map) and the view zooms and centers on it before navigating. Goes through
  // this closure's own vb state so wheel/pinch zoom continues seamlessly.
  svg.__zoomTo=function(tb, ms, cb){
    let [x,y,w,h]=tb;
    if(![x,y,w,h].every(isFinite)||w<=0||h<=0){ cb&&cb(); return; }
    const px=w*0.12, py=h*0.12; x-=px; y-=py; w+=2*px; h+=2*py;
    const ar=vb0[2]/vb0[3];                       // keep the svg's aspect
    if(w/h>ar){ const nh=w/ar; y-=(nh-h)/2; h=nh; } else { const nw=h*ar; x-=(nw-w)/2; w=nw; }
    const minw=vb0[2]/MAXIN;                      // respect the zoom ceiling
    if(w<minw){ const k=minw/w; x-=(w*k-w)/2; y-=(h*k-h)/2; w*=k; h*=k; }
    const t=[x,y,w,h], s=vb.slice();
    const red=window.matchMedia&&matchMedia("(prefers-reduced-motion: reduce)").matches;
    if(red||!ms){ vb=t; apply(); cb&&cb(); return; }
    // NAVIGATION MUST NEVER DEPEND ON THE ANIMATION SYSTEM (ledger #78):
    // some real surfaces starve requestAnimationFrame entirely (embedded
    // panes, throttled background tabs) while still delivering clicks —
    // there the rAF loop never ran, so the tap "did nothing" forever. The
    // watchdog guarantees the zoom LANDS and the navigation fires even if
    // not one animation frame is ever granted.
    let done=false;
    const finish=()=>{ if(done) return; done=true; vb=t.slice(); apply(); cb&&cb(); };
    const wd=setTimeout(finish, ms+250);
    const t0=performance.now();
    (function step(now){
      if(done) return;
      let u=Math.min(1,((now||performance.now())-t0)/ms);
      u=u<0.5?2*u*u:1-Math.pow(-2*u+2,2)/2;       // easeInOutQuad
      vb=[s[0]+(t[0]-s[0])*u, s[1]+(t[1]-s[1])*u, s[2]+(t[2]-s[2])*u, s[3]+(t[3]-s[3])*u];
      apply();
      if(u<1) requestAnimationFrame(step); else { clearTimeout(wd); finish(); }
    })(t0);
  };
}
function openDetail(code,_nohist){
  const s=DATA.sections[code]; const st=statusOf(code); const rec=recOf(code);
  const rules=(rec&&rec.rules)?rec.rules:[];
  const closedDraw=rules.filter(r=>r.status==="closed"&&r.pts&&r.pts.length>=2);
  const closedText=rules.filter(r=>r.status==="closed"&&(!r.pts||r.pts.length<2));
  const openBound=rules.filter(r=>r.status==="open"&&r.pts&&r.pts.length>=2);
  function coordsOf(r){ return (r.pt_labels&&r.pt_labels.length>=2)?`${r.pt_labels[0]} to ${r.pt_labels[1]}`:""; }
  const drawList = closedDraw.map((r,i)=>`<li><span class="num">${i+1}</span><span><b>${r.subject||'Closed area'}</b> — closed ${r.side||''} of a line from ${coordsOf(r)}</span></li>`).join("");
  const esc=t=>String(t||'').replace(/</g,'&lt;');
  const textList = closedText.map(r=>`<li><span class="num tx">•</span><span><b>${esc(r.subject)||'Closed area'}</b>${r.side?' — closed '+r.side+' portion':''}${r.text?' — <i>“'+esc(r.text)+'”</i>':' <i>(described in the EO; no line coordinates to map)</i>'}</span></li>`).join("");
  const restrText = rules.filter(r=>r.status==="restricted"&&(!r.pts||r.pts.length<2))
    .map(r=>`<li><span class="num tx" style="color:var(--partial)">•</span><span><b>${esc(r.subject)||'Area'}</b>${r.text?' — <i>“'+esc(r.text)+'”</i>':''}</span></li>`).join("");
  const openList = openBound.length?
     (st==="partial"
       ?`<div class="pk-sub">Open only <b>${openBound[0].side||''}</b> of the boundary line${openBound.length>1?'s':''} — the rest of the section is closed.</div>`
       :`<div class="pk-sub">When this opening is in effect, fishing occurs only <b>${openBound[0].side||''}</b> of the dashed boundary line on the map — the rest stays closed.</div>`):"";
  const pockets = (closedDraw.length||closedText.length||openBound.length||restrText)?
    `<div class="pockets"><div class="pk-h">${closedDraw.length||closedText.length||restrText?"What's closed or restricted here":"Where fishing is allowed"}</div>${openList}
     <ul>${drawList}${textList}${restrText}</ul>
     <div class="pk-note">On the map: <b style="color:var(--open)">green</b> = open water, <b style="color:var(--closed)">red</b> = closed. Numbers match the map. Lines are exact EO coordinates; quoted items are the announcement's own words.</div></div>`:"";
  const bands=(rec&&rec.shore_bands)?rec.shore_bands:[];
  const cw=(DATA.closed_waters||{})[code]||[];
  const cwList = cw.length?`<div class="pockets"><div class="pk-h">Permanent closed waters (always closed)</div><ul>${cw.map(c=>`<li><span class="num" style="background:transparent"><svg width="16" height="16"><rect width="16" height="16" fill="url(#permhatch)" stroke="var(--closed)"/></svg></span><span><b>${(c.name||'Closed area')}</b>${c.type?' \u2014 '+c.type:''}${c.regulation?' ('+c.regulation+')':''}</span></li>`).join("")}</ul></div>`:"";
  const shore=(rec&&(rec.shore_only||bands.length))?`<div class="pockets"><div class="pk-h" style="color:var(--partial)">Shore &amp; distance closures</div>${rec.shore_only?'<div class="pk-sub" style="background:var(--partial-bg);border-color:var(--partial-line)">Shore-only opening \u2014 fish only within the shore areas the EO describes.</div>':''}${bands.length?`<ul>${bands.map(bd=>`<li><span class="num tx" style="color:var(--partial)">\u2022</span><span><b>${bd.subject||'Area'}</b> \u2014 ${bd.text||bd.status||''}</span></li>`).join("")}</ul>`:''}<div class="pk-note">Distance-from-shore closures can't be drawn without a coastline layer \u2014 read the exact wording here and in the EO.</div></div>`:"";
  // THE COORDINATES A CAPTAIN PLOTS (ledger #89). Every point the announcement
  // states for THIS section's own opening and closure lines, in the EO's own
  // degrees-minutes AND in decimal degrees for a plotter. Never re-typed: these
  // are the same byte-clean numbers the map draws its lines from.
  const coordGroups=[];
  for(const r of rules){
    const pts=r.pts||[], labs=r.pt_labels||[];
    if(!pts.length) continue;
    coordGroups.push({status:r.status, subject:r.subject||"", text:r.text||"",
      rows:pts.map((pt,i)=>({dm:(labs[i]||"").trim(),
                             dec:pt[1].toFixed(5)+", "+pt[0].toFixed(5)}))});
  }
  const coordBlock=coordGroups.length?`<div class="pockets"><div class="pk-h">Coordinates \u2014 this ${(DATA.unit_label||'section').toLowerCase()}'s opening &amp; closure lines</div>
     ${coordGroups.map(g=>`<div style="margin:8px 0 2px"><div style="font-size:12px;font-weight:700"><span class="cdot" style="background:${COLOR[g.status]||'var(--ref)'}"></span>${(g.subject||'').replace(/</g,'&lt;')} \u2014 ${g.status==='open'?'open boundary':'closure line'}</div>
       <table class="coordtbl">${g.rows.map(rw=>`<tr><td class="dm">${(rw.dm||'\u2014').replace(/</g,'&lt;')}</td><td class="dec">${rw.dec}</td></tr>`).join("")}</table></div>`).join("")}
     <div class="pk-note">Left column is the announcement's own degrees\u2011minutes; right column is the same point in decimal degrees for a plotter. Confirm against the EO before setting gear.</div></div>`:"";

  // THE ANNOUNCEMENT, ENTIRE (ledger #89). The clause above is this parser's
  // judgement about which words belong to this section; the block below is the
  // announcement itself, so a restriction can never be hidden by that judgement
  // going wrong \u2014 which is exactly how Section 15-C came to promise "with the
  // following restriction:" and then say nothing.
  const ann=(rec&&rec.rel)?((DATA.announcements||{})[rec.rel]||null):null;
  const annBlock=(ann&&ann.text)?`<details class="annfull" open><summary>The announcement in full${ann.eo?` \u2014 EO ${String(ann.eo).replace(/</g,'&lt;')}`:''}</summary>
     <div class="annbody">${String(ann.text).replace(/&/g,'&amp;').replace(/</g,'&lt;')}</div>
     <div class="annmeta">Complete text of ${ann.title?('\u201c'+String(ann.title).replace(/</g,'&lt;')+'\u201d'):'the ADF&amp;G announcement'}${ann.published?', published '+String(ann.published).replace('T',' '):''}. ${ann.url?`<a href="${ann.url}" target="_blank" rel="noopener" style="color:var(--accent)">Open the ADF&amp;G PDF</a> \u2014 `:''}the announcement is the legal authority.</div></details>`:"";
  const sh=document.getElementById("sheet");
  sh.innerHTML=`<div class="shmap">${drawMap(code,900,620,{detail:true})}<button class="shclose" onclick="closeDetail()">×</button>
    <span class="statusband" style="left:14px;top:14px">${STLAB[st]}</span>
    <div class="zc"><button data-z="in" aria-label="Zoom in">+</button><button data-z="out" aria-label="Zoom out">\u2212</button><button data-z="reset" aria-label="Reset">\u21ba</button></div>
    <span class="zhint">scroll / pinch to zoom \u00b7 drag to pan</span></div>
   <div class="shbody"><div class="cdist">${s.district_name} &middot; ${GEAR_LABEL[gear]}</div><h2>${s.name}</h2>
     <div class="kv"><span class="k">Status</span><span class="v" style="color:${COLOR[st]};font-weight:700">${STLAB[st]}</span></div>
     <div class="kv"><span class="k">When</span><span class="v">${rec?fmtWhen(rec):(isRef()&&!areaLive()?'Boundary reference (no in-season status)':fmtWhen(rec))}</span></div>
     ${rec&&rec.starts?`<div class="kv"><span class="k">Opens</span><span class="v">${new Date(rec.starts).toLocaleString()}</span></div>`:''}
     ${rec&&rec.ends?`<div class="kv"><span class="k">Through</span><span class="v">${new Date(rec.ends).toLocaleString()}</span></div>`:''}
     ${rec&&rec.eo?`<div class="kv"><span class="k">Emergency order</span><span class="v">${rec.eo}</span></div>`:''}
     ${rec&&rec.title?`<div class="kv"><span class="k">Announcement</span><span class="v" style="font-weight:600">${rec.title}</span></div>`:''}
     ${rec&&rec.period_text?`<div class="pockets"><div class="pk-h">In the announcement's words${rec.unit_name&&rec.unit_name!==s.name?` — ${String(rec.unit_name).replace(/</g,'&lt;')}`:''}</div><div class="pk-sub" style="white-space:pre-wrap">${String(rec.period_text).replace(/</g,'&lt;')}</div><div class="pk-note">Verbatim from the ADF&amp;G announcement — where a status is “partial”, this text states exactly which waters.</div>${annBlock}</div>`:(annBlock?`<div class="pockets"><div class="pk-h">In the announcement's words</div>${annBlock}</div>`:'')}
     ${coordBlock}
     ${(isRef()||(!(s.polys&&s.polys.length)&&(s.points||s.lines)))?`<div class="pockets"><div class="pk-h">Regulatory boundary &mdash; ${(AREAS.find(a=>a.key===area)||{}).label}</div>
        <div class="pk-sub">${(s.text||'').replace(/</g,'&lt;')}</div>
        ${s.points&&s.points.length?`<ul>${s.points.map(p=>`<li><span class="num tx" style="color:var(--ref)">•</span><span>${p.name?('<b>'+p.name+'</b> — '):''}${(p.lat_dm||'')} ${(p.lon_dm||'')}</span></li>`).join("")}</ul>`:''}
        <div class="pk-note">${(DATA.source_note||'')} Dots are the regulation's coordinate points; lines are its coordinate-defined boundaries. Confirm with ADF&amp;G.</div></div>`:''}
     ${pockets}${shore}
     ${rec&&rec.scope==='district'?`<div class="notice">Status from a district-wide order for ${s.district_name}; check the announcement for section-specific lines.</div>`:''}
     ${(!areaLive())?`<div class="notice" style="background:var(--ref-bg);border-color:var(--ref-line)">This is the official ADF&amp;G boundary for orientation. Live open/closed status for ${(AREAS.find(a=>a.key===area)||{}).label} is being wired from that area's announcements — for now, confirm openings with ADF&amp;G.</div>`:(!rec?(DATA.comprehensive===false?`<div class="notice" style="background:var(--unknown-bg);border-color:var(--unknown-line);color:var(--muted)">No current ADF&amp;G advisory names this ${(DATA.unit_label||'section').toLowerCase()} for ${GEAR_LABEL[gear]}. This is <b>not</b> a closure — it just isn't covered by the latest announcement. Confirm with ADF&amp;G.</div>`:`<div class="notice">No current emergency-order opening for ${GEAR_LABEL[gear]} in this section — usually means it is not open to this fishery now. Confirm with ADF&amp;G.</div>`):'')}
     <div class="notice" style="background:var(--none-bg);border-color:var(--none-line);color:var(--muted)">Boundaries are ADF&amp;G official polygons; closed areas are computed from the EO's own coordinates. Planning snapshot as of ${fmtAsOf(DATA.as_of)} — the ADF&amp;G announcement is the legal authority.</div>
   </div>`;
  const dm=sh.querySelector(".shmap svg"); if(dm) setupZoom(dm, sh.querySelector(".zc"));
  document.getElementById("modal").classList.add("on");
  _openCode=code; if(!_nohist) navPush();
}
function closeDetail(_nohist){
  document.getElementById("modal").classList.remove("on");
  const had=_openCode; _openCode=null;
  // closing by \u00d7 or backdrop walks history back too, so the browser's own
  // back button never has to replay a sheet the captain already dismissed
  if(!_nohist && !_hist && had && history.state && history.state.v==="afo" && history.state.code){
    try{ history.back(); }catch(e){}
  }
}
document.getElementById("modal").onclick=e=>{if(e.target.id==="modal")closeDetail()};
document.getElementById("filterseg").onclick=e=>{const b=e.target.closest("button");if(!b)return;
  filter=b.dataset.f;[...e.currentTarget.children].forEach(x=>x.setAttribute("aria-pressed",x===b));render();};
document.getElementById("search").oninput=e=>{q=e.target.value.toLowerCase().trim();render();};
function themeLabel(){
  // the button names the screen you will GET, not the one you have
  const dark=document.documentElement.dataset.theme==="dark";
  const l=document.getElementById("themelabel"), g=document.getElementById("themeglyph");
  if(l) l.textContent=dark?"Light screen":"Dark screen";
  if(g) g.innerHTML=dark?"&#9728;":"&#9790;";   // sun to go light, moon to go dark
}
document.getElementById("themebtn").onclick=()=>{
  const cur=document.documentElement.dataset.theme==="dark"?"light":"dark";
  document.documentElement.dataset.theme=cur;
  try{localStorage.setItem("afo_theme",cur)}catch(e){}
  themeLabel();
  render();   // maps re-emit so SVG picks up the palette everywhere
};
themeLabel();
render();
</script>
</body></html>'''

HTML = HTML.replace("__UNREAD_ALL__", json.dumps(UNREAD_ALL))
HTML = HTML.replace("__UNREAD__", json.dumps(UNREAD))
HTML = HTML.replace("__ENGINE__", ENGINE_STAMP)
HTML = HTML.replace("__DATA__", DATA_JSON)
open("SE_Openings.html","w",encoding="utf-8").write(HTML)
import os
print("wrote SE_Openings_v2.html:", round(os.path.getsize("SE_Openings.html")/1024,1),"KB", "engine", ENGINE_STAMP)
