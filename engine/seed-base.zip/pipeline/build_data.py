#!/usr/bin/env python3
"""Consolidate extracted ADF&G announcements into one dataset for the chart app.

Coordinate notation varies by area office. Observed in real releases:
    55°19.57′ N lat      Southeast  (U+00B0 degree, U+2032 prime)
    60° 26.49' N.        Prince William Sound (space, ASCII apostrophe, trailing period)
    61º 02.855' N.       PWS Eastern District (U+00BA MASCULINE ORDINAL, 3 decimals)
    64° 53.273' N        Yukon
Anything that does not parse is kept as text and flagged, never guessed.
"""
import json, glob, re, os, unicodedata, datetime as dt
try:
    from zoneinfo import ZoneInfo            # present with system tz db or the tzdata pkg
    _HAVE_ZONEINFO = True
except Exception:                             # pragma: no cover
    _HAVE_ZONEINFO = False


class _AlaskaTZ(dt.tzinfo):
    """Self-contained America/Anchorage — used when zoneinfo has no database
    (bundled Windows Python ships none, and tzdata is not included). AKST is
    UTC-9; AKDT is UTC-8 from the 2nd Sunday of March to the 1st Sunday of
    November (US rule since 2007). Enough to stamp 'now' in Alaska time."""
    def _dst_on(self, d):
        y = d.year
        # 2nd Sunday of March, 02:00
        mar = dt.datetime(y, 3, 8); mar += dt.timedelta(days=(6 - mar.weekday()) % 7)
        start = mar.replace(hour=2)
        # 1st Sunday of November, 02:00
        nov = dt.datetime(y, 11, 1); nov += dt.timedelta(days=(6 - nov.weekday()) % 7)
        end = nov.replace(hour=2)
        return start <= d.replace(tzinfo=None) < end
    def utcoffset(self, d):
        return dt.timedelta(hours=-8 if self._dst_on(d) else -9)
    def dst(self, d):
        return dt.timedelta(hours=1) if self._dst_on(d) else dt.timedelta(0)
    def tzname(self, d):
        return "AKDT" if self._dst_on(d) else "AKST"


def _alaska_tz():
    if _HAVE_ZONEINFO:
        try:
            return ZoneInfo("America/Anchorage")
        except Exception:
            pass
    return _AlaskaTZ()
from timemodel import parse_period, state_of, fishery_key, weekly_pattern, open_now

DEG = "[°º˚̊]"          # degree sign, masculine ordinal, ring above
MIN = "[′'’´]"               # prime, apostrophe, right single quote, acute
COORD = re.compile(
    r"(?P<deg>\d{1,3})\s*" + DEG + r"\s*(?P<min>\d{1,2}(?:\.\d+)?)\s*" + MIN + r"?\s*"
    r"(?P<hem>[NSEW])", re.I)

COORD_NOHEM = re.compile(r"(?P<deg>\d{1,3})\s*" + DEG + r"\s*(?P<min>\d{1,2}(?:\.\d+)?)\s*" + MIN + r"?")

# The codified regulation text carries typographic defects that the extraction
# preserved verbatim rather than silently "fixing" — which was right, but the
# converter still has to read them or real closures are lost.
#
# These are NAMED repairs for observed defects, not permissive parsing. An
# earlier attempt used a cascade of loose regexes and quietly turned
# "131 41.88' W. long." into -42.47: a loose parser does not fail, it invents.
# Each repair below is specific, is recorded in `repairs` so it can be audited,
# and is followed by the same strict parse and Alaska bounds check as clean text.
REPAIRS = [
    # 54° 40,00'  ->  54° 40.00'      comma where the decimal point belongs
    (re.compile(r"(\d{1,3}\s*[°º]\s*\d{1,2}),(\d+)"), r"\1.\2", "comma for decimal point"),
    # 132" 16.94' ->  132° 16.94'     straight double quote for the degree sign
    (re.compile(r"(\d{1,3})\s*\"\s*(\d{1,2}\.\d+)"), r"\1° \2", "double quote for degree sign"),
    # 130° 50'.00 ->  130° 50.00'     prime and decimal point transposed
    (re.compile(r"(\d{1,3}\s*[°º]\s*\d{1,2})['\u2032]\.(\d+)"), r"\1.\2'", "prime and decimal transposed"),
    # 133.00.00'  ->  133° 00.00'     periods for both degree sign and separator
    (re.compile(r"(\d{1,3})\.(\d{2})\.(\d{2})\s*['\u2032]"), r"\1° \2.\3'", "periods for degree sign"),
    # 58 51.00'   ->  58° 51.00'      degree sign missing entirely
    (re.compile(r"(?<![\d.])(\d{1,3})\s+(\d{1,2}\.\d+)\s*['\u2032]"), r"\1° \2'", "degree sign missing"),
    # 162° 54 .40' -> 162° 54.40'    stray space before the decimal point
    #
    # 5 AAC 05.200(a) and (h) both print the offshore point of the Point Romanof
    # line as "162° 54 .40' W. long." — the space is in the codified text and both
    # mirrors reproduce it. Left alone it does not fail loudly: COORD cannot match
    # (no hemisphere follows the minutes) so COORD_NOHEM matches and returns
    # 162° 54' = -162.9, silently discarding 0.40' — about 400 m of Yukon delta
    # boundary, and exactly the kind of quiet wrongness that fines a fisherman.
    # Named and narrow: it fires only on degrees-minutes followed by whitespace
    # and a decimal fraction, and it is reported like every other repair.
    (re.compile(r"(\d{1,3}\s*[°º]\s*\d{1,2})\s+\.(\d+)"), r"\1.\2", "space before decimal point in minutes"),
]
# A latitude cannot carry an east/west hemisphere. 5 AAC 33.200(h) prints
# Babbler Point as "56° 29.08' W. lat." — the W is a typo for N, and taking it
# literally put the point in the southern hemisphere. Unambiguous, so repaired;
# the reverse case (a longitude marked N or S) is equally unambiguous.
AXIS_HEM = [
    ("lat", re.compile(r"([EW])(\.?\s*lat)", re.I), "N", "east/west hemisphere on a latitude"),
    ("lon", re.compile(r"([NS])(\.?\s*long)", re.I), "W", "north/south hemisphere on a longitude"),
]
repairs = []

def repair(sv, where):
    """Apply the named repairs, recording any that fire."""
    if not sv: return sv
    t = str(sv)
    for rx, sub, why in REPAIRS:
        t2 = rx.sub(sub, t)
        if t2 != t:
            repairs.append(f"{where}: {why} — {sv!r} read as {t2!r}")
            t = t2
    for axis, rx, good, why in AXIS_HEM:
        if where != axis: continue
        t2 = rx.sub(good + r"\2", t)
        if t2 != t:
            repairs.append(f"{where}: {why} — {sv!r} read as {t2!r}")
            t = t2
    return t

def to_decimal(s, axis=None):
    """'55°19.57′ N' -> 55.32617 ; returns (value, ok).

    Some regulation text drops the hemisphere ("57° 01.11' lat."). Every Alaska
    salmon coordinate is north latitude and west longitude, so when the field
    itself tells us which axis it is, the hemisphere is inferred rather than the
    coordinate being thrown away. A missing hemisphere is recoverable; a value in
    the wrong field is not, and is still rejected by the bounds check."""
    if not s: return None, True                      # legitimately absent
    s = repair(s, axis or "coord")
    m = COORD.search(str(s))
    if m:
        v = int(m.group("deg")) + float(m.group("min")) / 60.0
        if m.group("hem").upper() in ("S", "W"): v = -v
        return round(v, 6), True
    m = COORD_NOHEM.search(str(s))
    if m and axis in ("lat", "lon"):
        v = int(m.group("deg")) + float(m.group("min")) / 60.0
        if axis == "lon": v = -v
        return round(v, 6), True
    return None, False                               # present but unparseable

def _prov(kd):
    """Several regulation files record that their text came from an AAC mirror
    rather than the ADF&G PDF (WebFetch truncates that PDF before chapter 33).
    The agents that wrote them used different key names and shapes, so read
    defensively rather than assuming one."""
    for k in ("text_source_url", "provenance", "text_provenance",
              "source_note", "extraction_note", "source_document_caveat"):
        v = kd.get(k)
        if isinstance(v, str) and v: return v
        if isinstance(v, dict):
            for kk in ("url", "text_source_url", "source_url", "note"):
                if v.get(kk): return v[kk]
    return None

AREA_NAME = {
    "sand point":  "Alaska Peninsula (Area M)",
    "port moller": "Alaska Peninsula (Area M)",
    "cold bay":    "Alaska Peninsula (Area M)",
    "chignik":     "Chignik",
    "kotzebue":    "Norton Sound & Kotzebue",
    "norton sound":"Norton Sound & Kotzebue",
}

def yr_of(d):
    pub = (d.get("published") or "")
    return int(pub[:4]) if pub[:4].isdigit() else 2026

def clean(t):
    if t is None: return None
    return unicodedata.normalize("NFC", str(t)).strip()

problems, releases = [], []
# Regulation files live in the same directory but are a different kind of thing.
# Globbing them into the announcement loop silently inflated the release count
# from 16 to 21 and the area count from 272 to 515.
REG_FILE = re.compile(r"(regulations|_reg_)", re.I)
for f in sorted(glob.glob("raw/*.json")):
    if REG_FILE.search(os.path.basename(f)):
        continue
    d = json.load(open(f, encoding="utf-8"))
    rid = d.get("release_id") or os.path.basename(f)[:-5]
    areas_out = []
    for a in d.get("areas", []):
        rules_out = []
        for r in a.get("rules", []):
            pts = []
            for p in r.get("points", []):
                lat, ok1 = to_decimal(p.get("lat_dm"), "lat")
                lon, ok2 = to_decimal(p.get("lon_dm"), "lon")
                if not ok1: problems.append(f"{rid}: unparseable latitude {p.get('lat_dm')!r} ({r.get('subject')})")
                if not ok2: problems.append(f"{rid}: unparseable longitude {p.get('lon_dm')!r} ({r.get('subject')})")
                if lat is None and lon is None:
                    pts.append({"name": clean(p.get("name")), "lat": None, "lon": None,
                                "lat_dm": clean(p.get("lat_dm")), "lon_dm": clean(p.get("lon_dm"))})
                    continue
                # sanity: Alaska waters only. Anything else is an extraction error, not data.
                if lat is not None and not (50 <= lat <= 72):
                    problems.append(f"{rid}: latitude {lat} outside Alaska ({r.get('subject')})"); lat = None
                if lon is not None and not (-180 <= lon <= -125):
                    problems.append(f"{rid}: longitude {lon} outside Alaska ({r.get('subject')})"); lon = None
                pts.append({"name": clean(p.get("name")), "lat": lat, "lon": lon,
                            "lat_dm": clean(p.get("lat_dm")), "lon_dm": clean(p.get("lon_dm"))})
            geom = (r.get("geometry") or "other").lower()
            status = (r.get("status") or "").lower() or None
            text = clean(r.get("text")) or ""
            mappable = any(p["lat"] is not None or p["lon"] is not None for p in pts)

            # "the Boat Harbor THA will close at 11:59 p.m. Saturday, August 29"
            # is not a closure that is in force now — the water is OPEN until
            # then. Stored as a plain closure it was wrong twice over: it showed
            # closed water as closed while it was still open, and then expired
            # out of the dataset at the very moment the closure took effect.
            future_close = None
            if status == "closed" and re.search(r"\bwill\s+(?:be\s+)?clos", text, re.I):
                _s, _e, _c = parse_period(text, yr_of(d), clean(d.get("published")))
                if _e: future_close = _e

            # Whether a rule can be DRAWN is not the same as whether it can be
            # EVALUATED at a position. A 2-nmi shoreline buffer has no
            # coordinates and cannot be drawn, but it also cannot be tested
            # without a coastline — so a position inside that area is not
            # "open", it is UNDETERMINED. Recording the distinction here is what
            # lets the app refuse to paint water green that it cannot vouch for.
            # WHAT ACTUALLY BLOCKS A CHART, and what only looked like it did.
            #
            # The first cut treated anything without coordinates as undrawable
            # and refused to shade its whole area. That was backwards in two
            # ways, and between them it left Deep Inlet — open, with its
            # boundary sitting in 5 AAC 33.374 — painted red, which on this
            # chart means CLOSED. Telling a seiner that open water is shut is
            # the worst thing this file can do.
            #
            #  * "The Outer Karluk, Outer Ayakulik ... Sections" is an OPENING.
            #    It carries no coordinates because it does not need any: it
            #    names the area, and the regulation defines the area. Where we
            #    have that definition the rule is not merely drawable, it IS
            #    the extent.
            #  * "closed to the retention of Chinook salmon", "no more than 20
            #    fathoms of gear", "closed waters are as described in the
            #    regulation book" — these are CONDITIONS, not geography. A size
            #    limit does not close water. The regulation-book sentence points
            #    at the standing 5 AAC closures, which are already drawn.
            #    Blocking a chart on these hid real openings behind nothing.
            geo = geom in ("lat_cutoff", "lon_cutoff", "line", "polygon")
            evaluable = (mappable and geo)
            # A rule about FISH or GEAR is not a rule about WATER. These were
            # blocking whole districts from being drawn: "Subsistence fishing for
            # Chinook, chum, and coho salmon is closed and these salmon species
            # must be released alive" closes no water at all, and it was hiding
            # every open Yukon district behind it.
            CONDITION = re.compile(
                r"retention|retain|may not be kept|released? alive|returned to the water|"
                r"size limit|inches|fathom|mesh|gear is restricted|"
                r"fishing for (?:[a-z, ]*)?(?:chinook|chum|coho|sockeye|pink|king|red|salmon)"
                r"[a-z, ]*\s+is\s+closed|"
                r"as described in the regulation book|adjusted by emergency order|"
                r"permit holder|logbook|reporting|fish ticket|onboard|observer", re.I)
            # A CLOSING DATE IS NOT A PLACE. "The Anita Bay THA will close for
            # the season at 11:59 p.m., Tuesday, November 10, 2026" says nothing
            # about where the water is; it is the end date of a season that is
            # in force right now. It was classified unknown_extent and it kept
            # Anita Bay off the chart three times over while the THA was open.
            SCHEDULE = re.compile(
                r"(?:will\s+)?(?:close|open|reopen|remain\s+(?:open|closed))"
                r"[^.]{0,80}?(?:for the season|at\s+\d{1,2}(?::\d\d)?\s*(?:a\.?m|p\.?m|noon|midnight)"
                r"|on\s+(?:monday|tuesday|wednesday|thursday|friday|saturday|sunday))", re.I)
            # A named exclusion we cannot draw — "excluding waters of the
            # Annette Islands Reserve". Refusing to draw the whole District 1
            # troll opening over it lost far more information than it protected.
            # ADF&G prints the exclusion in words on their own sheets; so does
            # this one now, and the area is drawn with the caveat carried.
            # Anything that actually points at a piece of water. A sentence with
            # none of these in it is not describing a boundary.
            SPATIAL = re.compile(
                r"north(?:erly|ward)? of|south(?:erly|ward)? of|east(?:erly|ward)? of|"
                r"west(?:erly|ward)? of|within|inside|outside|shoreward|seaward|"
                r"line from|line between|latitude|longitude|\d+\s*°|nautical mile|"
                r"\byards\b|\bfathom line\b|waters of|portion of|section of", re.I)
            NAMED_EXCL = re.compile(
                r"\b(?:excluding|except(?:ing)?|other than|does not (?:apply|include))\b", re.I)
            kind = None
            if not evaluable:
                if status == "open":
                    # An OPEN rule can only ADD water. It cannot subtract any, so
                    # it can never be the reason an area goes undrawn. This used
                    # to catch only geom=="whole_area", and "the troll fishery
                    # will remain open continuously in the troll exclusive area
                    # outside the SHA" — an OPENING — fell through to
                    # unknown_extent and suppressed its own area.
                    kind = "names_the_area"
                elif SCHEDULE.search(text or "") and not SPATIAL.search(text or ""):
                    kind = "schedule"                # a date, not a boundary
                elif NAMED_EXCL.search(text or ""):
                    kind = "named_exclusion"         # drawn, with the words carried
                elif geom in ("buffer", "distance_from_shore"):
                    kind = "shore_band"
                elif CONDITION.search(text or ""):
                    kind = "condition"               # a rule about fish or gear, not water
                elif geom == "river_reach":
                    # Fresh water. In a river fishery this IS the geography and
                    # it blocks; in a marine area a rule about stream channels
                    # says nothing about where a seiner may set. Deep Inlet's
                    # last blocker was "no restrictions will be in effect for
                    # Deep Inlet THA salmon streams" — a sentence about
                    # freshwater, and it was hiding a live marine opening.
                    kind = "freshwater"
                else:
                    kind = "unknown_extent"          # could be anywhere in the area
            why = None
            if not evaluable:
                why = {"buffer": "distance from a shoreline this app has no coastline for",
                       "whole_area": "names an area without giving its boundary coordinates",
                       "river_reach": "described by river miles and markers, not coordinates",
                       "distance_from_shore": "distance from a shoreline this app has no coastline for",
                       "lon_band": "a longitude band the extractor did not resolve to two edges",
                       "other": "wording this app cannot turn into geometry",
                      }.get(geom, "no usable coordinates")

            rules_out.append({
                "subject": clean(r.get("subject")), "status": status,
                "geometry": geom, "side": clean(r.get("side")),
                "distance_nmi": r.get("distance_nmi"), "text": text, "points": pts,
                "mappable": mappable,
                "evaluable": evaluable,
                "blocker_kind": kind,
                "not_evaluable_because": why,
                "future_close": future_close,
            })
        pub = clean(d.get("published"))
        yr = int((pub or "2026")[:4]) if (pub or "")[:4].isdigit() else 2026
        st, en, conf = parse_period(a.get("period_text"), yr, pub)
        # An area is COMPLETE only if every rule in it can be evaluated. This is
        # the gate on green. Of 79 in-force areas measured on 2026-08-23, only
        # 11 were complete: the rest carry at least one buffer, named-area or
        # river-reach rule with no geometry. Shading the drawable rules of an
        # incomplete area green paints water open that a rule the app never drew
        # may close — District 2 purse seine was doing exactly that, with a
        # "closed within 2.0 nmi of the mainland shoreline" rule invisible
        # underneath the green.
        # Not all undrawable rules are undrawable in the same way, and the
        # difference decides whether an opening can be shown at all.
        #
        #   shore_band  "closed within 2.0 nmi of the mainland shoreline" —
        #               undrawable for want of a coastline, but KNOWN IN KIND
        #               and known in place: it hugs the shore. Refusing to shade
        #               the whole section hides the fact that the section is
        #               open, which is information the fisherman needs. Shading
        #               it with the shore band called out at the point of use
        #               gives both, and the same mark carries the other caveat —
        #               that the green runs to the section's regulatory envelope
        #               rather than to the beach. Both problems live at the
        #               shore; one mark answers both.
        #   unknown     names an area or a river reach with no coordinates. Its
        #               extent could be anywhere in the section, so nothing can
        #               be shaded open.
        areas_out.append({"district": clean(a.get("district")), "section": clean(a.get("section")),
                          "status": (a.get("status") or "").lower() or None,
                          "region_wide": bool(a.get("region_wide")),
                          # a hostless THA pocket statement keeps its pocket name
                          # so restatus can surface it as a NAMED advisory
                          "tha_pocket": clean(a.get("tha_pocket")),
                          "period_text": clean(a.get("period_text")),
                          "starts": st, "ends": en, "period_confidence": conf,
                          # complete / blockers / conditions are classified after
                          # the regulatory cross-reference exists — whether a
                          # freshwater rule blocks depends on whether the area has
                          # a marine boundary, which is not known yet at this point
                          "complete": None, "shore_only": None,
                          "shore_bands": [], "conditions": [], "blockers": [],
                          "rules": rules_out})
    releases.append({
        "id": rid, "title": clean(d.get("title")), "published": clean(d.get("published")),
        # "Sand Point" is an ADF&G FIELD OFFICE, not a management area. Labelling
        # the area by the office that issues its announcements meant a Peninsula
        # seiner looking for Area M found nothing he recognised. ADF&G's own page
        # heading is "Alaska Peninsula Management Area"; permit holders say Area M.
        # Carry both, and keep the office as a sub-series.
        "region": AREA_NAME.get((clean(d.get("region")) or "").lower(), clean(d.get("region"))),
        "office": clean(d.get("region")),
        "gear": [g.lower() for g in (d.get("gear") or [])],
        "species": clean(d.get("species")), "emergency_order": clean(d.get("emergency_order")),
        "contact": clean(d.get("contact")), "next_announcement": clean(d.get("next_announcement")),
        "url": f"https://www.adfg.alaska.gov/static/applications/dcfnewsrelease/{rid}.pdf",
        # the announcement's complete body, verbatim (ledger #89) — every
        # section sheet can show the whole thing, so no attribution decision
        # this pipeline makes can keep a restriction from its captain
        "full_text": clean(d.get("full_text")) or None,
        "areas": areas_out,
    })

releases.sort(key=lambda r: (r.get("published") or ""), reverse=True)

# --- what is actually current -------------------------------------------------
# Each ADF&G release restates the whole picture for its fishery, so within one
# (region, gear) the newest release supersedes the older ones outright.
# ADF&G prints Alaska time. This container runs on UTC, so comparing the two
# put "what is open right now" eight hours out — enough to show a fishery closed
# through the whole morning it was open, and open for eight hours after it shut.
# Alaska time, always, and the page stamps which zone it is showing.
_AKTZ = _alaska_tz()
NOW = dt.datetime.now(_AKTZ).replace(tzinfo=None, microsecond=0)
TZNAME = dt.datetime.now(_AKTZ).tzname()
newest = {}
for r in releases:
    k = fishery_key(r)
    if k not in newest or (r.get("published") or "") > (newest[k].get("published") or ""):
        newest[k] = r
for r in releases:
    r["superseded_by"] = None
    top = newest.get(fishery_key(r))
    if top is not r:
        r["superseded_by"] = {"id": top["id"], "title": top["title"], "published": top["published"]}
    # An announcement whose period we could not parse is not therefore current.
    # ADF&G's index holds seven days; a release older than STALE_DAYS with no
    # readable window has almost certainly lapsed. The Aug 5 troll release —
    # window Aug 9-12, eighteen days gone — was sitting on the chart as
    # "undated" and being drawn as if in force. Undated plus old is lapsed.
    STALE_DAYS = 10
    pub = r.get("published")
    try:
        age = (NOW - dt.datetime.fromisoformat(pub)).days if pub else 999
    except ValueError:
        age = 999
    for a in r["areas"]:
        s_ = state_of(a.get("starts"), a.get("ends"), NOW)
        if s_ == "unknown" and age > STALE_DAYS:
            s_ = "lapsed"
        # A recurring weekly schedule is in force only on its own days and hours.
        # A THA that fishes Sunday, Thursday and Friday is NOT open on a Tuesday,
        # however live the season window is.
        a["weekly"] = None
        fishing, why = open_now(a.get("period_text"), a.get("starts"), a.get("ends"), NOW)
        if fishing is not None:
            pat = weekly_pattern(a.get("period_text"))
            a["weekly"] = {"days": sorted(pat[0]), "from": "%02d:%02d" % pat[1],
                           "to": "%02d:%02d" % pat[2], "fishing_now": fishing, "why": why}
            if s_ == "in_force" and not fishing:
                s_ = "not_today"
        if r["superseded_by"]:
            a["time_state"] = "superseded"
        else:
            a["time_state"] = s_
        a["release_age_days"] = age
        for x in a["rules"]:
            x["time_state"] = a["time_state"]
def _count(pred):
    return sum(1 for r in releases for a in r["areas"] for x in a["rules"] if pred(r, a, x))

stats = {
    "releases": len(releases),
    "in_force_rules": _count(lambda r,a,x: a["time_state"] == "in_force"),
    "upcoming_rules": _count(lambda r,a,x: a["time_state"] == "upcoming"),
    "expired_rules": _count(lambda r,a,x: a["time_state"] == "expired"),
    "superseded_rules": _count(lambda r,a,x: a["time_state"] == "superseded"),
    "undated_rules": _count(lambda r,a,x: a["time_state"] == "unknown"),
    "not_today_rules": _count(lambda r,a,x: a["time_state"] == "not_today"),
    "lapsed_rules": _count(lambda r,a,x: a["time_state"] == "lapsed"),
    "in_force_areas": sum(1 for r in releases for a in r["areas"]
                          if a["time_state"] == "in_force" and a["rules"]),
    "in_force_areas_complete": 0,   # filled in after classification, below
    "in_force_mappable": _count(lambda r,a,x: a["time_state"] == "in_force" and x["mappable"]),
    "areas": sum(len(r["areas"]) for r in releases),
    "rules": sum(len(a["rules"]) for r in releases for a in r["areas"]),
    "mappable_rules": sum(1 for r in releases for a in r["areas"] for x in a["rules"] if x["mappable"]),
    "coordinates": sum(1 for r in releases for a in r["areas"] for x in a["rules"]
                       for p in x["points"] if p["lat"] is not None or p["lon"] is not None),
}
# --- standing regulatory boundaries -------------------------------------------
# Announcements name areas without giving their coordinates, and point at the
# regulations to supply them — Kodiak says so outright ("as shown on the Kodiak
# Area Salmon Statistical Chart and detailed in 5 AAC 18.350"), and Southeast
# does it by convention: the ADF&G GIS service for these boundaries is literally
# named SoutheastSalmon5AAC33_200.
#
# So the regulation IS the missing geometry. 5 AAC 33.200 defines every district
# and section by coordinate; 5 AAC 33.350 defines 194 standing closed waters that
# apply whether or not an announcement repeats them. Loading them turns a rule
# that merely NAMES an area ("the Outer Karluk Section is open") into a rule with
# a boundary, by cross-reference — which is how a person reads these documents.
#
# Every regulation file is loaded, not just Kodiak's. A hardcoded filename here
# is exactly the kind of thing that silently stops picking up new data.
regulatory, reg_sources = [], []
for kp in sorted(glob.glob("raw/*regulations*.json")) + sorted(glob.glob("raw/se_reg_*.json")):
    kd = json.load(open(kp, encoding="utf-8"))
    tag = os.path.basename(kp)[:-5]
    if kd.get("source_url"): reg_sources.append({"file": tag, "url": kd["source_url"],
                                                 "citation": kd.get("citation"),
                                                 "source": kd.get("source"),
                                                 # several of these were taken from AAC mirrors
                                                 # because the ADF&G PDF truncates before ch.33
                                                 "text_source": _prov(kd)})
    for a in kd.get("areas", []):
        pts = []
        for pt in a.get("points", []):
            lat, ok1 = to_decimal(pt.get("lat_dm"), "lat"); lon, ok2 = to_decimal(pt.get("lon_dm"), "lon")
            if not ok1: problems.append(f"{tag}: unparseable lat {pt.get('lat_dm')!r} ({a.get('name')})")
            if not ok2: problems.append(f"{tag}: unparseable lon {pt.get('lon_dm')!r} ({a.get('name')})")
            if lat is not None and not (50 <= lat <= 72):
                problems.append(f"{tag}: lat {lat} outside Alaska ({a.get('name')})"); lat = None
            if lon is not None and not (-180 <= lon <= -125):
                problems.append(f"{tag}: lon {lon} outside Alaska ({a.get('name')})"); lon = None
            pts.append({"name": clean(pt.get("name")), "lat": lat, "lon": lon,
                        "lat_dm": clean(pt.get("lat_dm")), "lon_dm": clean(pt.get("lon_dm"))})
        # The regulation states which side is closed in words — "closed east of
        # a line from Quadra Point to Kah Shakes Point". Without pulling that out
        # a standing closure has a line and no side, and the renderer (correctly)
        # refuses to shade it. Only an explicit direction counts; "inside",
        # "within" and bare bay names stay sideless and are marked, not shaded.
        _t = (a.get("text") or "").lower()
        _side = None
        m_ = re.search(r"\b(?:closed|close[sd]?)\s+(?:to[^.]{0,40}?\s+)?"
                       r"(north|south|east|west|northeast|northwest|southeast|southwest)"
                       r"(?:erly)?\s+(?:of|from)\b", _t)
        if not m_:
            m_ = re.search(r"\bwaters?\s+(north|south|east|west)\s+of\b", _t)
        if m_: _side = m_.group(1)

        regulatory.append({"side": _side,
                           "kind": clean(a.get("kind")), "name": clean(a.get("name")),
                           "parent": clean(a.get("parent")), "citation": clean(a.get("citation")),
                           "text": clean(a.get("text")), "points": pts,
                           "verified_twice": a.get("verified_twice"),
                           "notes": clean(a.get("notes")),
                           "source_file": tag,
                           "mappable": any(p["lat"] is not None or p["lon"] is not None for p in pts)})
stats["regulatory_areas"] = len(regulatory)
stats["regulatory_mappable"] = sum(1 for a in regulatory if a["mappable"])

# --- cross-reference: give every named area its regulatory boundary -----------
# "District 3 / Section 3-A" in an announcement and "Section 3-A" in 5 AAC 33.200
# are the same water. Matching them is what converts a rule that names an area
# into a rule with an extent, and it is the step that was missing when the chart
# was guessing extents from a fixed box around whatever coordinate it had.
def _area_key_of(rel):
    """The management area a release belongs to, as the regulation index keys it."""
    return (rel.get("region") or "").strip().lower()

def _norm(n):
    """Announcements and regulations name the same water differently:
    the release says "Outer Karluk", 5 AAC 18.200 says "Outer Karluk Section";
    the release says "13-A", the regulation says "Section 13-A". Strip the type
    word from either end and the two agree. Getting this wrong does not error —
    it just silently fails to find a boundary that is sitting right there."""
    if not n: return None
    t = re.sub(r"[^a-z0-9]+", " ", str(n).lower()).strip()
    t = re.sub(r"^(district|section|subdistrict|area)\s+", "", t)
    # Strip the whole designation, not just its last word. The regulation says
    # "Deep Inlet Terminal Harvest Area" and the announcement title says "Deep
    # Inlet"; stripping only the trailing "area" left "deep inlet terminal
    # harvest" and the two never met, so thirteen live THA openings had no
    # boundary while their coordinates sat in the same file.
    t = re.sub(r"\s*\b(?:commercial\s+)?(?:terminal|special)\s+harvest\s+area\b.*$", "", t)
    t = re.sub(r"\s*\b(?:hatchery\s+)?harvest\s+area\b.*$", "", t)
    t = re.sub(r"\s*\b(?:tha|sha)\b.*$", "", t)
    t = re.sub(r"\s+(district|section|subdistrict|area|hatchery)$", "", t)
    return re.sub(r"\s+", "", t)

def _about_this_area(rule, area):
    """Does this closure actually concern the area it sits in?

    "Section 6-D: will be closed" appears inside District 6's block, but it shuts
    6-D, not District 6 — and it was blocking the whole district from being
    drawn. A closure that names a place other than its container is either a hole
    (if we can bound it) or somebody else's problem; either way it is not a
    reason to refuse to draw this area.

    Conservative on purpose: only rules that clearly name a DIFFERENT area are
    let through. Anything ambiguous still blocks."""
    subj = (rule.get("subject") or "").strip()
    head = ((rule.get("text") or "").split(":")[0] or "").strip()
    here = {_norm(area.get("district")), _norm(area.get("section"))} - {None}
    for cand in (subj, head):
        if not cand or len(cand) > 60: continue
        n = _norm(cand)
        if not n: continue
        if n in here:
            return True                     # names this very area: it blocks
        if REG_BY_NAME.get(n):
            return False                    # names a different, known place
        # "Section 6-D" inside District 6, "Lost River" inside Situk-Ahrnklin
        if any(h and n != h and (n.startswith(h) or h.startswith(n)) for h in here):
            return False
    return True

def _lookup(name, area):
    """Find a regulatory area by name, inside its own management area first.

    Falls back to a global match ONLY when exactly one area of that name exists
    anywhere — otherwise the ambiguity is real and nothing is returned, because
    guessing between two districts that share a number is how a Yukon closure
    ends up drawn over Ketchikan."""
    k = _norm(name)
    if not k: return None
    if area:
        hit = REG_BY_NAME.get((area, k))
        if hit: return hit
    # A GENERIC key never crosses management areas, even when it looks unique.
    # "District 1" normalises to "1". The Yukon's own entry is filed under a
    # different name, so "1" had exactly one global match — Southeast's — and
    # "unambiguous" handed the Yukon River fall announcement Ketchikan. A bare
    # number or a two-character token is not a name; it is an index that every
    # chapter of 5 AAC reuses.
    generic = len(k) < 4 or re.fullmatch(r"[0-9]+[a-z]?", k) is not None
    if generic:
        return None                      # only an in-area match will do
    cands = REG_ANY.get(k) or []
    if len(cands) == 1: return cands[0]
    if area:
        same = [c for c in cands if c.get("area_key") == area]
        if len(same) == 1: return same[0]
    return None

def _parent_of(name, area=None):
    a = _lookup(name, area)
    return a.get("parent") if a else None

# The union of every coordinate in one regulation file — that management area's
# own outer bound. Used to complete a definition that gives only one axis:
# 5 AAC 18.200 defines Southwest Kodiak District as the waters between two
# LATITUDES, with no longitude at all, because the shoreline supplies the rest.
# Discarding those left eleven live Kodiak openings undrawable; completing the
# missing axis from the area's own envelope is a real bound, honestly coarser,
# and recorded as such.
AREA_ENVELOPE = {}

# WHICH MANAGEMENT AREA A REGULATION FILE DESCRIBES.
# Keyed on a bare name, "District 1" is ambiguous: the Yukon has Districts 1-6
# and so does Southeast. The lookup was handing the Yukon River fall
# announcement Ketchikan's coordinates, which would have drawn Yukon
# subsistence closures across Southeast Alaska. A name is only unique inside its
# own chapter of 5 AAC, so the index is namespaced by area and consulted with
# the release's own area first.
FILE_AREA = {
    "se_reg_d1_d2": "southeast", "se_reg_d3_d4": "southeast",
    "se_reg_d5_d9": "southeast", "se_reg_d11_d15": "southeast",
    "se_reg_closed_waters": "southeast", "se_tha_regulations": "southeast",
    "kodiak_regulations": "kodiak",
    "akpen_regulations": "alaska peninsula (area m)",
    "yakutat_regulations": "yakutat",
    "yukon_regulations": "yukon",
}

REG_BY_NAME = {}          # (area, name) -> area record
REG_ANY = {}              # name -> [records]  (used only when unambiguous)
for a in regulatory:
    k = _norm(a["name"])
    if not k or not a["mappable"]: continue
    ar = FILE_AREA.get(a["source_file"], a["source_file"])
    a["area_key"] = ar
    if (ar, k) not in REG_BY_NAME: REG_BY_NAME[(ar, k)] = a
    REG_ANY.setdefault(k, []).append(a)
for a in regulatory:
    env = AREA_ENVELOPE.setdefault(a["source_file"], {"n": None, "s": None, "e": None, "w": None})
    for p in a["points"]:
        if p["lat"] is not None:
            env["n"] = p["lat"] if env["n"] is None else max(env["n"], p["lat"])
            env["s"] = p["lat"] if env["s"] is None else min(env["s"], p["lat"])
        if p["lon"] is not None:
            env["e"] = p["lon"] if env["e"] is None else max(env["e"], p["lon"])
            env["w"] = p["lon"] if env["w"] is None else min(env["w"], p["lon"])

# --- landmarks named without their coordinates -------------------------------
# "Outer Karluk Section: all waters west of Kodiak Island bounded by the
# latitude of Rocky Point, the latitude of Pafco Point (57° 36.78' N. lat.), and
# by midstream Shelikof Strait." Rocky Point carries no number HERE — but the
# same file writes it out in the Southwest Kodiak District, and 5 AAC uses one
# value for a landmark throughout. Resolving the name against the file's own
# landmark table turns a one-coordinate section into a two-coordinate band,
# which is the difference between a bay and half an archipelago.
#
# Only the file's own coordinates are used, never another area's and never
# anything invented: if the name is not written out with a number somewhere in
# the same regulation, nothing is added.
LANDMARK = {}                      # source_file -> normalised name -> (lat, lon)
_LM_BAD = re.compile(r"^(?:the|a|an|of|and|to|from|point|cape|island|bay|head)$", re.I)
for a in regulatory:
    tbl = LANDMARK.setdefault(a["source_file"], {})
    for p in a["points"]:
        raw = (p.get("name") or "").strip()
        if not raw or len(raw) < 5: continue
        k = re.sub(r"[^a-z ]+", " ", unicodedata.normalize("NFKD", raw).lower())
        k = re.sub(r"\s+", " ", k).strip()
        if not k or _LM_BAD.match(k): continue
        cur = tbl.get(k)
        if p["lat"] is not None and (cur is None or cur[0] is None):
            tbl[k] = (p["lat"], (cur[1] if cur else None))
        if p["lon"] is not None:
            cur = tbl.get(k)
            tbl[k] = ((cur[0] if cur else None), p["lon"])

LANDMARK_RESOLVED = []
_LAT_REF = re.compile(r"latitude of ([A-Z][A-Za-z'\- ]{3,30}?)(?=[,.;)]| and | bounded| to the |$)")
_LON_REF = re.compile(r"longitude of ([A-Z][A-Za-z'\- ]{3,30}?)(?=[,.;)]| and | bounded| to the |$)")

def _resolved_points(a):
    """The entry's own points, plus any landmark it names WITHOUT a coordinate
    that the same regulation writes out elsewhere. Every addition is recorded so
    the build log can be read."""
    pts = list(a["points"])
    tbl = LANDMARK.get(a["source_file"]) or {}
    txt = a.get("text") or ""
    have = {re.sub(r"[^a-z ]+", " ", unicodedata.normalize("NFKD", (p.get("name") or "")).lower()).strip()
            for p in pts if p["lat"] is not None or p["lon"] is not None}
    added = []
    for rx, axis in ((_LAT_REF, "lat"), (_LON_REF, "lon")):
        for m in rx.finditer(txt):
            k = re.sub(r"[^a-z ]+", " ", unicodedata.normalize("NFKD", m.group(1)).lower())
            k = re.sub(r"\s+", " ", k).strip()
            if not k or k in have: continue
            v = tbl.get(k)
            if not v: continue
            lat, lon = v
            val = lat if axis == "lat" else lon
            if val is None: continue
            pts.append({"name": m.group(1).strip(), "lat": lat if axis == "lat" else None,
                        "lon": lon if axis == "lon" else None, "resolved": True})
            added.append((a["name"], m.group(1).strip(), axis, val))
    if added: LANDMARK_RESOLVED.extend(added)
    return pts

for a in regulatory:
    a["points_resolved"] = _resolved_points(a)
stats["landmarks_resolved_from_same_regulation"] = len(LANDMARK_RESOLVED)
print("landmarks resolved from the same regulation:", len(LANDMARK_RESOLVED))
for _n, _lm0, _ax, _v in LANDMARK_RESOLVED[:40]:
    print("   %-34s %-22s %s %.5f" % (_n[:34], _lm0[:22], _ax, _v))

# --- the fences a regulation actually draws --------------------------------
# SOUTHEAST DOES NOT WRITE BOXES. 5 AAC 33.200 writes fences and sides:
#
#   "(c) District 3: all waters NORTH AND WEST OF A LINE from Point Marsh Light
#    ... to the southernmost tip of Cape Muzon ..., AND EAST OF A LINE from the
#    northernmost tip of Eagle Point ... "
#   "(1) Section 3-A: waters of District 3 SOUTH AND EAST OF A LINE through
#    Tlevak Narrows beginning at the easternmost tip of Turn Point ... "
#
# The bounding box of those points is not the area. Section 3-A's two points sit
# 0.04 minutes apart in latitude, so its box was a hairline, and District 3's box
# was a rectangle over half the panhandle. Both were drawn, and both were wrong.
#
# So the ordered point chain and the side are extracted per fence and carried
# through to the renderer, which draws the line with ticks on the stated side —
# the mark every chart has used for a boundary since charts existed.
_DIR = r"(?:north|south|east|west)(?:erly|ward)?"
_FENCE_RE = re.compile(
    r"\b(" + _DIR + r"(?:\s+and\s+" + _DIR + r")?)\s+of\s+"
    r"(a\s+line|the\s+latitude|the\s+longitude|" + r"\d)", re.I)

def _fences_of(a):
    """Split an entry's text at each '<side> of a line/latitude/longitude' and
    hand each fence the entry's own points that are named inside its span, in
    the order the regulation writes them. Only the entry's OWN coordinates are
    used — no point is created here."""
    txt = a.get("text") or ""
    pts = a.get("points_resolved", a["points"])
    named = [(p, (p.get("name") or "").strip().lower()) for p in pts]
    out = []
    ms = list(_FENCE_RE.finditer(txt))

    # "Izhut Bay Section: all waters of Izhut Bay ... BOUNDED BY A LINE FROM
    #  Pillar Cape ... to Peril Cape."  No direction word, so the fence pattern
    #  above never saw it, and the box drawn from those two headlands was 0.8 by
    #  4.8 nautical miles — the LINE's own bounding box, not the bay, which runs
    #  miles behind it. Same sentence shape as Deep Inlet, same error. Four
    #  Kodiak sections were drawn this way.
    #
    #  "bounded ON THE SOUTH by a line" states which side the line bounds, so the
    #  water is on the OPPOSITE side — the inverse of "south of a line". Getting
    #  that backwards would tick every one of them into the wrong water, so a
    #  side is only claimed where the sentence gives one.
    # "The Southeast Cove Terminal Harvest Area consists of the waters of Keku
    #  Strait ENCLOSED BY A LINE from ... to ... then northwest ..." -- ten
    #  points that close on themselves. That is a genuine polygon, the one shape
    #  where a filled area is the truth rather than an inference, so it is kept
    #  as one instead of being reduced to its bounding box.
    if re.search(r"enclosed by a line", txt, re.I):
        ring = [p for p in pts if p["lat"] is not None and p["lon"] is not None]
        if len(ring) >= 3:
            return [{"side": None, "kind": "polygon",
                     "points": [{"name": p.get("name"), "lat": p["lat"], "lon": p["lon"],
                                 "lat_dm": p.get("lat_dm"), "lon_dm": p.get("lon_dm")}
                                for p in ring]}]

    # "Unimak District: waters on the south side of Unimak Island BETWEEN A LINE
    #  extending from Scotch Cap through the easternmost tip of Ugamak Island AND
    #  A LINE extending 115 degrees from Cape Pankof Light." Two lines with the
    #  water between them, and no direction word anywhere -- so the fence pattern
    #  missed it and a 27 by 60 nautical mile box was drawn instead.
    # "a line extending 115 degrees from Cape Pankof Light", "a line extending
    #  seaward 144 degrees from Cape Kasiak" -- a point and a bearing is a line,
    #  fully published, and it was being discarded. Recorded as a ray for the
    #  renderer to draw out to the edge of the frame.
    rays = []
    for m in re.finditer(r"a line extending\s+(?:seaward\s+)?(\d{1,3})\s*(?:°|º|degrees?)?"
                         r"[^.]{0,60}?\bfrom\s+([A-Z][A-Za-z'\- ]{3,34}?)"
                         r"(?=\s*[(,.;]| at | and | to |$)", txt):
        k = re.sub(r"[^a-z ]+", " ", unicodedata.normalize("NFKD", m.group(2)).lower())
        k = re.sub(r"\s+", " ", k).strip()
        for p, nm in named:
            if nm == k and p["lat"] is not None and p["lon"] is not None:
                rays.append({"side": None, "kind": "ray", "bearing": int(m.group(1)),
                             "points": [{"name": p.get("name"), "lat": p["lat"], "lon": p["lon"],
                                         "lat_dm": p.get("lat_dm"), "lon_dm": p.get("lon_dm")}]})
                break

    if re.search(r"\bbetween a line\b", txt, re.I):
        segs, marks = [], [m.start() for m in re.finditer(r"\ba line\b", txt, re.I)]
        for i, k in enumerate(marks):
            end = marks[i + 1] if i + 1 < len(marks) else len(txt)
            span = txt[k:end].lower()
            chain = []
            for p, nm in named:
                if not nm or len(nm) < 4: continue
                if p["lat"] is None or p["lon"] is None: continue
                j = span.find(nm)
                if j >= 0: chain.append((j, p))
            chain.sort(key=lambda z: z[0])
            if len(chain) >= 2:
                segs.append({"side": None, "kind": "closing_line",
                             "points": [{"name": p.get("name"), "lat": p["lat"], "lon": p["lon"],
                                         "lat_dm": p.get("lat_dm"), "lon_dm": p.get("lon_dm")}
                                        for _, p in chain]})
        if segs or rays: return segs + rays

    _OPP = {"north": "south", "south": "north", "east": "west", "west": "east"}
    for m in re.finditer(r"bounded(?:\s+on\s+the\s+(north|south|east|west))?"
                         r"(?:\s+\w+){0,2}?\s+by\s+a\s+line", txt, re.I):
        start = m.end()
        nxt = txt.find(" bounded", start)
        end = nxt if nxt > 0 else len(txt)
        span = txt[start:end].lower()
        chain = []
        for p, nm in named:
            if not nm or len(nm) < 4: continue
            if p["lat"] is None or p["lon"] is None: continue
            k = span.find(nm)
            if k >= 0: chain.append((k, p))
        if len(chain) < 2:
            # a line whose ends are written as bare coordinates, not landmarks
            bare = [p for p in pts if p["lat"] is not None and p["lon"] is not None
                    and not (p.get("name") or "").strip()]
            chain = [(i, p) for i, p in enumerate(bare)] if len(bare) >= 2 else []
        if len(chain) < 2: continue
        chain.sort(key=lambda z: z[0])
        side = _OPP.get((m.group(1) or "").lower()) if m.group(1) else None
        out.append({"side": side, "kind": "closing_line",
                    "points": [{"name": p.get("name"), "lat": p["lat"], "lon": p["lon"],
                                "lat_dm": p.get("lat_dm"), "lon_dm": p.get("lon_dm")}
                               for _, p in chain]})
    if out: return out

    if not ms:
        # "Outer Karluk Section: all waters west of Kodiak Island bounded by the
        # latitude of Rocky Point, the latitude of Pafco Point, and by midstream
        # Shelikof Strait." The area is BETWEEN two parallels. The parallels are
        # published; the strait is not. Each published parallel becomes a bar,
        # and the renderer ticks them inward.
        #
        # No wording test guards this any more. It used to require the word
        # "bounded", and the Yakutat, Yakataga and Coastal Districts -- which
        # phrase it differently -- fell through to a box built on an axis the
        # regulation never gave. A published parallel or meridian is a line
        # whatever sentence carries it.
        bars = []
        for p in pts:
            if (p["lat"] is None) == (p["lon"] is None): continue   # need exactly one axis
            bars.append({"side": None, "kind": "bar",
                         "points": [{"name": p.get("name"), "lat": p["lat"], "lon": p["lon"],
                                     "lat_dm": p.get("lat_dm"), "lon_dm": p.get("lon_dm")}]})
        return bars
    for i, m in enumerate(ms):
        start = m.end()
        end = ms[i + 1].start() if i + 1 < len(ms) else len(txt)
        span = txt[start:end].lower()
        side = re.sub(r"\s+", " ", m.group(1).strip().lower())
        chain = []
        for p, nm in named:
            if not nm or len(nm) < 4: continue
            if p["lat"] is None and p["lon"] is None: continue
            k = span.find(nm)
            if k < 0: continue
            chain.append((k, p))
        # a bare cutoff: "south of 55 45.78 N. lat." names no landmark at all
        if not chain:
            for p, nm in named:
                if nm: continue
                if p["lat"] is None and p["lon"] is None: continue
                chain.append((0, p))
        if not chain: continue
        chain.sort(key=lambda z: z[0])
        seen, ordered = set(), []
        for _, p in chain:
            k = (p["lat"], p["lon"])
            if k in seen: continue
            seen.add(k)
            ordered.append({"name": p.get("name"), "lat": p["lat"], "lon": p["lon"],
                            "lat_dm": p.get("lat_dm"), "lon_dm": p.get("lon_dm")})
        if ordered:
            out.append({"side": side, "points": ordered})
    return out

for a in regulatory:
    a["fences"] = _fences_of(a)
stats["regulation_fences"] = sum(len(a["fences"]) for a in regulatory)

def _box_of(a, env):
    """The plain envelope of a regulation entry's own points, or None if it does
    not give one on both axes."""
    lats = [p["lat"] for p in a.get("points_resolved", a["points"]) if p["lat"] is not None]
    lons = [p["lon"] for p in a.get("points_resolved", a["points"]) if p["lon"] is not None]
    if len(lats) >= 2 and max(lats) > min(lats) and len(lons) >= 2 and max(lons) > min(lons):
        return {"s": min(lats), "n": max(lats), "w": min(lons), "e": max(lons)}
    return None

_SIDE_LAT = re.compile(r"\b(north|south)(?:erly|ward)?\s+of\b", re.I)
_SIDE_LON = re.compile(r"\b(east|west)(?:erly|ward)?\s+of\b", re.I)

def reg_extent(district, section, area=None):
    """Boundary coordinates for a named area, preferring the section over the
    district — the narrower definition is the better bound.

    A definition can be DEGENERATE: 5 AAC 09.200 defines Beaver Bay Section by a
    single latitude between two longitudes, and Southwest Stepovak by one point
    and a shoreline. A zero-width box cannot be drawn on its own.

    WHERE THE FRAME COMES FROM, and why it is not the management area.
    "Anton Larsen Bay Section: all waters of Anton Larsen Bay south of
    57° 52.25' N. lat." gives one latitude and nothing else. Completing the
    missing axes from the KODIAK MANAGEMENT AREA envelope turned a single bay
    into the entire archipelago — 56.7 to 58.9 N, 152 to 156.5 W — which is not
    a coarser answer, it is a wrong one, and three live sections were dropped
    rather than drawn that way. The frame is now the nearest ANCESTOR that
    defines a real box (here the Northwest Kodiak District), and the section's
    own cutoff is applied to it with the side the regulation states. The
    management area is the last resort, not the first."""
    chain = [section, _parent_of(section, area), district, _parent_of(district, area)]
    entries = [(n, _lookup(n, area)) for n in chain]
    env_all = None
    # THE FRAME IS BUILT PER AXIS, not as a whole box. 5 AAC bounds most Kodiak
    # districts in latitude only — "Eastside Kodiak District: all waters south
    # and east of Kodiak Island bounded by the latitude of Cape Trinity and the
    # latitude of Cape Chiniak, and by midstream Shelikof Strait" — so no
    # ancestor yields a two-axis box and the whole frame fell back to the
    # management area. Sitkalidak Section then spanned 2.1 degrees of latitude,
    # the entire archipelago, off a single published coordinate. Each axis now
    # takes the nearest ancestor that actually bounds THAT axis; only an axis no
    # ancestor bounds falls through to the management envelope, which is what
    # the regulation itself does when it says "and by midstream Shelikof Strait".
    fr_lat = fr_lon = None
    frame_name = None
    for n, a in entries:
        if not a: continue
        if env_all is None:
            env_all = AREA_ENVELOPE.get(a["source_file"]) or {}
        if _norm(n) == _norm(section or district): continue
        pr = a.get("points_resolved", a["points"])
        la = [p["lat"] for p in pr if p["lat"] is not None]
        lo = [p["lon"] for p in pr if p["lon"] is not None]
        if fr_lat is None and len(la) >= 2 and max(la) > min(la):
            fr_lat = (min(la), max(la)); frame_name = frame_name or a["name"]
        if fr_lon is None and len(lo) >= 2 and max(lo) > min(lo):
            fr_lon = (min(lo), max(lo)); frame_name = frame_name or a["name"]
    env_all = env_all or {}
    frame = None
    if fr_lat or fr_lon:
        frame = {"s": (fr_lat[0] if fr_lat else env_all.get("s")),
                 "n": (fr_lat[1] if fr_lat else env_all.get("n")),
                 "w": (fr_lon[0] if fr_lon else env_all.get("w")),
                 "e": (fr_lon[1] if fr_lon else env_all.get("e"))}
    for name, a in entries:
        if not a: continue
        _pr = a.get("points_resolved", a["points"])
        lats = [p["lat"] for p in _pr if p["lat"] is not None]
        lons = [p["lon"] for p in _pr if p["lon"] is not None]
        env = frame or {"s": env_all.get("s"), "n": env_all.get("n"),
                        "w": env_all.get("w"), "e": env_all.get("e")}
        txt = a.get("text") or ""

        def _span(vals, lo, hi, side_re, lo_word):
            """Two edges from the entry's own points where it gives two; where it
            gives ONE, the frame supplies the far edge and the regulation's own
            wording says which side of the line the area is on.

            The third return value records WHERE EACH EDGE CAME FROM, and that
            provenance is the whole point. "The Kendrick Bay Terminal Harvest
            Area consists of the waters of Kendrick Bay west of 131 59' W. long."
            gives one meridian and no latitude at all. Completing the latitude
            from District 2 produced a box 77 nautical miles tall and seven
            tenths of a mile wide — a rectangle down the middle of Clarence
            Strait, which is not Kendrick Bay and is not anywhere a seiner may
            fish. A box is only ever honest where the regulation bounds BOTH
            edges of an axis itself; anything less is a line, and a line has to
            be drawn as a line."""
            if vals and max(vals) > min(vals):
                return min(vals), max(vals), "own2"
            if lo is None or hi is None or hi <= lo:
                return None, None, "none"
            if len(vals) == 1:
                v = vals[0]
                if lo < v < hi:
                    m = side_re.search(txt)
                    word = (m.group(1).lower() if m else None)
                    if word == lo_word:            # "south of X" / "west of X"
                        return lo, v, "own1"
                    if word:                       # "north of X" / "east of X"
                        return v, hi, "own1"
                return lo, hi, "own1"
            return lo, hi, "frame"

        s_, n_, latFrom = _span(lats, env.get("s"), env.get("n"), _SIDE_LAT, "south")
        w_, e_, lonFrom = _span(lons, env.get("w"), env.get("e"), _SIDE_LON, "west")
        band = (latFrom != "own2") or (lonFrom != "own2")
        if (n_ is not None and s_ is not None and e_ is not None and w_ is not None
                and n_ > s_ and e_ > w_):
            # COARSE: a band this wide is the regulation bounding a direction by
            # a shoreline it never gives coordinates for — "and by midstream
            # Shelikof Strait". It is honest as a bound and dishonest as green
            # water: 4.4 degrees of longitude at 57 N is 265 km and crosses into
            # another management area entirely. The app draws a coarse band as an
            # outline with its name, never as fill.
            coarse = band and ((n_ - s_) > 1.2 or (e_ - w_) > 3.0)
            return {"name": a["name"], "citation": a["citation"],
                    "coarse": bool(coarse),
                    "precision": ("band" if band else
                                  "exact" if _norm(name) == _norm(section or district)
                                  else "parent"),
                    "n": n_, "s": s_, "e": e_, "w": w_,
                    "lat_only": not lons, "lon_only": not lats,
                    "npoints": len(a["points"]),
                    "lat_from": latFrom, "lon_from": lonFrom,
                    "fences": a.get("fences") or [],
                    "framed_by": (frame_name if band and frame else None)}
    return None

# A standing closure states a cutoff without saying how far it runs: "Bay of
# Pillars: waters east of 134° 11.74' W. long." means inside Bay of Pillars, not
# across the Gulf of Alaska. The regulation files record each closure's parent
# district, and 5 AAC defines that district by coordinate — so the parent's
# extent is the bound. Without it a single cutoff paints half the chart red.
for a in regulatory:
    a["parent_extent"] = (reg_extent(a.get("parent"), None, a.get("area_key"))
                          if a.get("parent") else None)
    a["parent_key"] = _norm(a.get("parent"))
stats["standing_closures_bounded"] = sum(
    1 for a in regulatory if a["kind"] == "closed_water" and a["mappable"] and a["parent_extent"])

# A closure inside an announcement usually names a PLACE, not the section:
# "Carroll Inlet: closed north of 55°19.57′ N" shuts part of Carroll Inlet, not
# everything north of that latitude in District 1. Treated as a constraint on the
# whole section it annihilates the section — five of six openings composed to an
# empty polygon before this. Most of those names are defined in 5 AAC 33.350, so
# the same cross-reference that gives a section its boundary gives a closure its
# own bound, and the closure becomes a HOLE in the opening rather than a knife
# through it.
placed = 0
for r in releases:
    for a in r["areas"]:
        for x in a["rules"]:
            # The subject is the usual handle ("Boca de Quadra"), but plenty of
            # closures carry the place only in the sentence ("Carroll Inlet:
            # closed north of ..."). Try the subject, then the text before the
            # first colon, then any regulation place-name that appears in the
            # text. A closure that finds its own place cuts only that place; one
            # that does not is applied to the whole section, which is safe but
            # shrinks the opening — so every extra match here is real water
            # given back, not a liberty taken.
            rk = _area_key_of(r)
            ex = reg_extent(x.get("subject"), None, rk)
            if not ex:
                head = (x.get("text") or "").split(":")[0]
                if head and len(head) < 60: ex = reg_extent(head, None, rk)
            if not ex:
                t = (x.get("text") or "").lower()
                best = None
                for (_ak, nm), ra in REG_BY_NAME.items():
                    if _ak != rk: continue
                    plain = re.sub(r"[^a-z0-9 ]+", " ", (ra.get("name") or "").lower()).strip()
                    if len(plain) < 6: continue
                    if plain in t and (best is None or len(plain) > len(best[0])):
                        best = (plain, ra)
                if best:
                    ex = reg_extent(best[1]["name"], None, rk)
            x["reg_extent"] = ex
            if ex: placed += 1
stats["rules_with_own_extent"] = placed

matched = 0
for r in releases:
    rk = _area_key_of(r)          # look inside this release's own chapter of 5 AAC
    for a in r["areas"]:
        ex = reg_extent(a.get("district"), a.get("section"), rk)
        # A terminal harvest area announcement names no district or section —
        # the THA *is* the area, and its name is in the title. 5 AAC 33.369-.389
        # define them by coordinate and they were already extracted, so a Deep
        # Inlet or Anita Bay opening has a boundary sitting right there. Without
        # this, thirteen of nineteen live Southeast openings were left off the
        # chart with nothing said about them.
        if not ex:
            # r, not d. `d` is the last raw file the parsing loop happened to
            # read, still in scope hundreds of lines later — so every release
            # was matched against one arbitrary title and none of them hit.
            t = clean(r.get("title")) or ""
            m = re.match(r"^\s*(?:\d{4}\s+)?(.*?)\s*(?:terminal harvest area|special harvest area|\bTHA\b|\bSHA\b)", t, re.I)
            if m:
                ex = (reg_extent(m.group(1), None, rk)
                      or reg_extent(m.group(1) + " Terminal Harvest Area", None, rk))
                if ex: a["matched_by"] = "tha_title"
        a["reg_extent"] = ex

        # Only a rule whose extent could be ANYWHERE in the area stops the area
        # being shown open. A rule that names the area, states a condition about
        # fish or gear, concerns fresh water in a marine fishery, or carries its
        # own regulatory boundary does not.
        marine = bool(ex)
        _ = rk
        BLOCKING = {"unknown_extent"} if marine else {"unknown_extent", "freshwater"}
        blk, cond, shore, excl = [], [], [], []
        for x in a["rules"]:
            k = x.get("blocker_kind")
            if x["evaluable"] or not k: continue
            if k == "named_exclusion":
                # Drawn, but the words go ON THE SHEET. A named piece of water
                # is cut out of this opening and this app has no boundary for
                # it, so the chart says so in print rather than either hiding
                # the whole opening or shading over a closure.
                excl.append({"subject": x["subject"], "text": x["text"]})
                cond.append({"subject": x["subject"], "status": x["status"],
                             "text": x["text"], "kind": k})
            elif k == "shore_band":
                shore.append({"subject": x["subject"], "status": x["status"],
                              "text": x["text"], "why": x["not_evaluable_because"]})
            elif k in BLOCKING and not x.get("reg_extent") and _about_this_area(x, a):
                blk.append({"subject": x["subject"], "geometry": x["geometry"],
                            "status": x["status"], "why": x["not_evaluable_because"],
                            "text": x["text"], "kind": k})
            else:
                cond.append({"subject": x["subject"], "status": x["status"],
                             "text": x["text"], "kind": k})
        a["blockers"] = blk
        a["conditions"] = cond
        a["shore_bands"] = shore
        a["exclusions"] = excl
        a["complete"] = (not blk) and bool(a["rules"])
        a["shore_only"] = bool(shore) and not blk
        # Which district this area belongs to, so a standing closure filed under
        # that district can be matched to it. "Section 9-B" belongs to District 9;
        # a District 9 closure applies to it, a District 1 closure does not.
        _d = _norm(a.get("district"))
        _s = _norm(a.get("section"))
        _parent = None
        if _s:
            _reg = _lookup(_s, rk)
            if _reg and _reg.get("parent"): _parent = _norm(_reg["parent"])
        a["district_key"] = _parent or _d

        # --- where the chart should LOOK when you pick this area -------------
        # The Anita Bay THA is "those waters of Anita Bay south and west of a
        # line from Anita Point to a point on the northern shore". The two line
        # points span nine hundredths of a minute of latitude, so the extent
        # built from them is a sliver across the mouth — and picking Anita Bay
        # sent the chart to that sliver instead of to the bay. The client has
        # fished it and said so.
        #
        # The announcement itself publishes coordinates well inside the bay: the
        # June closure lines at 132 26.19' W, 132 26.98' W, 132 28.00' W, and the
        # shore-band corners down at 56 11.73' N. Every one of them is a
        # published coordinate inside this area. They are no use as a boundary,
        # but they are exactly right for deciding what water to put on screen,
        # so the VIEW extent is the envelope of everything the sources publish
        # for the area — including rules whose own dates have passed, because a
        # June closure still tells you where Anita Bay is.
        _lats, _lons = [], []
        for _r in a["rules"]:
            for _p in (_r.get("points") or []):
                if _p.get("lat") is not None: _lats.append(_p["lat"])
                if _p.get("lon") is not None: _lons.append(_p["lon"])
        if ex:
            _lats += [ex["n"], ex["s"]]; _lons += [ex["e"], ex["w"]]
        _vn = max(_lats) if _lats else None
        _vs = min(_lats) if _lats else None
        _ve = max(_lons) if _lons else None
        _vw = min(_lons) if _lons else None
        if _vn is not None and _vs is not None and _ve is not None and _vw is not None:
            # never smaller than a boat can see: pad a degenerate axis a little
            if _vn - _vs < 0.004: _vn += 0.002; _vs -= 0.002
            if _ve - _vw < 0.006: _ve += 0.003; _vw -= 0.003
            a["view_extent"] = {"n": _vn, "s": _vs, "e": _ve, "w": _vw,
                                "from": "every coordinate published for this area"}
        if ex: matched += 1
stats["areas_with_regulatory_extent"] = matched

# --- a shut section inside a district the same announcement opens -------------
# Kodiak announcement #40: "The Northwest Kodiak District (except the Anton
# Larsen Bay, Sharatin Bay, and Kizhuyak Bay Sections remain closed)". Those
# three sections are separate areas in the same release, carry status "closed",
# and used to have no relationship at all to the district drawn green over the
# top of them. Green over water an announcement says is shut is the one error
# that can cost a fisherman a citation, so each open area now carries the shut
# sections that sit inside it and the chart cuts them out and letters them.
_excluded = 0
for _rel in releases:
    _shut = [x for x in _rel["areas"]
             if x.get("status") == "closed" and x.get("reg_extent")
             and (x.get("section") or x.get("district"))]
    if not _shut: continue
    for _a in _rel["areas"]:
        if _a.get("status") not in ("open", "partial"): continue
        _ae = _a.get("reg_extent")
        if not _ae: continue
        _mine = []
        for _x in _shut:
            if _x is _a: continue
            # same district, and the shut section is not the open area itself
            if _norm(_x.get("district")) != _norm(_a.get("district")): continue
            if _norm(_x.get("section") or "") == _norm(_a.get("section") or ""): continue
            # A shut DISTRICT is not a pocket inside its own section. "District
            # 13 is closed" alongside "Section 13-A is open" is a contradiction
            # to surface, not a hole to punch: cutting the parent out of the
            # child erases the child entirely.
            if not _x.get("section") and _a.get("section"): continue
            _xe = _x["reg_extent"]
            # it has to actually overlap the water being opened
            if (_xe["s"] >= _ae["n"] or _xe["n"] <= _ae["s"]
                    or _xe["w"] >= _ae["e"] or _xe["e"] <= _ae["w"]): continue
            _mine.append({"name": " ".join(z for z in (_x.get("district"), _x.get("section")) if z),
                          "label": _x.get("section") or _x.get("district"),
                          "citation": _xe.get("citation"), "extent": _xe,
                          "text": (_x.get("period_text") or "")[:300]})
        if _mine:
            _a["closed_within"] = _mine
            _excluded += len(_mine)
stats["shut_sections_cut_from_openings"] = _excluded

# --- standing closures that apply inside any opened area ----------------------
# 5 AAC 33.350 closures are in force continuously. An announcement that opens a
# section does not lift them, so they must be drawn over any opened water.
stats["standing_closures"] = sum(1 for a in regulatory
                                 if a["kind"] == "closed_water" and a["mappable"])

# --- independent cross-check of the regulation text ---------------------------
# The 5 AAC 33 text came from AAC mirrors that agree character-for-character —
# but both derive from the same state codification, so that is agreement, not
# independence, and the printed booklet is not reachable from here.
#
# The ANNOUNCEMENTS are genuinely independent: different documents, different
# area offices, different publication dates, extracted in a separate pass. Where
# an announcement and the regulation name the same landmark, the two must agree.
# That is a real check on the regulation transcription, and it is run on every
# build rather than being asserted once in prose.
GENERIC = {"inner point", "outer point", "north point", "south point", "east point",
           "west point", "point", "the point", "middle point", "sandy point"}

def _lm(n):
    if not n: return None
    t = unicodedata.normalize("NFKD", str(n)).lower()
    t = re.sub(r"\b(light|lighted|buoy|marker|regulatory|the|at|of)\b", " ", t)
    t = re.sub(r"[^a-z ]+", " ", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t or None

_reg_lm = {}
for a in regulatory:
    for pt in a["points"]:
        k = _lm(pt.get("name"))
        if not k or k in GENERIC or (pt["lat"] is None and pt["lon"] is None): continue
        _reg_lm.setdefault(k, []).append((pt["lat"], pt["lon"], a["citation"]))
_ann_lm = {}
for r in releases:
    for a in r["areas"]:
        for x in a["rules"]:
            for pt in x["points"]:
                k = _lm(pt.get("name"))
                if not k or k in GENERIC or (pt["lat"] is None and pt["lon"] is None): continue
                _ann_lm.setdefault(k, []).append((pt["lat"], pt["lon"], r["id"]))

TOL_MIN = 0.06                     # arc-minutes, about 110 m
xcheck = {"landmarks": 0, "pairs": 0, "agree": 0, "disagree": []}
for k in sorted(set(_reg_lm) & set(_ann_lm)):
    xcheck["landmarks"] += 1
    for (rlat, rlon, cit) in _reg_lm[k]:
        for (alat, alon, rid) in _ann_lm[k]:
            ds = []
            if rlat is not None and alat is not None: ds.append(abs(rlat - alat) * 60)
            if rlon is not None and alon is not None: ds.append(abs(rlon - alon) * 60)
            if not ds: continue
            xcheck["pairs"] += 1
            worst = max(ds)
            if worst <= TOL_MIN:
                xcheck["agree"] += 1
            else:
                xcheck["disagree"].append({
                    "landmark": k, "arcmin": round(worst, 2), "citation": cit,
                    "regulation": [rlat, rlon], "announcement": [alat, alon], "release": rid})

stats["in_force_areas_complete"] = sum(
    1 for r in releases for a in r["areas"]
    if a["time_state"] == "in_force" and a["rules"] and (a["complete"] or a["shore_only"]))
stats["in_force_areas_drawable"] = sum(
    1 for r in releases for a in r["areas"]
    if a["time_state"] == "in_force" and a["rules"] and a["reg_extent"]
       and (a["complete"] or a["shore_only"]))
stats["in_force_areas_no_boundary"] = sum(
    1 for r in releases for a in r["areas"]
    if a["time_state"] == "in_force" and a["rules"] and not a["reg_extent"])

out = {"generated": NOW.isoformat(timespec="minutes"),
       "now": NOW.isoformat(timespec="minutes"),
       "timezone": TZNAME,
       "regulatory": regulatory,
       "regulatory_sources": reg_sources,
       "regulatory_source": (reg_sources[0]["url"] if reg_sources else None),
       "source": "ADF&G Division of Commercial Fisheries advisory announcements",
       "source_index": "https://www.adfg.alaska.gov/index.cfm?adfg=cfnews.main",
       "stats": stats, "problems": problems, "repairs": repairs,
       "crosscheck": xcheck, "releases": releases}
json.dump(out, open("app_data.json", "w", encoding="utf-8"), ensure_ascii=False, separators=(",", ":"))
print(json.dumps(stats, indent=1))
print(f"regulation vs announcement cross-check: {xcheck['agree']}/{xcheck['pairs']} "
      f"coordinate pairs agree within {TOL_MIN}' across {xcheck['landmarks']} shared landmarks")
for dd in xcheck["disagree"]:
    print(f"   DISAGREES by {dd['arcmin']}' : {dd['landmark']} — {dd['citation']} vs release {dd['release']}")
print(f"notation repairs applied: {len(repairs)}")
for r in repairs: print("   ", r)
print(f"parse problems: {len(problems)}")
for p in problems[:10]: print("  ", p)
