#!/usr/bin/env python3
"""Alaska Fishery Openings — local application (Southeast, 5 AAC 33).

Runs entirely on this machine. It shows the current commercial-salmon openings
map (seine / gillnet / troll) as a captain reads it — where you may fish and
where you may not — and keeps itself current by fetching ADF&G announcements on
an anticipatory schedule, parsing them deterministically, and re-rendering. It
never shows a closure it is not sure of: anything it cannot parse with
confidence is flagged for review, never guessed.

Start it with the launcher (the app icon). It binds to 127.0.0.1 only, so it is
not reachable from anywhere else, and it fetches only from adfg.alaska.gov.
"""
import http.server, socketserver, json, os, sys, threading, time, traceback, urllib.parse, datetime as dt

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "engine"))
sys.path.insert(0, os.path.join(HERE, "pipeline"))

# Under pythonw.exe there is no console (stdout/stderr are None); route them to
# a log file so the app runs identically with or without a console.
DATA = os.path.join(HERE, "data")
os.makedirs(DATA, exist_ok=True)
if sys.stdout is None or sys.stderr is None:
    _log = open(os.path.join(DATA, "openings.log"), "a", buffering=1, encoding="utf-8", errors="replace")
    if sys.stdout is None: sys.stdout = _log
    if sys.stderr is None: sys.stderr = _log

SEEDS = os.path.join(HERE, "seeds")
PIPELINE = os.path.join(HERE, "pipeline")
HOST = "127.0.0.1"
PORT = int(os.environ.get("OPENINGS_PORT", "8785"))
VERSION = "3.0.5"
# every rebuild path — boot reconciliation, refresh, the doctor's repair — stamps
# the page with THIS engine (axiom 33): one place, so no path can forget.
os.environ["AFO_ENGINE_VERSION"] = VERSION
STATE_FILE = os.path.join(DATA, "state.json")

import scheduler                      # engine/
import fetch_detect                   # engine/
import doctor                        # engine/  (self-diagnosis + self-repair)
import selfaudit                     # engine/  (self-CONTRADICTION check + repair)
import reparse                       # engine/  (a shipped grammar fix reaches held records)
import publisher                      # engine/  (auto-publish to the phone page)
from rebuild import rebuild           # pipeline/

_lock = threading.Lock()              # one refresh at a time


# ---- THE PAGE MUST HAVE BEEN BUILT BY THIS ENGINE (axiom 33, ledger #85/#96)
# The installer deliberately preserves data/, and a rebuild only happens when
# new announcements arrive — so an upgraded app SERVED AND PUBLISHED the
# previous version's page, with /api/state honestly reporting the new engine
# version the whole time. Two different facts, one number on screen. Every boot
# now compares the page's own stamp against this engine and rebuilds when they
# differ, so the served page and the published page can never be a version
# behind the program that serves them.
def _page_engine():
    """The engine version stamped into the built page, or None."""
    import re
    path = os.path.join(DATA, "SE_Openings.html")
    try:
        with open(path, encoding="utf-8") as f:
            head = f.read(4096)
        m = re.search(r'<meta name="afo-engine" content="([^"]*)"', head)
        return m.group(1) if m else None
    except Exception:
        return None


def _expected_stamp():
    """The stamp the CURRENT generator would produce (version + its own hash)."""
    try:
        import hashlib
        h = hashlib.sha256()
        for fn in sorted(("build_app.py", "restatus.py", "areastatus.py", "timemodel.py")):
            try:
                with open(os.path.join(PIPELINE, fn), "rb") as f:
                    h.update(f.read())
            except Exception:
                pass
        return VERSION + "+" + h.hexdigest()[:8]
    except Exception:
        return VERSION


def _reconcile_page_version(log=print):
    """Rebuild when the page on disk was not built by THIS generator.

    Comparing version strings alone let a page built before an in-release fix
    sit beside one built after it, both stamped the same, and the stale one was
    served (caught on the bench, ledger #107). The comparison is now against a
    stamp that includes a hash of the generator itself."""
    pv = _page_engine()
    if pv == _expected_stamp():
        return {"page_version": pv, "rebuilt": False}
    log(f"  page was built by engine {pv!r}, this engine is {VERSION!r} — rebuilding")
    try:
        os.environ["AFO_ENGINE_VERSION"] = VERSION
        size = rebuild(SEEDS, DATA, PIPELINE, log=log)
        now = _page_engine()
        if now != _expected_stamp():
            log(f"  WARNING: after rebuild the page still reports engine {now!r}")
        return {"page_version": now, "rebuilt": True, "size": size}
    except Exception as e:
        log(f"  page rebuild failed: {e}")
        return {"page_version": pv, "rebuilt": False, "error": str(e)}


# NOTE: the expected stamp comes from _expected_stamp() above, NEVER from
# `import build_app` — build_app builds a page at IMPORT time, so importing it
# to read a constant would rebuild (or, from the wrong directory, raise and be
# swallowed, leaving the stamp empty and check C3 silently switched off).
# Caught on the bench while wiring this; a guard that fails quiet is no guard.


def _self_audit(rebuild_ok=True, log=print):
    """THE APP CHECKS ITS OWN STATEMENTS, ON ITS OWN, EVERY CYCLE.

    Ledger #112, the client: "you need to run this synergistically and
    independently of me. the app should have this self checker and repairer on
    hand." The gates are mine and run when I run them; this runs on a
    fisherman's machine at 3 a.m. with nobody watching, which is when a
    two-hourly rebuild can quietly start telling him something untrue.
    """
    try:
        return selfaudit.run(DATA, _expected_stamp(),
                             rebuild_fn=_rebuild_for_doctor if rebuild_ok else None,
                             log=log)
    except Exception as e:                       # never break the cycle it guards
        log(f"  self-audit error: {e}")
        return {"ok": True, "contradictions": [], "open": [], "repaired": [],
                "error": str(e)}


def _rebuild_for_doctor():
    """The doctor's repair hook: a full local rebuild, returning the page size."""
    os.environ["AFO_ENGINE_VERSION"] = VERSION
    return rebuild(SEEDS, DATA, PIPELINE, log=print)


# --------------------------------------------------------------------- seeding
def _seed():
    """First run: copy the shipped raw records + built page into the writable
    data dir, and extract the static geometry (baked into the page) into
    se_openings_data.json so refreshes can re-render without any source geojson."""
    import shutil, re
    os.makedirs(os.path.join(DATA, "raw"), exist_ok=True)
    os.makedirs(os.path.join(DATA, "areas"), exist_ok=True)
    os.makedirs(os.path.join(DATA, "eo_pdfs"), exist_ok=True)
    if not any(f.endswith(".json") for f in os.listdir(os.path.join(DATA, "raw"))):
        for f in os.listdir(os.path.join(SEEDS, "raw")):
            shutil.copy(os.path.join(SEEDS, "raw", f), os.path.join(DATA, "raw", f))
    # non-SE areas' per-unit status records (Kodiak, PWS, ...) — seeded so the
    # installed app shows live status immediately, refreshed by fetch_detect.
    seeds_areas = os.path.join(SEEDS, "areas")
    if os.path.isdir(seeds_areas) and not any(
            f.endswith(".json") for f in os.listdir(os.path.join(DATA, "areas"))):
        for f in os.listdir(seeds_areas):
            shutil.copy(os.path.join(seeds_areas, f), os.path.join(DATA, "areas", f))
    for f in ("app_data.json", "SE_Openings.html"):
        dst = os.path.join(DATA, f)
        if not os.path.exists(dst) and os.path.exists(os.path.join(SEEDS, f)):
            shutil.copy(os.path.join(SEEDS, f), dst)
    # Extract the baked multi-area dataset from the page, once, so refreshes can
    # reuse the static geometry: regions_data.json (all areas) + se_openings_data.json
    # (the SE block restatus updates).
    rdj = os.path.join(DATA, "regions_data.json")
    sod = os.path.join(DATA, "se_openings_data.json")
    html = os.path.join(DATA, "SE_Openings.html")
    if (not os.path.exists(rdj) or not os.path.exists(sod)) and os.path.exists(html):
        try:
            txt = open(html, encoding="utf-8").read()
            m = re.search(r"const DATA_ALL = (\{.*?\});", txt, re.S) or re.search(r"const DATA = (\{.*?\});", txt, re.S)
            if m:
                obj = json.loads(m.group(1))
                if not os.path.exists(rdj):
                    open(rdj, "w", encoding="utf-8").write(m.group(1))
                se = obj["regions"]["SE"] if "regions" in obj else obj
                if not os.path.exists(sod):
                    json.dump(se, open(sod, "w", encoding="utf-8"), separators=(",", ":"))
        except Exception as e:
            print("could not extract dataset from page:", e)


def _as_of():
    try:
        d = json.load(open(os.path.join(DATA, "app_data.json"), encoding="utf-8"))
        return d.get("generated") or d.get("now")
    except Exception:
        return None


def _releases():
    try:
        return json.load(open(os.path.join(DATA, "app_data.json"), encoding="utf-8")).get("releases", [])
    except Exception:
        return []


def _load_state():
    try:
        return json.load(open(STATE_FILE, encoding="utf-8"))
    except Exception:
        return {"last_check": None, "last_result": None, "next_poll": None, "flagged": []}


def _save_state(s):
    try:
        json.dump(s, open(STATE_FILE, "w", encoding="utf-8"), default=str, indent=1)
    except Exception:
        pass


def _next_poll():
    try:
        return scheduler.next_poll(_releases()).isoformat(timespec="minutes")
    except Exception:
        return (dt.datetime.now() + dt.timedelta(hours=24)).isoformat(timespec="minutes")


# ------------------------------------------------------------------- refresh
def refresh(force_rebuild=False):
    """One fetch+parse+rebuild cycle. Safe to call anytime; serialized. Returns
    a summary and updates state.json. Never raises for a network problem."""
    with _lock:
        st = _load_state()
        res = fetch_detect.run(DATA, log=print)
        # announcements ingested before full_text existed get their complete
        # words topped up in place (ledger #89); a fill is a page change, so it
        # forces the rebuild the same way a new announcement does
        try:
            bf = fetch_detect.backfill_full_text(DATA, log=print)
        except Exception as e:
            print("backfill error:", e); bf = {"filled": 0}
        # re-derive anything still carrying an older grammar (ledger #113)
        try:
            reparse.run(DATA, log=print)
        except Exception as e:
            print("  reparse skipped:", e)
        st["last_check"] = res.get("checked_at")
        st["last_result"] = {k: res[k] for k in ("ok", "new", "ingested") if k in res}
        st["flagged"] = res.get("flagged", [])
        rebuilt = False
        if res.get("ingested", 0) > 0 or bf.get("filled", 0) > 0 or force_rebuild:
            try:
                sz = rebuild(SEEDS, DATA, PIPELINE, log=print)
                rebuilt = sz > 0
            except Exception as e:
                print("rebuild failed:", e); traceback.print_exc()
            # a rebuild must never leave a damaged page behind — the doctor
            # validates it and falls back to the shipped map if it is broken
            dr = doctor.run(DATA, SEEDS, rebuild_fn=None, log=print)
            for f in dr["findings"]:
                print("DOCTOR:", f)
        # SELF-AUDIT BEFORE PUBLISHING (ledger #112). The doctor has just
        # proved the page is INTACT; this proves it is not saying something the
        # app's own records contradict — and repairs what it can before those
        # bytes go to the phone page. A contradiction it cannot repair is
        # carried onto the page in words rather than hidden.
        sa = _self_audit(rebuild_ok=True)
        st["audit"] = {"ok": sa.get("ok", True),
                       "open": [f"{c['id']}: {c['what']}" for c in sa.get("open", [])],
                       "repaired": sa.get("repaired", [])}
        if sa.get("repaired"):
            rebuilt = True
        st["as_of"] = _as_of()
        st["next_poll"] = _next_poll()
        _save_state(st)
        # THE PHONE PAGE IS AN EXTENSION OF THIS REFRESH (ledger #79): when
        # publishing is configured, every validated rebuild pushes the page
        # to the client's own Netlify site — no hand re-deploys, ever. Runs
        # AFTER the doctor pass above, so a damaged page can never publish;
        # skips when the page's bytes are unchanged; never breaks refresh.
        pub = publisher.maybe_publish(DATA, os.path.join(DATA, "SE_Openings.html"), log=print)
        return {"ok": res.get("ok", False), "reason": res.get("reason"),
                "new": res.get("new", 0), "ingested": res.get("ingested", 0),
                "rebuilt": rebuilt, "flagged": res.get("flagged", []),
                "published": pub, "audit": st.get("audit"),
                "as_of": st["as_of"], "next_poll": st["next_poll"]}


def scheduler_loop():
    """Wake at each anticipated poll time, refresh, repeat. A resident thread."""
    while True:
        try:
            nxt = scheduler.next_poll(_releases())
        except Exception:
            nxt = dt.datetime.now() + dt.timedelta(hours=24)
        wait = max(60, (nxt - dt.datetime.now()).total_seconds())
        st = _load_state(); st["next_poll"] = nxt.isoformat(timespec="minutes"); _save_state(st)
        time.sleep(wait)
        try:
            print(f"[{dt.datetime.now().isoformat(timespec='seconds')}] anticipated poll")
            # force a re-render even with nothing new: statuses are TIME-driven
            # ("opens 10:00 a.m. today" must flip to open on schedule, not wait
            # for the next announcement to arrive)
            refresh(force_rebuild=True)
        except Exception as e:
            print("scheduled refresh error:", e); traceback.print_exc()
            # whatever broke the cycle, leave the data servable before sleeping
            try:
                dr = doctor.run(DATA, SEEDS, rebuild_fn=None, log=print)
                for f in dr["findings"]:
                    print("DOCTOR:", f)
            except Exception:
                pass


# ---------------------------------------------------------------- API handlers
def _section_count():
    try:
        d = json.load(open(os.path.join(DATA, "se_openings_data.json"), encoding="utf-8"))
        return len(d.get("sections", {}))
    except Exception:
        return None


def api_state():
    st = _load_state()
    return {"version": VERSION, "booting": False, "page_version": _page_engine(), "as_of": _as_of(),
            "sections": _section_count(), "region": "Southeast (5 AAC 33)",
            "last_check": st.get("last_check"), "next_poll": st.get("next_poll") or _next_poll(),
            "flagged": len(st.get("flagged", [])),
            # what the app currently knows is wrong with what it is saying —
            # answerable by looking, without asking me (axiom 33 clause 1)
            "contradictions": len((st.get("audit") or {}).get("open") or []),
            "audit": st.get("audit")}


def api_status():
    st = _load_state()
    return {"version": VERSION, "as_of": _as_of(), "region": "Southeast (5 AAC 33)",
            "last_check": st.get("last_check"), "next_poll": st.get("next_poll") or _next_poll(),
            "last_result": st.get("last_result"),
            "flagged": st.get("flagged", []),
            "releases": len(_releases())}


def api_refresh(body):
    return refresh(force_rebuild=bool((body or {}).get("rebuild")))


def api_publish_status():
    return publisher.status(DATA)              # never includes the token


def api_publish(body):
    body = body or {}
    if body.get("action") == "off":
        return publisher.disable(DATA)
    if body.get("action") == "now":
        cfg = publisher.load_cfg(DATA)
        cfg["last_hash"] = None                 # force even if unchanged
        publisher.save_cfg(DATA, cfg)
        return publisher.maybe_publish(DATA, os.path.join(DATA, "SE_Openings.html"), log=print)
    token = (body.get("token") or "").strip()
    site = (body.get("site") or "").strip()
    if not token or not site:
        return {"error": "Both the access token and the site name are needed."}
    try:
        return publisher.configure(DATA, token, site)
    except Exception as e:
        return {"error": str(e)[:300]}


PUBLISH_PAGE = """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Publish — Alaska Fishery Openings</title>
<style>body{font:15px/1.5 system-ui;max-width:640px;margin:40px auto;padding:0 18px;color:#101d25;background:#eef1f3}
.card{background:#fff;border:1px solid #dde5ea;border-left:4px solid #137a3a;border-radius:12px;padding:18px 22px;margin:14px 0}
h1{font-size:20px} label{display:block;font-weight:700;margin:12px 0 4px} input{width:100%;font:inherit;padding:8px 10px;border:1px solid #dde5ea;border-radius:8px}
button{font:inherit;font-weight:700;background:#0b4f6c;color:#fff;border:0;border-radius:9px;padding:9px 16px;margin:14px 8px 0 0;cursor:pointer}
button.alt{background:#5c6c77} .ok{color:#137a3a;font-weight:700} .bad{color:#c02626;font-weight:700} small{color:#5c6c77}</style></head><body>
<h1>Publish the phone page automatically</h1>
<div class="card"><p>When this is on, <b>every time the app refreshes from ADF&amp;G</b> it pushes the
updated map to your own Netlify site — the public link stays current by itself.</p>
<p><b>One-time setup:</b> in Netlify go to <b>User settings &rarr; Applications &rarr; Personal access
tokens &rarr; New access token</b>, name it anything, copy it, and paste it below with your site name.
<small>The token is stored only in this app's data folder on this computer. It is never shown again here.</small></p>
<label>Netlify access token</label><input id="tok" type="password" placeholder="nfp_...">
<label>Site name or URL</label><input id="site" placeholder="alaska-salmon-openings">
<button onclick="save()">Save &amp; turn on</button>
<button class="alt" onclick="pubnow()">Publish now</button>
<button class="alt" onclick="off()">Turn off</button>
<p id="msg"></p></div>
<div class="card"><b>Status</b><pre id="st" style="white-space:pre-wrap"></pre></div>
<script>
async function st(){const r=await fetch('/api/publish').then(r=>r.json());
  document.getElementById('st').textContent=JSON.stringify(r,null,1);}
async function save(){const t=document.getElementById('tok').value,s=document.getElementById('site').value;
  msg('Checking the token against your Netlify account…');
  const r=await fetch('/api/publish',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token:t,site:s})}).then(r=>r.json());
  msg(r.error?('✗ '+r.error):'✓ Connected to '+(r.site_url||r.site_name)+' — auto-publish is ON. Use “Publish now” to push the current map immediately.',!r.error); st();}
async function pubnow(){msg('Publishing…');
  const r=await fetch('/api/publish',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'now'})}).then(r=>r.json());
  msg(r.published?('✓ Published — '+(r.url||'')):('✗ '+(r.reason||r.error||'not configured')),r.published); st();}
async function off(){await fetch('/api/publish',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'off'})}); msg('Auto-publish is off.'); st();}
function msg(t,ok){const m=document.getElementById('msg');m.textContent=t;m.className=ok===false?'bad':(ok?'ok':'');}
st();
</script></body></html>"""


def api_selftest():
    from tests import test_all
    return test_all.run()


def api_health():
    """Diagnose AND repair on demand — the health check leaves the app healthy.

    HEALTH IS TWO QUESTIONS, NOT ONE (ledger #112): are my files intact
    (doctor), and is what I am telling the captain true (self-audit)? A tree
    can pass the first and fail the second — that is exactly ledger #110, where
    every file was perfect and four announcements were silently off the chart.
    """
    d = doctor.run(DATA, SEEDS, rebuild_fn=_rebuild_for_doctor, log=print)
    a = _self_audit(rebuild_ok=True)
    d["audit"] = {"ok": a.get("ok", True), "repaired": a.get("repaired", []),
                  "open": [{"id": c["id"], "what": c["what"], "detail": c["detail"]}
                           for c in a.get("open", [])]}
    d["ok"] = bool(d.get("ok", True)) and a.get("ok", True)
    return d


def api_quit(body):
    threading.Timer(0.4, lambda: os._exit(0)).start()
    return {"ok": True, "message": "engine shutting down"}


# SERVE FIRST, HEAL WHILE SERVING (ledger #117). Boot now does real work
# before the chart is ready — re-parse held announcements with this build's
# grammar, reconcile the page to this engine, self-audit and rebuild a 14 MB
# page — and on a slow machine after an upgrade that can pass the launcher's
# 45-second patience, which then tells the fisherman "the engine did not
# answer" about an engine that was about to. Caught by the release gate under
# Wine: install fine, files fine, engine answering fifty seconds later. So the
# port is bound in the first second and answers /api/state at once; every
# other request gets a small "starting" page that reloads itself, and the REAL
# page is never served until reconciliation is done (axiom 33 holds).
BOOTING = {"on": True, "step": "starting", "since": None}

STARTING_PAGE = """<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="refresh" content="3"><title>Alaska Salmon Openings</title>
<style>html,body{margin:0;height:100%%;background:#0c1417;color:#eaf2f5;font:16px/1.5 system-ui,Segoe UI,Roboto,sans-serif}
.w{max-width:520px;margin:18vh auto 0;padding:0 22px}h1{font-size:22px;margin:0 0 6px}
p{margin:6px 0;color:#9db0b9}.b{display:inline-block;margin-top:14px;padding:4px 10px;border-radius:8px;background:#12333d;color:#bfe4ec;font-size:13px}
.bar{height:4px;background:#243238;border-radius:3px;overflow:hidden;margin-top:18px}.bar i{display:block;height:100%%;width:40%%;background:#4cc172;animation:m 1.6s ease-in-out infinite alternate}
@keyframes m{from{transform:translateX(-20%%)}to{transform:translateX(220%%)}}</style></head>
<body><div class="w"><h1>Alaska &mdash; Salmon Openings</h1>
<p>Checking the announcements on this computer and drawing the chart. After an update this takes up to a minute; the chart opens by itself when it is ready.</p>
<div class="bar"><i></i></div><span class="b">version %s &middot; %s</span></div></body></html>"""

GET_ROUTES = {"/api/state": api_state, "/api/status": api_status,
              "/api/selftest": api_selftest, "/api/health": api_health,
              "/api/publish": api_publish_status}
POST_ROUTES = {"/api/refresh": api_refresh, "/api/quit": api_quit,
               "/api/publish": api_publish}


class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *a, **kw):
        super().__init__(*a, directory=DATA, **kw)

    def log_message(self, *a):
        pass

    # THE WINDOW IS A BROWSER, AND A BROWSER CACHES (ledger #102, axiom 33).
    # The JSON API said no-store; the PAGE ITSELF went out through
    # SimpleHTTPRequestHandler with only Last-Modified, so Chromium's heuristic
    # freshness let the app window keep rendering a page from before an upgrade
    # without ever asking the server. Caught in the tracker, fixed here in the
    # same hour because it is the same handler shape and therefore the same bug.
    def end_headers(self):
        if "Cache-Control" not in getattr(self, "_hdr_keys", ()):
            self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
            self.send_header("Pragma", "no-cache")
            self.send_header("Expires", "0")
        super().end_headers()

    def send_header(self, keyword, value):
        if not hasattr(self, "_hdr_keys"):
            self._hdr_keys = set()
        self._hdr_keys.add(keyword)
        super().send_header(keyword, value)

    def send_response(self, *a, **kw):
        self._hdr_keys = set()   # per response, not per keep-alive connection
        super().send_response(*a, **kw)

    def _send(self, code, payload, raw=False, ctype="application/json"):
        body = payload.encode() if raw else json.dumps(payload, default=str).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype + ("" if raw else "; charset=utf-8"))
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _fail(self, e, where):
        print("ERROR", where, e); traceback.print_exc()
        self._send(500, {"error": "Something went wrong; see data/openings.log.", "where": where})

    def do_GET(self):
        u = urllib.parse.urlparse(self.path)
        if BOOTING["on"]:
            if u.path == "/api/state":
                return self._send(200, {"version": VERSION, "booting": True,
                                        "step": BOOTING["step"]})
            if u.path.startswith("/api/"):
                return self._send(503, {"error": "starting", "booting": True,
                                        "step": BOOTING["step"]})
            body = (STARTING_PAGE % (VERSION, BOOTING["step"])).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)
            return
        if u.path in GET_ROUTES:
            try:
                self._send(200, GET_ROUTES[u.path]())
            except Exception as e:
                self._fail(e, u.path)
            return
        if u.path == "/publish":
            body = PUBLISH_PAGE.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        if u.path in ("/", "/index.html"):
            self.path = "/SE_Openings.html"
        return super().do_GET()

    def do_POST(self):
        u = urllib.parse.urlparse(self.path)
        if BOOTING["on"] and u.path != "/api/quit":
            return self._send(503, {"error": "starting", "booting": True,
                                    "step": BOOTING["step"]})
        if u.path not in POST_ROUTES:
            return self._send(404, {"error": "Unknown request."})
        try:
            n = int(self.headers.get("Content-Length") or 0)
            body = json.loads(self.rfile.read(n) or b"{}") if n else {}
        except Exception as e:
            return self._fail(e, u.path)
        try:
            self._send(200, POST_ROUTES[u.path](body))
        except Exception as e:
            self._fail(e, u.path)


class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True

    def handle_error(self, request, client_address):
        # A client that closes mid-response (or shutdown killing a serve thread)
        # raises a connection error here — benign; keep it out of the log.
        et = sys.exc_info()[0]
        if et and issubclass(et, (BrokenPipeError, ConnectionResetError, ConnectionAbortedError)):
            return
        super().handle_error(request, client_address)


def main():
    # BIND FIRST (ledger #117): the launcher asks /api/state within a second
    # of starting us and gives up after forty-five; the boot work below can
    # legitimately take longer than that after an upgrade. Answer at once,
    # serve a self-reloading "starting" page, and only switch to the real
    # chart once it has been reconciled to this engine.
    port = PORT
    httpd = None
    for _ in range(20):
        try:
            httpd = Server((HOST, port), Handler); break
        except OSError:
            port += 1
    if httpd is None:
        print("No free port; close other copies and retry."); return
    BOOTING["since"] = dt.datetime.now().isoformat(timespec="seconds")
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    url = f"http://{HOST}:{port}"
    print(f"  listening at {url} (starting page) while the chart is prepared")

    def step(name):
        BOOTING["step"] = name
        print(f"  boot: {name}")

    # crash-loop guard FIRST: three boots that never reached serving means the
    # working data is the prime suspect — reset it from the shipped seeds
    step("checking last run")
    note = doctor.boot_check(DATA, SEEDS, log=print)
    _seed()
    # boot diagnosis + repair: whatever state the last run left, serve healthy
    step("checking files")
    dr = doctor.run(DATA, SEEDS, rebuild_fn=None, log=print)
    for f in dr["findings"]:
        print("DOCTOR:", f)
    # A SHIPPED GRAMMAR FIX REACHES THE ANNOUNCEMENTS ALREADY HERE (ledger
    # #113). Records carry the fingerprint of the parser that made them; when
    # this build's parser differs, they are re-derived from their own stored
    # words — no network, and every future fix is retroactive on first start.
    step("re-reading announcements with this version's grammar")
    try:
        rr = reparse.run(DATA, log=print)
        _ch = [x for x in rr.get("reparsed", []) if "->" in x]
        if _ch:
            print(f"  re-parsed {len(_ch)} announcement(s) with this build's grammar; "
                  f"{rr.get('gained', 0)} placement(s) recovered")
    except Exception as e:
        print("  reparse skipped:", e)
    step("drawing the chart")
    rp = _reconcile_page_version()
    if rp.get("rebuilt"):
        print(f"  page rebuilt for engine {VERSION}")
    # and before serving one byte of the chart, check that what we are about
    # to serve does not contradict what we hold (ledger #112)
    step("checking the chart against the announcements")
    sa = _self_audit(rebuild_ok=True)
    st = _load_state()
    st["audit"] = {"ok": sa.get("ok", True),
                   "open": [f"{c['id']}: {c['what']}" for c in sa.get("open", [])],
                   "repaired": sa.get("repaired", [])}
    st["next_poll"] = _next_poll(); _save_state(st)

    BOOTING["on"] = False              # the real chart is now what / serves
    doctor.boot_ok(DATA)               # serving: clear the crash counter
    print("=" * 62)
    print("  Alaska Fishery Openings — Southeast (5 AAC 33)")
    print(f"  Version {VERSION}   |   {url}")
    print(f"  Map as of: {_as_of()}   |   next anticipated check: {_next_poll()}")
    print("  Binds to 127.0.0.1 only. Fetches only from adfg.alaska.gov.")
    print("=" * 62)
    if "--no-scheduler" not in sys.argv:
        threading.Thread(target=scheduler_loop, daemon=True).start()
    if "--no-browser" not in sys.argv and "--no-scheduler" in sys.argv:
        import webbrowser
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        print("\nStopped.")


if __name__ == "__main__":
    main()
