"""Self-diagnosis and self-repair for the Alaska Fishery Openings engine.

This app runs unattended on a captain's machine. A corrupted file, a rebuild
that died mid-write, or a crash loop must never leave him with a dead window —
the app diagnoses itself and repairs itself, and the worst possible outcome is
the shipped known-good map with an honest as-of date, never a crash.

DESIGN — repair is progressive and never destroys evidence:
  Level 0  housekeeping: rotate an oversized log, prune old announcement PDFs
           (the parsed raw/areas JSON is the record; the PDF is only needed to
           parse), cap the quarantine folder.
  Level 1  a damaged per-release file (raw/*.json, areas/*.json) is QUARANTINED
           (moved to data/quarantine/, never deleted) — the rebuild works
           without it and the next fetch cycle re-downloads that release.
  Level 2  a damaged derived file (app_data.json, se_openings_data.json,
           regions_data.json, state.json) is quarantined and re-derived: state
           resets to defaults; the datasets re-extract from the shipped page or
           rebuild from the raw records.
  Level 3  a damaged or missing map page is rebuilt; if the rebuild itself
           fails, the SHIPPED seed page is restored so the app always serves a
           working map (stale-but-dated beats dead).
  Boot     a crash LOOP (3 consecutive boots that never reached serving) resets
           the data dir from the seeds — quarantining, not deleting, what was
           there — because at that point the data, not the code, is the prime
           suspect.

Every finding and repair is returned and logged; /api/health exposes them.
Pure stdlib.
"""
import os, json, shutil, time, datetime as dt

CRITICAL_JSON = ("app_data.json", "se_openings_data.json", "regions_data.json")
PAGE = "SE_Openings.html"
LOG_MAX = 5 * 1024 * 1024          # rotate log past 5 MB
LOG_KEEP = 500 * 1024              # keep the newest 500 KB on rotation
PDF_KEEP_NEWEST = 40               # keep the newest N announcement PDFs
PDF_MAX_AGE_DAYS = 60              # and anything younger than this
QUAR_KEEP = 25                     # newest quarantined files kept


def _ts():
    return dt.datetime.now().strftime("%Y%m%d-%H%M%S")


def _quarantine(data_dir, path, findings, why):
    qdir = os.path.join(data_dir, "quarantine")
    os.makedirs(qdir, exist_ok=True)
    dest = os.path.join(qdir, f"{_ts()}-{os.path.basename(path)}")
    try:
        shutil.move(path, dest)
        findings.append(f"quarantined {os.path.basename(path)} ({why})")
    except OSError:
        try:
            os.remove(path)
            findings.append(f"removed unreadable {os.path.basename(path)} ({why})")
        except OSError:
            findings.append(f"could not quarantine {os.path.basename(path)} ({why})")
    return dest


def _json_ok(path):
    try:
        with open(path, encoding="utf-8") as f:
            json.load(f)
        return True
    except Exception:
        return False


def _page_ok(path):
    """A servable map page: big enough, carries the dataset, and is complete
    (a rebuild that died mid-write leaves no closing tag)."""
    try:
        size = os.path.getsize(path)
        if size < 1_000_000:
            return False
        with open(path, "rb") as f:
            head = f.read(400_000).decode("utf-8", "replace")
            f.seek(max(0, size - 4096))
            tail = f.read().decode("utf-8", "replace")
        return ("const DATA_ALL" in head) and ("</html>" in tail)
    except Exception:
        return False


# ------------------------------------------------------------------ housekeeping
def housekeeping(data_dir, findings):
    # log rotation — an append-only log must not eat the disk it lives on
    log = os.path.join(data_dir, "openings.log")
    try:
        if os.path.exists(log) and os.path.getsize(log) > LOG_MAX:
            with open(log, "rb") as f:
                f.seek(-LOG_KEEP, 2)
                tail = f.read()
            with open(log + ".old", "wb") as f:
                f.write(tail)
            open(log, "w").close()
            findings.append(f"rotated openings.log (> {LOG_MAX // (1024*1024)} MB)")
    except OSError:
        pass
    # announcement PDFs: parsed JSON is the record; old PDFs are dead weight
    pdir = os.path.join(data_dir, "eo_pdfs")
    try:
        if os.path.isdir(pdir):
            pdfs = sorted(((os.path.getmtime(os.path.join(pdir, f)), f)
                           for f in os.listdir(pdir) if f.endswith(".pdf")), reverse=True)
            cutoff = time.time() - PDF_MAX_AGE_DAYS * 86400
            removed = 0
            for i, (mt, f) in enumerate(pdfs):
                if i >= PDF_KEEP_NEWEST and mt < cutoff:
                    try:
                        os.remove(os.path.join(pdir, f)); removed += 1
                    except OSError:
                        pass
            if removed:
                findings.append(f"pruned {removed} announcement PDFs older than {PDF_MAX_AGE_DAYS} days")
    except OSError:
        pass
    # quarantine cap — evidence, not an archive
    qdir = os.path.join(data_dir, "quarantine")
    try:
        if os.path.isdir(qdir):
            qs = sorted(os.listdir(qdir), reverse=True)
            for f in qs[QUAR_KEEP:]:
                try:
                    os.remove(os.path.join(qdir, f))
                except OSError:
                    pass
            if len(qs) > QUAR_KEEP:
                findings.append(f"trimmed quarantine to newest {QUAR_KEEP}")
    except OSError:
        pass


# ----------------------------------------------------------------- diagnose+fix
def _reseed_file(data_dir, seeds_dir, name, findings):
    src = os.path.join(seeds_dir, name)
    if os.path.exists(src):
        shutil.copy(src, os.path.join(data_dir, name))
        findings.append(f"restored {name} from the shipped seed")
        return True
    return False


def _extract_datasets_from_page(data_dir, findings):
    """regions_data.json / se_openings_data.json re-extracted from the page —
    the same first-run seeding app.py does."""
    import re
    html = os.path.join(data_dir, PAGE)
    if not os.path.exists(html):
        return False
    try:
        txt = open(html, encoding="utf-8", errors="replace").read()
        m = re.search(r"const DATA_ALL = (\{.*?\});", txt, re.S)
        if not m:
            return False
        obj = json.loads(m.group(1))
        rdj = os.path.join(data_dir, "regions_data.json")
        sod = os.path.join(data_dir, "se_openings_data.json")
        if not os.path.exists(rdj):
            open(rdj, "w", encoding="utf-8").write(m.group(1))
            findings.append("re-extracted regions_data.json from the page")
        se = obj["regions"]["SE"] if "regions" in obj else obj
        if not os.path.exists(sod):
            json.dump(se, open(sod, "w", encoding="utf-8"), separators=(",", ":"))
            findings.append("re-extracted se_openings_data.json from the page")
        return True
    except Exception:
        return False


def run(data_dir, seeds_dir, rebuild_fn=None, repair=True, log=print):
    """Diagnose (and by default repair) the data directory. Returns
    {"ok": bool, "findings": [...], "checked_at": iso}. Never raises."""
    findings = []
    data_dir = os.path.abspath(data_dir)
    os.makedirs(data_dir, exist_ok=True)
    try:
        # 1) per-release records: a bad one is quarantined, never fatal
        for sub in ("raw", "areas"):
            d = os.path.join(data_dir, sub)
            if not os.path.isdir(d):
                continue
            for f in sorted(os.listdir(d)):
                if not f.endswith(".json"):
                    continue
                p = os.path.join(d, f)
                if not _json_ok(p):
                    if repair:
                        _quarantine(data_dir, p, findings, f"corrupt {sub} record")
                    else:
                        findings.append(f"corrupt {sub}/{f}")
        # 2) derived datasets
        need_rebuild = False
        for name in CRITICAL_JSON:
            p = os.path.join(data_dir, name)
            if os.path.exists(p) and not _json_ok(p):
                if repair:
                    _quarantine(data_dir, p, findings, "corrupt dataset")
                    need_rebuild = True
                else:
                    findings.append(f"corrupt {name}")
        st = os.path.join(data_dir, "state.json")
        if os.path.exists(st) and not _json_ok(st):
            if repair:
                _quarantine(data_dir, st, findings, "corrupt state")
                json.dump({"last_check": None, "last_result": None,
                           "next_poll": None, "flagged": []},
                          open(st, "w", encoding="utf-8"))
                findings.append("state.json reset to defaults")
            else:
                findings.append("corrupt state.json")
        # 3) the page itself
        page = os.path.join(data_dir, PAGE)
        page_bad = (not os.path.exists(page)) or (not _page_ok(page))
        if page_bad and repair:
            if os.path.exists(page):
                _quarantine(data_dir, page, findings, "damaged map page")
            _reseed_file(data_dir, seeds_dir, PAGE, findings)
            need_rebuild = True
        elif page_bad:
            findings.append("map page missing or damaged")
        # 4) missing datasets -> re-extract from the (now valid) page
        if repair:
            missing = [n for n in ("regions_data.json", "se_openings_data.json")
                       if not os.path.exists(os.path.join(data_dir, n))]
            if missing:
                _extract_datasets_from_page(data_dir, findings)
        # 5) re-derive current status by rebuilding, if anything was re-seeded
        if repair and need_rebuild and rebuild_fn is not None:
            try:
                sz = rebuild_fn()
                if sz and _page_ok(page):
                    findings.append("rebuilt the map from local records")
                else:
                    _reseed_file(data_dir, seeds_dir, PAGE, findings)
            except Exception as e:
                # the rebuild itself failing must never take the app down:
                # the shipped page is the floor the captain always gets
                _reseed_file(data_dir, seeds_dir, PAGE, findings)
                findings.append(f"rebuild failed ({type(e).__name__}); serving the shipped map")
        # 6) housekeeping
        if repair:
            housekeeping(data_dir, findings)
        ok = os.path.exists(page) and _page_ok(page) and all(
            _json_ok(os.path.join(data_dir, n))
            for n in CRITICAL_JSON if os.path.exists(os.path.join(data_dir, n)))
        return {"ok": ok, "findings": findings,
                "checked_at": dt.datetime.now().isoformat(timespec="seconds")}
    except Exception as e:                            # the doctor never crashes the patient
        findings.append(f"doctor error: {type(e).__name__}: {e}")
        return {"ok": False, "findings": findings,
                "checked_at": dt.datetime.now().isoformat(timespec="seconds")}


# ------------------------------------------------------------------- crash loop
BOOT_FILE = "boot.json"
CRASH_LOOP_AT = 3


def boot_check(data_dir, seeds_dir, log=print):
    """Called at engine start, BEFORE serving. Detects a crash loop (repeated
    boots that never reached 'serving') and, at the threshold, resets the data
    dir from the shipped seeds — quarantining what was there. Returns a note or
    None. Call boot_ok() once the server is actually serving."""
    p = os.path.join(data_dir, BOOT_FILE)
    try:
        b = json.load(open(p, encoding="utf-8")) if os.path.exists(p) else {}
    except Exception:
        b = {}
    attempts = int(b.get("attempts", 0)) + 1
    note = None
    if attempts >= CRASH_LOOP_AT:
        note = (f"crash loop detected ({attempts} boots without serving) — "
                f"resetting working data from the shipped seeds")
        log("DOCTOR: " + note)
        findings = []
        for name in CRITICAL_JSON + (PAGE, "state.json"):
            q = os.path.join(data_dir, name)
            if os.path.exists(q):
                _quarantine(data_dir, q, findings, "crash-loop reset")
        _reseed_file(data_dir, seeds_dir, PAGE, findings)
        _extract_datasets_from_page(data_dir, findings)
        for f in findings:
            log("DOCTOR: " + f)
        attempts = 0
    try:
        json.dump({"attempts": attempts, "at": dt.datetime.now().isoformat(timespec="seconds")},
                  open(p, "w", encoding="utf-8"))
    except OSError:
        pass
    return note


def boot_ok(data_dir):
    """The engine reached serving — clear the crash counter."""
    try:
        json.dump({"attempts": 0, "ok_at": dt.datetime.now().isoformat(timespec="seconds")},
                  open(os.path.join(data_dir, BOOT_FILE), "w", encoding="utf-8"))
    except OSError:
        pass
