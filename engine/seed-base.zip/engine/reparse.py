#!/usr/bin/env python3
"""RE-PARSE — a grammar fix reaches the announcements already on this machine.

WHY THIS EXISTS
---------------
2026-09-05, ledger #113, caught on the client's own machine minutes after he
installed 3.0.0. The Kodiak and Area M grammars had been fixed and shipped:
Kodiak #45's three fishing periods and Sand Point #26's three extensions parse
to 22 and 11 placed units on the bench. On HIS computer both still held ZERO,
and the chart was still missing those openings.

Because parsing happens ONCE, when a release is first fetched. The stored
record is never revisited. So a parser improvement only ever helps
announcements that have not arrived yet — and the announcements a captain needs
today are the ones already sitting in the folder, parsed by last week's code.
Shipping the fix was not the same as landing it, and nothing in the app knew
the difference.

The announcement's complete words already ride with every record (ledger #89),
which means the fix does not need the network: the text is here, and the parse
can simply be re-derived. Every record carries the fingerprint of the parser
that produced it; when the installed parser differs, the record is re-derived
from its own stored text. Every future grammar fix is therefore retroactive on
every machine, the first time the app starts after the upgrade.

THE SAFETY RULE, and it is the whole discipline of this file:
    A RE-PARSE MAY ADD PLACEMENTS. IT MAY NEVER SILENTLY REMOVE THEM ALL.
If the new parse places nothing where the old one placed something, the old
record stands and the disagreement is flagged. A newer parser is a better
guess, not an authority, and losing a captain's opening to an "improvement" is
the same wrong as never placing it.

Pure stdlib.
"""

import glob
import hashlib
import json
import os

PARSER_FILES = ("openparse.py", "extract.py")
HERE = os.path.dirname(os.path.abspath(__file__))


def fingerprint():
    """A hash of the parsers themselves — the same idea as the page's engine
    stamp (axiom 33): a version number cannot distinguish two builds of one
    release, and an in-release grammar fix is exactly that case."""
    h = hashlib.sha256()
    for fn in sorted(PARSER_FILES):
        try:
            with open(os.path.join(HERE, fn), "rb") as f:
                h.update(f.read())
        except Exception:
            h.update(b"?")
    return h.hexdigest()[:8]


def _jload(p, default=None):
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def _write(p, rec):
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(rec, f, ensure_ascii=False, indent=1)
    os.replace(tmp, p)


def _placed_units(rec):
    return len(rec.get("units") or [])


def _placed_areas(rec):
    """A Southeast release has placed something if any area names a unit, states
    a region-wide status, marks a hatchery pocket, or draws a line — NOT merely
    if it carries coordinates (ledger #112)."""
    n = 0
    for a in (rec.get("areas") or []):
        if (a.get("section") or a.get("district") or a.get("region_wide")
                or a.get("tha_pocket") or (a.get("rules") or [])):
            n += 1
    return n


def run(data_dir, log=print, force=False, limit=400):
    """Re-derive every record whose parser fingerprint is not the installed one.

    Returns a summary; never raises. One bad record never stops the pass — the
    whole point is that the machine heals itself without anybody watching.
    """
    import sys
    sys.path.insert(0, HERE)
    fp = fingerprint()
    out = {"parser": fp, "checked": 0, "reparsed": [], "gained": 0,
           "kept_old": [], "no_text": [], "errors": []}

    try:
        import openparse
    except Exception as e:
        out["errors"].append(f"openparse unavailable: {e}")
        openparse = None
    try:
        from extract import parse as se_parse
    except Exception as e:
        out["errors"].append(f"extract unavailable: {e}")
        se_parse = None

    jobs = []
    if openparse:
        jobs.append(("areas", openparse.parse, _placed_units))
    if se_parse:
        jobs.append(("raw", se_parse, _placed_areas))

    for sub, parser, counter in jobs:
        for p in sorted(glob.glob(os.path.join(data_dir, sub, "*.json"))):
            rid = os.path.basename(p)[:-5]
            if not rid.isdigit():
                continue                      # regulation-derived records aren't announcements
            if len(out["reparsed"]) >= limit:
                break
            rec = _jload(p)
            if not isinstance(rec, dict):
                continue
            if rec.get("_parser") == fp and not force:
                continue
            out["checked"] += 1
            text = rec.get("full_text") or ""
            if sub == "raw":
                # SOUTHEAST IS RE-DERIVED FROM ITS PDF, NEVER FROM BODY TEXT
                # (ledger #116). full_text is the announcement with its
                # furniture stripped and its lines rejoined — exactly the
                # structure the Southeast extractor reads section headings and
                # coordinate lines from. Re-parsing SE from it is lossy by
                # construction (a 26-area release came back smaller), which is
                # why the safety rule kept firing. The PDF is the source.
                pdf = os.path.join(data_dir, "eo_pdfs", rid + ".pdf")
                text = ""
                if os.path.exists(pdf):
                    try:
                        from fetch_detect import parse_pdf_text
                        text = parse_pdf_text(pdf) or ""
                    except Exception as e:
                        out["errors"].append(f"{rid}: pdf text: {e}")
                        text = ""
                if len(text.strip()) < 200:
                    # no PDF on disk: nothing faithful to re-derive from. Stamp
                    # it so the loop converges; the next fetch that brings the
                    # PDF back re-derives it.
                    rec["_parser"] = fp
                    rec["_parser_kept"] = "no PDF on disk to re-derive from"
                    _write(p, rec)
                    out["no_text"].append(rid)
                    continue
            if len(text.strip()) < 200:
                # nothing to re-derive from; leave it UNSTAMPED so a later
                # backfill of the words gets another chance at it
                out["no_text"].append(rid)
                continue
            try:
                new = parser(text, rid)
            except Exception as e:
                out["errors"].append(f"{rid}: {e}")
                continue
            was, now = counter(rec), counter(new)
            keep_reason = None
            if now < was:
                # THE SAFETY RULE, FINAL FORM: a re-parse may ADD placements and
                # may never REMOVE any. Proven necessary on the 30 seeded
                # Southeast releases (ledger #116): re-deriving them from their
                # PDFs through the bundled text extractor comes back SMALLER on
                # ten of them and EMPTY on two hatchery-pocket announcements
                # (Neets Bay, Kendrick Bay) whose closure lines the old records
                # carry — a divergence in text extraction, not in grammar. A
                # unit that maps to nothing is "unknown", never wrong; a lost
                # closure line is a wrong opening. The asymmetry decides it.
                keep_reason = f"new parse placed {now} where the old placed {was}"
            elif sub == "areas" and rec.get("region") and not new.get("region"):
                keep_reason = "re-parse lost the region"
            if keep_reason:
                # KEPT, AND STAMPED (ledger #116). Leaving a kept record
                # unstamped made C7 re-flag it every cycle forever — eleven
                # Southeast records on the client's machine, "still parsed by
                # an older grammar" on every boot with nothing anyone could do.
                # The disagreement is written INTO the record for the next
                # person to read; the loop converges.
                rec["_parser"] = fp
                rec["_parser_kept"] = keep_reason
                _write(p, rec)
                out["kept_old"].append(f"{rid}: {keep_reason} — old record kept")
                log(f"  REPARSE kept the old record for {rid} ({keep_reason})")
                continue
            # carry forward the things the parse does not produce
            for k in ("full_text",):
                if rec.get(k) and not new.get(k):
                    new[k] = rec[k]
            if not new.get("published") and rec.get("published"):
                new["published"] = rec["published"]
            new["_parser"] = fp
            _write(p, new)
            if now != was:
                out["reparsed"].append(f"{rid}: {was} -> {now} placement(s)")
                out["gained"] += max(0, now - was)
                log(f"  REPARSE {rid}: {was} -> {now} placement(s)")
            else:
                out["reparsed"].append(f"{rid}: unchanged ({now})")
    changed = [r for r in out["reparsed"] if "->" in r]
    if changed or out["kept_old"]:
        log(f"  REPARSE: {len(changed)} record(s) changed, "
            f"{out['gained']} placement(s) recovered, "
            f"{len(out['kept_old'])} old record(s) kept for safety")
    return out


# ---------------------------------------------------------------------- selftest
if __name__ == "__main__":
    import shutil, sys, tempfile
    tmp = tempfile.mkdtemp()
    fails = []
    try:
        os.makedirs(os.path.join(tmp, "areas")); os.makedirs(os.path.join(tmp, "raw"))
        fx = os.path.join(os.path.dirname(HERE), "tests", "fixtures", "nseo_recon")

        # THE REAL CASE: Kodiak #45, stored with ZERO units by the old parser,
        # its own words still on the record. The installed parser places 22.
        kod = open(os.path.join(fx, "KOD45.txt"), encoding="utf-8").read()
        json.dump({"release_id": "1833462759", "region": "Kodiak", "units": [],
                   "published": "2026-09-02T00:00", "full_text": kod,
                   "_unparsed": ["no named units parsed"], "_parser": "old00000"},
                  open(os.path.join(tmp, "areas", "1833462759.json"), "w"))
        # and Sand Point #26
        sp = open(os.path.join(fx, "SANDPT26.txt"), encoding="utf-8").read()
        json.dump({"release_id": "1834219457", "region": "AreaM", "units": [],
                   "published": "2026-09-04T00:00", "full_text": sp,
                   "_parser": "old00000"},
                  open(os.path.join(tmp, "areas", "1834219457.json"), "w"))
        # a record with no words to re-derive from
        json.dump({"release_id": "1829361326", "region": "Kodiak", "units": [],
                   "full_text": ""},
                  open(os.path.join(tmp, "areas", "1829361326.json"), "w"))
        # a record that already places, whose text the parser cannot improve on —
        # the safety rule must keep it rather than empty it
        json.dump({"release_id": "1811111111", "region": "Kodiak",
                   "units": [{"name": "Somewhere", "status": "open"}],
                   "full_text": "x" * 400, "_parser": "old00000"},
                  open(os.path.join(tmp, "areas", "1811111111.json"), "w"))

        res = run(tmp, log=lambda *a: None)
        k = _jload(os.path.join(tmp, "areas", "1833462759.json"))
        s = _jload(os.path.join(tmp, "areas", "1834219457.json"))
        if len(k.get("units") or []) < 20:
            fails.append(f"Kodiak #45 re-parsed to {len(k.get('units') or [])} units, "
                         f"expected 20+ — the shipped grammar fix did not land")
        if len(s.get("units") or []) < 10:
            fails.append(f"Sand Point #26 re-parsed to {len(s.get('units') or [])} units, "
                         f"expected 10+")
        if k.get("_parser") != fingerprint():
            fails.append("a re-parsed record was not stamped with the parser that made it")
        if not k.get("full_text"):
            fails.append("the re-parse dropped the announcement's own words")
        if "1829361326" not in res["no_text"]:
            fails.append("a record with no stored words was not reported as such")
        if _jload(os.path.join(tmp, "areas", "1829361326.json")).get("_parser"):
            fails.append("a record that could not be re-derived was stamped anyway — "
                         "it would never be retried after a text backfill")
        keep = _jload(os.path.join(tmp, "areas", "1811111111.json"))
        if not (keep.get("units") or []):
            fails.append("THE SAFETY RULE FAILED: a re-parse emptied a record that "
                         "was placing an opening")
        if not res["kept_old"]:
            fails.append("the safety rule fired but was not reported")

        # second pass is a no-op: stamped records are not re-derived again
        res2 = run(tmp, log=lambda *a: None)
        if res2["checked"] > 2:            # only the two unstampable ones
            fails.append(f"a second pass re-derived {res2['checked']} records; "
                         f"stamped records must be skipped")

        for f in fails:
            print("  FAIL:", f)
        print("SELFTEST PASS — a shipped grammar fix lands on records already held"
              if not fails else f"SELFTEST FAILED ({len(fails)})")
        sys.exit(0 if not fails else 1)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
