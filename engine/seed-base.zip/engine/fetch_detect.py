"""Anticipatory fetch + detect for the SE openings app (phase 2).

Runs on the user's machine (where the network lives), inside the standalone
app. One cycle:

  1. fetch the ADF&G Commercial Fisheries news listing (and its RSS mirror),
  2. read every release id from it,
  3. keep the ids we have not already parsed (raw/{id}.json absent),
  4. download each new release PDF,
  5. turn the PDF into text (pdfminer.six — pure Python, no poppler binary),
  6. parse it with extract.py and write raw/{id}.json,
     flagging (never guessing) anything it cannot parse.

The network functions are isolated from the parsing so the parsing is unit
tested offline, and every network call is wrapped so a connectivity failure
returns a clear status and never crashes the resident engine.

Pairs with scheduler.py: the engine calls run() at each anticipated poll time.
Pure stdlib + pdfminer.six.
"""
import os, re, json, time, urllib.request, urllib.error, datetime as dt

LISTING_URL = "https://www.adfg.alaska.gov/index.cfm?adfg=cfnews.main"
RSS_URL = "https://www.adfg.alaska.gov/index.cfm?adfg=rss.main"
PDF_URL = "https://www.adfg.alaska.gov/static/applications/dcfnewsrelease/{id}.pdf"
UA = "SE-Openings-App/2.0 (+local; contact NSRAA)"
TIMEOUT = 30

# A release id is the numeric key that also names its PDF. Seen in the listing
# both as the PDF href and as the id= query parameter of the item link.
_ID_PATTERNS = [
    re.compile(r"dcfnewsrelease/(\d{6,})\.pdf", re.I),
    re.compile(r"[?&](?:id|announcement_id|newsid)=(\d{6,})", re.I),
    re.compile(r"cfnewsrelease[^0-9]{0,4}(\d{6,})", re.I),
    re.compile(r"<guid[^>]*>[^<]*?(\d{6,})[^<]*</guid>", re.I),
]


# --------------------------------------------------------------- parsing (offline)
def list_release_ids(listing_text):
    """Every distinct release id mentioned in a listing/RSS document, newest
    first (the listing is already newest-first; we preserve first-seen order)."""
    seen = []
    for rx in _ID_PATTERNS:
        for m in rx.finditer(listing_text or ""):
            i = m.group(1)
            if i not in seen:
                seen.append(i)
    return seen


def new_ids(listing_text, raw_dir):
    """Ids in the listing we have not already parsed to raw/{id}.json."""
    have = {f[:-5] for f in os.listdir(raw_dir) if f.endswith(".json") and not f.endswith(".notes.md")} \
        if os.path.isdir(raw_dir) else set()
    return [i for i in list_release_ids(listing_text) if i not in have]


def pdf_to_text(path):
    """PDF -> text with pdfminer.six (validated to match pdftotext on the 30
    ground-truth releases: precision 1.000, recall 0.957)."""
    from pdfminer.high_level import extract_text
    return extract_text(path)


def parse_pdf(path, release_id):
    """PDF file -> structured raw record via the deterministic extractor."""
    from extract import parse
    return parse(pdf_to_text(path), release_id)


def parse_pdf_text(path):
    return pdf_to_text(path)


# --------------------------------------------------------------- network (on device)

def _headline(text):
    """The announcement's own first meaningful line, for the surfaced banner —
    a captain needs to know WHICH opening he is being sent to read, not just an
    id number."""
    for ln in (text or "").splitlines():
        ln = " ".join(ln.split())
        if len(ln) > 12 and not ln.lower().startswith(
                ("alaska department", "division of", "contact", "for immediate",
                 "p.o. box", "po box", "www.", "phone", "fax")):
            return ln[:120]
    return ""

def _get(url, binary=False):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
        data = r.read()
    return data if binary else data.decode("utf-8", "replace")


def fetch_listing():
    """The listing text, with the RSS mirror appended so ids from either source
    are seen. Returns "" on any network error (caller reports it)."""
    parts = []
    for u in (LISTING_URL, RSS_URL):
        try:
            parts.append(_get(u))
        except (urllib.error.URLError, OSError, TimeoutError):
            pass
    return "\n".join(parts)


def download_pdf(release_id, dest_dir):
    os.makedirs(dest_dir, exist_ok=True)
    dest = os.path.join(dest_dir, release_id + ".pdf")
    data = _get(PDF_URL.format(id=release_id), binary=True)
    if not data[:4] == b"%PDF":
        raise ValueError("not a PDF")
    with open(dest, "wb") as f:
        f.write(data)
    return dest


# ------------------------------------------------------- backfill the full words
def backfill_full_text(data_dir, max_fill=12, log=print):
    """Give already-ingested announcements their complete body text.

    full_text (ledger #89) is written at parse time, so records ingested before
    it existed carry none, and an announcement in force for a week would show a
    clipped clause for that whole week. This tops them up in place: the PDF on
    disk if we kept it, otherwise one download. Newest first, capped, and it
    NEVER raises — a backfill that fails leaves the record exactly as it was.
    """
    filled, tried = 0, 0
    pdf_dir = os.path.join(data_dir, "eo_pdfs")
    todo = []
    for sub in ("raw", "areas"):
        d = os.path.join(data_dir, sub)
        if not os.path.isdir(d):
            continue
        for fn in os.listdir(d):
            if not fn.endswith(".json"):
                continue
            path = os.path.join(d, fn)
            try:
                with open(path, encoding="utf-8") as f:
                    rec = json.load(f)
            except Exception:
                continue
            if rec.get("full_text"):
                continue
            todo.append(((rec.get("published") or ""), path, fn[:-5]))
    todo.sort(reverse=True)                      # the ones in force first
    for _pub, path, rid in todo[:max_fill]:
        tried += 1
        try:
            pdf = os.path.join(pdf_dir, rid + ".pdf")
            if not os.path.exists(pdf):
                pdf = download_pdf(rid, pdf_dir)
            from extract import _body_text
            body = _body_text(parse_pdf_text(pdf))
            if not body:
                continue
            with open(path, encoding="utf-8") as f:
                rec = json.load(f)
            rec["full_text"] = body
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(rec, f, ensure_ascii=False, indent=1)
            os.replace(tmp, path)
            filled += 1
        except Exception as e:                   # offline, 404, unreadable PDF
            log(f"  backfill skipped {rid}: {e}")
    if tried:
        log(f"  full-text backfill: {filled}/{tried} announcements topped up"
            f" ({len(todo)} still without their complete words)")
    return {"filled": filled, "tried": tried, "remaining": max(0, len(todo) - filled)}


# --------------------------------------------------------------- one full cycle
def run(data_dir, offline_listing=None, max_new=40, log=print):
    """Detect and ingest new releases. Returns a summary dict. Never raises for
    a network problem — it reports it. Set offline_listing to a listing string
    to run the detect/ingest path without touching the network (tests)."""
    raw_dir = os.path.join(data_dir, "raw")
    areas_dir = os.path.join(data_dir, "areas")
    pdf_dir = os.path.join(data_dir, "eo_pdfs")
    os.makedirs(raw_dir, exist_ok=True)
    os.makedirs(areas_dir, exist_ok=True)
    started = dt.datetime.now().isoformat(timespec="seconds")

    listing = offline_listing if offline_listing is not None else fetch_listing()
    if not listing:
        return {"ok": False, "checked_at": started, "reason": "could not reach ADF&G",
                "new": 0, "ingested": 0, "flagged": [], "ids": []}

    # a new id is one we have parsed to NEITHER raw/ (SE) nor areas/ (other areas)
    have = {f[:-5] for d in (raw_dir, areas_dir) if os.path.isdir(d)
            for f in os.listdir(d) if f.endswith(".json")}
    listed = list_release_ids(listing)
    todo = [i for i in listed if i not in have][:max_new]
    ingested = 0; flagged = []; done = []
    # EVERY RELEASE GETS AN EXPLICIT DISPOSITION (axiom 37, ledger #109).
    # This loop used to `continue` past anything it could not use — an
    # unreadable PDF and an irrelevant one were both silently dropped, with no
    # record and no flag, so four current salmon announcements (Lower Cook
    # Inlet, Sand Point #26, Kodiak #45, a Norton Sound closure) sat outside
    # the app for days while every gate passed. Nothing is dropped in silence
    # any more: each id ends the cycle with a reason attached, and anything
    # salmon-related that did not make it is SURFACED to the captain.
    disp = {}
    for rid in todo:
        try:
            if offline_listing is not None:
                path = os.path.join(pdf_dir, rid + ".pdf")
                if not os.path.exists(path):
                    disp[rid] = {"disposition": "no-local-pdf"}
                    continue
            else:
                path = download_pdf(rid, pdf_dir)
            text = parse_pdf_text(path)
            # AN UNREADABLE ANNOUNCEMENT IS NOT AN IRRELEVANT ONE (axiom 37).
            # Empty extracted text used to fall through the "salmon" test and
            # vanish, so a scanned or image-only PDF looked exactly like a sea
            # cucumber notice. It is now flagged and surfaced, because a
            # release we cannot read may be the opening a captain needs.
            if len((text or "").strip()) < 200:
                disp[rid] = {"disposition": "unreadable", "chars": len((text or "").strip())}
                flagged.append({"id": rid, "why": ["could not read the PDF text"],
                                "surface": True})
                log(f"  UNREADABLE {rid}: {len((text or '').strip())} chars of text")
                continue
            # only commercial salmon advisories carry openings; skip the rest
            if "salmon" not in text.lower():
                disp[rid] = {"disposition": "not-salmon"}
                continue
            from extract import parse as se_parse
            import openparse
            region = openparse.detect_region(text)
            if region == "SE":
                rec = se_parse(text, rid)
                with open(os.path.join(raw_dir, rid + ".json"), "w", encoding="utf-8") as f:
                    json.dump(rec, f, ensure_ascii=False, indent=1)
                ingested += 1; done.append(rid)
                # PLACED NOTHING = ABSENT FROM THE CHART (axiom 38, ledger
                # #110). "Ingested" used to be declared on the strength of a
                # file being written, so a salmon release that parsed to ZERO
                # rules counted as handled while nothing about it ever reached
                # the chart or the captain. A release that placed nothing is
                # surfaced exactly like one we could not read, because to the
                # captain the two are the same thing: the announcement is not
                # on the map.
                # "placed nothing" for a Southeast release means no area names
                # a unit, states a region-wide status, marks a hatchery pocket
                # or draws a line — NOT merely "carries no coordinates"
                # (ledger #112: 1828817395 opens twelve Yakutat rivers by name).
                _placed = any((a.get("section") or a.get("district")
                               or a.get("region_wide") or a.get("tha_pocket")
                               or (a.get("rules") or []))
                              for a in (rec.get("areas") or []))
                if not _placed:
                    why = openparse.classify_zero_yield(text)
                    disp[rid] = {"disposition": why or "no-units",
                                 "region": "SE", "published": rec.get("published"),
                                 "why": rec.get("_unparsed") or ["parsed to no closure lines"],
                                 "title": _headline(text)}
                    if not why:
                        flagged.append({"id": rid, "surface": True,
                                        "why": ["salmon announcement that placed nothing on the chart"]})
                        log(f"  NO-UNITS SE {rid}: parsed, but nothing placed")
                    else:
                        log(f"  {why.upper()} SE {rid}: zero placements, and correctly so")
                elif rec.get("_unparsed"):
                    disp[rid] = {"disposition": "ingested", "unparsed": rec["_unparsed"]}
                    flagged.append({"id": rid, "why": rec["_unparsed"]})
                log(f"  ingested SE {rid}: {len(rec['areas'][0]['rules'])} rules"
                    + (f"  [FLAGGED: {rec['_unparsed']}]" if rec.get("_unparsed") else ""))
            elif region:                              # a non-SE management area
                rec = openparse.parse(text, rid)
                with open(os.path.join(areas_dir, rid + ".json"), "w", encoding="utf-8") as f:
                    json.dump(rec, f, ensure_ascii=False, indent=1)
                ingested += 1; done.append(rid)
                # same rule as SE above (axiom 38): zero placed units means the
                # announcement is not on the chart, however cleanly it parsed.
                if not rec.get("units"):
                    # A ZERO YIELD IS NOT ALWAYS A MISS (ledger #113): a
                    # subsistence schedule and a kelp notice are CORRECTLY
                    # absent from a commercial salmon chart, and surfacing them
                    # beside a real miss turns the warning bar into wallpaper.
                    why = openparse.classify_zero_yield(text)
                    disp[rid] = {"disposition": why or "no-units", "region": region,
                                 "published": rec.get("published"),
                                 "why": rec.get("_unparsed") or ["parsed to no named units"],
                                 "title": _headline(text)}
                    if not why:
                        flagged.append({"id": rid, "surface": True,
                                        "why": ["salmon announcement that placed nothing on the chart"]})
                        log(f"  NO-UNITS {region} {rid}: parsed, but zero units placed")
                    else:
                        log(f"  {why.upper()} {region} {rid}: zero units, and correctly so")
                elif rec.get("_unparsed"):
                    disp[rid] = {"disposition": "ingested", "unparsed": rec["_unparsed"]}
                    flagged.append({"id": rid, "why": rec["_unparsed"]})
                log(f"  ingested {region} {rid}: {len(rec['units'])} units"
                    + (f"  [FLAGGED: {rec['_unparsed']}]" if rec.get("_unparsed") else ""))
            else:
                # SALMON, BUT WE COULD NOT PLACE IT (axiom 37): never silent.
                disp[rid] = {"disposition": "unplaceable",
                             "title": (text or "")[:120].replace("\n", " ").strip()}
                flagged.append({"id": rid,
                                "why": ["salmon announcement we could not place in a management area"],
                                "surface": True})
                log(f"  UNPLACEABLE {rid}: salmon text, no region matched")
        except Exception as e:                       # one bad release never stops the cycle
            disp[rid] = {"disposition": "error", "why": str(e)[:200]}
            flagged.append({"id": rid, "why": [f"fetch/parse error: {e}"], "surface": True})
            log(f"  skipped {rid}: {e}")
    for rid in done:
        # setdefault, never assign: a no-units or unparsed record set above is
        # the truth about that release and must survive this backfill.
        disp.setdefault(rid, {"disposition": "ingested"})
    # persist the ledger beside the data so it can be audited without me
    try:
        led_path = os.path.join(data_dir, "dispositions.json")
        prev = {}
        if os.path.exists(led_path):
            with open(led_path, encoding="utf-8") as f:
                prev = (json.load(f) or {}).get("releases", {})
        prev.update(disp)
        tmp = led_path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"checked_at": started, "listed": len(listed),
                       "releases": prev}, f, indent=1)
        os.replace(tmp, led_path)
    except Exception as e:
        log(f"  disposition ledger not written: {e}")
    return {"ok": True, "checked_at": started, "new": len(todo),
            "ingested": ingested, "flagged": flagged, "ids": done,
            "dispositions": disp}


# --------------------------------------------------------------- self-test
if __name__ == "__main__":
    import glob, tempfile, shutil

    # 1) id parsing from a listing that mixes the real link forms + RSS
    sample = """
    <a href="/static/applications/dcfnewsrelease/1766166725.pdf">Thomas Bay THA</a>
    <a href="index.cfm?adfg=cfnews.detail&id=1766843682">Anita Bay THA</a>
    <item><guid>https://www.adfg.alaska.gov/...cfnewsrelease.1767031834</guid></item>
    <a href="/static/applications/dcfnewsrelease/1766166725.pdf">dup should collapse</a>
    """
    ids = list_release_ids(sample)
    assert ids == ["1766166725", "1766843682", "1767031834"], ids

    # 2) new-id detection against a raw dir that already has one
    tmp = tempfile.mkdtemp()
    try:
        rawd = os.path.join(tmp, "raw"); os.makedirs(rawd)
        open(os.path.join(rawd, "1766166725.json"), "w").write("{}")
        assert new_ids(sample, rawd) == ["1766843682", "1767031834"]

        # 3) full offline ingest cycle against the 30 bundled ground-truth PDFs,
        #    driven by a synthetic listing — proves detect->pdfminer->extract->raw
        base = os.path.dirname(__file__)
        pdfsrc = os.path.join(base, "..", "eo_pdfs")
        if glob.glob(os.path.join(pdfsrc, "*.pdf")):
            data_dir = os.path.join(tmp, "data")
            os.makedirs(os.path.join(data_dir, "eo_pdfs"))
            for p in glob.glob(os.path.join(pdfsrc, "*.pdf")):
                shutil.copy(p, os.path.join(data_dir, "eo_pdfs", os.path.basename(p)))
            listing = " ".join(
                f'dcfnewsrelease/{os.path.basename(p)[:-4]}.pdf'
                for p in glob.glob(os.path.join(pdfsrc, "*.pdf")))
            res = run(data_dir, offline_listing=listing, log=lambda *a: None)
            assert res["ok"] and res["ingested"] >= 25, res
            # every ingested raw file re-reads as valid JSON with the right id
            for rid in res["ids"]:
                rec = json.load(open(os.path.join(data_dir, "raw", rid + ".json"), encoding="utf-8"))
                assert rec["release_id"] == rid
            print(f"fetch_detect self-test: PASS")
            print(f"  offline cycle ingested {res['ingested']} SE releases; "
                  f"{len(res['flagged'])} flagged for review")
        else:
            print("fetch_detect self-test: PASS (id-parse + detect; no PDFs bundled here)")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
