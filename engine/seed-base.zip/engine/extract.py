"""EO announcement text -> structured raw JSON (phase-2 parse core).

Turns the pdftotext output of an ADF&G Commercial Fisheries advisory
announcement into the same structure `build_data.py` consumes (raw/{id}.json).

Design (unchanged in spirit, rebuilt for recall):
  * Deterministic and conservative. Every coordinate it emits is copied
    byte-for-byte from the announcement's own digits — it never rounds,
    reformats, or infers a number. A closure it cannot parse with confidence
    is flagged into `_unparsed`, never guessed. A wrong opening is worse than a
    flagged one, so precision is the hard constraint and recall is the grind.

How it reads an order (the ADF&G templated grammar):
  Each closure/opening is a clause of the form
      "<Subject>: will be (open|closed) <side> [of a line from <coords...>]
                                              [of the latitude/longitude of <name> at <coord>]
                                              [within <n> nmi of <shore>] ..."
  plus the THA-definition form "The <Name> THA are those waters ... of a line
  from <coords...> with the following restrictions:".

  The parser segments the flattened text at every "<Subject>: will be
  <status>" boundary, so each clause owns exactly its own coordinates, then
  classifies each clause's geometry from its own wording and copies its
  coordinates. Status comes straight from the explicit open/closed word.

Pure stdlib.
"""
import re, datetime as dt

DEG = r"[°º˚]"
MIN = r"[′'’´]"

# A LAT token and a LON token, captured with their raw digit text preserved.
_LATRE = r"\d{1,3}\s*" + DEG + r"\s*\d{1,2}(?:\.\d+)?\s*" + MIN + r"?\s*[NS]"
_LONRE = r"\d{1,3}\s*" + DEG + r"\s*\d{1,2}(?:\.\d+)?\s*" + MIN + r"?\s*[EW]"

# A PAIR = a latitude directly followed by a longitude (only an optional
# "lat[.,]" and comma between them). The tight coupling is what keeps a
# lat-only cutoff from stealing the longitude of an unrelated later clause.
PAIR = re.compile(
    r"(" + _LATRE + r")\s*(?:lat[.,]?)?\s*,?\s*(" + _LONRE + r")", re.I)
# A bare latitude / longitude token, for single-coordinate cutoffs.
LATONLY = re.compile(r"(" + _LATRE + r")\s*(?:lat)?", re.I)
LONONLY = re.compile(r"(" + _LONRE + r")\s*(?:long)?", re.I)

MONTHS = {m.lower(): i for i, m in enumerate(
    ["January", "February", "March", "April", "May", "June", "July", "August",
     "September", "October", "November", "December"], 1)}
GEARMAP = [("purse seine", "purse seine"), ("drift gillnet", "drift gillnet"),
           ("set gillnet", "set gillnet"), ("gillnet", "drift gillnet"),
           ("troll", "troll"), ("seine", "purse seine")]


def _norm(t):
    return re.sub(r"[ \t]+", " ", t)


def _clean(s):
    return _norm(s).strip()


def _published(t):
    m = re.search(r"For Immediate Release:\s*([A-Za-z]+)\s+(\d{1,2}),\s*(\d{4})", t)
    if m:
        mo = MONTHS.get(m.group(1).lower())
        if mo:
            return f"{int(m.group(3)):04d}-{mo:02d}-{int(m.group(2)):02d}T00:00"
    return None


def _gears(t):
    tl = t.lower(); found = []
    for k, v in GEARMAP:
        if k in tl and v not in found:
            found.append(v)
    return found or None


# --------------------------------------------------------------- coordinate copy
def _pairs(body):
    """Every tight lat+lon pair in a clause body, each with the anchor name that
    precedes it (best-effort). Coordinates are copied verbatim."""
    pts = []
    for m in PAIR.finditer(body):
        pre = body[:m.start()]
        # anchor name = the last "<name> at" or "to <name>" before the pair
        nm = None
        am = re.search(r"(?:from|to|of)\s+([A-Za-z][A-Za-z .'\-]{2,50}?)\s+(?:at\s*)?$", pre)
        if not am:
            am = re.search(r"([A-Za-z][A-Za-z .'\-]{2,50}?)\s+at\s*$", pre)
        if am:
            nm = _clean(am.group(1)).strip(" ,;")
        pts.append({"name": (nm[-60:] if nm else None),
                    "lat_dm": _clean(m.group(1)), "lon_dm": _clean(m.group(2))})
    return pts


def _single(body):
    """A single-coordinate cutoff: a bare latitude OR longitude with no pair.
    Returns (kind, point) or (None, None). Only used when no pair is present."""
    # strip any paired coordinates out first so a pair never reads as a single
    stripped = PAIR.sub(" ", body)
    lm = LATONLY.search(stripped)
    om = LONONLY.search(stripped)
    if lm and not om:
        return "lat_cutoff", {"name": None, "lat_dm": _clean(lm.group(1)), "lon_dm": None}
    if om and not lm:
        return "lon_cutoff", {"name": None, "lat_dm": None, "lon_dm": _clean(om.group(1))}
    return None, None


_SIDE = re.compile(r"^\s*((?:north|south|east|west)(?:\s+and\s+(?:north|south|east|west))?)\b", re.I)


def _classify(subject, status, body):
    """Turn one clause body into a rule dict, copying coordinates verbatim.
    The clause body's own text rides along (truncated) so the time model can
    read the clause's dates — a rule without its words has no window."""
    b = body
    side = None
    sm = _SIDE.search(b)
    if sm:
        side = _clean(sm.group(1)).lower()
    has_line = bool(re.search(r"\bof (?:a|the)?\s*lines?\b", b))
    pts = _pairs(b)
    rule = {"subject": subject, "status": status, "side": side,
            "text": _clean(b)[:350]}
    if pts:
        # line if one "of a line" span, polygon if the boundary chains several
        segs = len(re.findall(r"\bof (?:a|the)?\s*lines?\b", b))
        rule["geometry"] = "polygon" if (segs >= 2 or len(pts) >= 5) else "line"
        rule["points"] = pts
        return rule
    if re.search(r"within\s+[\d.]+\s*(?:nautical mile|nmi|nm)\b", b, re.I):
        rule["geometry"] = "buffer"; rule["points"] = []
        # a buffer may still carry a bounding cutoff coordinate
        k, p = _single(b)
        if p:
            rule["points"] = [p]; rule["geometry"] = "buffer"
        return rule
    k, p = _single(b)
    if p:
        rule["geometry"] = k; rule["points"] = [p]
        return rule
    if re.match(r"^\s*\.?\s*$", b) or re.search(r"will not open|not anticipated|excluded|cost.?recovery", b, re.I):
        rule["geometry"] = "whole_area"; rule["points"] = []
        return rule
    rule["geometry"] = "other"; rule["points"] = []
    return rule


# ----------------------------------------------------------------- clause finder
# A clause opens at "<Subject>: will be (open|closed)". Subjects are section
# names ("Section 1-F", "District 2") and place names ("Boca de Quadra").
_CLAUSE_START = re.compile(
    r"([A-Z][A-Za-z0-9 ,.'&/()\-]{1,70}?):\s*will\s+be\s+(open|closed)\b", re.I)

# REGION-WIDE fishery sentences — no colon, the fishery itself is the subject:
#   "The Southeast Alaska/Yakutat commercial troll fishery will close to the
#    taking of all salmon at 11:59 p.m., August 8, 2026, ... and will reopen to
#    the taking of all salmon at 12:01 a.m., August 13, 2026."
#   "The troll fishery will open for the retention of Chinook salmon at ..."
# These govern the WHOLE region for their gear, and dropping them is how a
# coastwide opening goes missing while trollers are visibly fishing it.
_REGIONWIDE = re.compile(
    r"\b((?:The\s+)?[A-Z][A-Za-z/ ]{0,60}?\b(?:troll|purse seine|drift gillnet|"
    r"set gillnet|salmon)\s+fishery)\s+will\s+"
    r"(close|be\s+closed|reopen|be\s+reopened|open|be\s+open|remain\s+open|remain\s+closed)\b",
    re.I)
_REOPEN_SPLIT = re.compile(r",?\s+and\s+will\s+(reopen|be\s+reopened|open)\b", re.I)


def _sentence_at(flat, start):
    """The sentence containing `start` (to the next '. ' + capital, bounded)."""
    end = start
    n = len(flat)
    while end < n:
        k = flat.find(". ", end)
        if k < 0:
            return flat[start:min(n, start + 600)]
        # a period inside "a.m."/"p.m."/"No." is not a sentence end
        if re.match(r"[A-Z]", flat[k + 2:k + 3] or "") and not re.search(
                r"\b(?:a\.m|p\.m|No|U\.S)\.$", flat[max(0, k - 4):k + 1]):
            return flat[start:k + 1]
        end = k + 2
    return flat[start:min(n, start + 600)]


def _regionwide_areas(flat):
    """Region-wide fishery statements -> area records (district None, section
    None, region_wide True). A close+reopen sentence yields BOTH a closed area
    and an open area, each carrying its own words for the time model."""
    out = []
    seen_spans = []
    for m in _REGIONWIDE.finditer(flat):
        if any(a <= m.start() < b for a, b in seen_spans):
            continue
        sent = _sentence_at(flat, m.start())
        seen_spans.append((m.start(), m.start() + len(sent)))
        verb = re.sub(r"\s+", " ", m.group(2).lower())
        sp = _REOPEN_SPLIT.search(sent)
        if verb in ("close", "be closed", "remain closed") and sp:
            out.append({"status": "closed", "period_text": _clean(sent[:sp.start()])[:300]})
            out.append({"status": "open", "period_text": _clean("will " + sent[sp.start():].lstrip(", ").lstrip("and ").strip())[:300]})
        elif verb in ("close", "be closed", "remain closed"):
            out.append({"status": "closed", "period_text": _clean(sent)[:300]})
        else:
            out.append({"status": "open", "period_text": _clean(sent)[:300]})
    areas = []
    for o in out:
        areas.append({"district": None, "section": None, "status": o["status"],
                      "period_text": o["period_text"], "region_wide": True, "rules": []})
    return areas


_SEC_SUBJ = re.compile(r"^Sections?\s+(.+)$", re.I)
_DIST_SUBJ = re.compile(r"^Districts?\s+(.+)$", re.I)
_SEC_TOKEN = re.compile(r"\b(\d{1,2}-[A-Z])\b")
_DIST_TOKEN = re.compile(r"\b(\d{1,2})\b")


def _areas_from_rules(rules):
    """Group parsed rules into per-unit AREAS the status mapper can place:
    'Section 15-A' clauses -> {district:'15', section:'15-A'}; 'District 8'
    clauses -> {district:'8'}; everything else -> a named catch-all area.
    Each area's period_text is its own clause's words."""
    areas = []
    misc = []
    for r in rules:
        subj = r.get("subject") or ""
        st = r.get("status")
        ptxt = (r.get("text") or "")[:300]
        m = _SEC_SUBJ.match(subj)
        if m and st in ("open", "closed"):
            toks = _SEC_TOKEN.findall(m.group(1))
            if toks:
                for t in toks:
                    areas.append({"district": t.split("-")[0], "section": t,
                                  "status": st, "period_text": ptxt, "rules": [r]})
                continue
        m = _DIST_SUBJ.match(subj)
        if m and st in ("open", "closed"):
            toks = _DIST_TOKEN.findall(m.group(1))
            if toks:
                for t in toks:
                    areas.append({"district": t, "section": None,
                                  "status": st, "period_text": ptxt, "rules": [r]})
                continue
        misc.append(r)
    if misc:
        coord = [r for r in misc if r.get("points")]
        areas.append({"district": None, "section": None,
                      "status": "partial" if coord else "open",
                      "period_text": None, "rules": misc})
    return areas
# A restriction sub-clause: "<Name>: waters ... (are|is) (closed|open) ... of a
# line from <coords>" (or the coords first, status after). Handles the "are
# closed" phrasing that "will be" clauses miss.
_RESTR = re.compile(
    r"([A-Z][A-Za-z0-9 .'&()\-]{2,55}?):\s*waters\b(.*?)"
    r"(?=(?:[A-Z][A-Za-z0-9 .'&()\-]{2,55}?:\s*(?:waters\b|will\s+be))|$)", re.S)


def _body_status(b):
    """Status word governing a restriction body: explicit and unambiguous, else
    None (which flags the clause rather than guessing)."""
    m = re.search(r"will\s+be\s+(open|closed)\b", b, re.I)
    if m:
        return m.group(1).lower()
    found = [x.lower() for x in re.findall(r"\b(?:are|is)\s+(closed|open)\b", b, re.I)]
    s = set(found)
    if len(s) == 1:
        return s.pop()
    return None
# THA-definition / open-boundary intros. Each names an OPEN area and is
# followed by "... of a line from <coords>". The span after the intro is cut
# at the first phrase that would hand it a *closed* boundary, so an open span
# can never swallow a closure (precision guard).
# A THA subject: optionally "The waters of the", the name, "THA", and an
# optional "(statistical area NNN-NN)" parenthetical.
_THA_SUBJ = r"(?:The\s+(?:waters of the\s+)?)?([A-Z][A-Za-z0-9 .'\-]{2,55}?\s+(?:Troll\s+)?THA)(?:\s*\([^)]*\))?"
_OPEN_INTROS = [
    re.compile(_THA_SUBJ + r"\s+are those waters", re.I),
    re.compile(_THA_SUBJ + r"\s+(?:consists of|is comprised of|includes)\s+(?:those |the |all |the following )?waters", re.I),
    re.compile(_THA_SUBJ + r"\s+(?:is|are)\s+described as\s+(?:follows:|the waters|those waters|waters)", re.I),
    re.compile(_THA_SUBJ + r"\s+is described as follows:", re.I),
    re.compile(_THA_SUBJ + r"\s+is defined in[^:]*?as:\s*waters", re.I),
    re.compile(r"([A-Z][A-Za-z0-9 .'&\-]{2,55}?\s*\(\d{3}-\d{2}\)):\s*waters", re.I),
]
# Trailing-status prose closure/opening with no "Subject:" header:
# "waters ... of a line from <coords> ... (will be|are|is) (open|closed)".
# Bounded so the status word stays local to these coordinates (precision guard).
_PROSE = re.compile(
    r"waters\b[^;]{0,140}?of a line from(.{0,320}?)(?:will be|are|is)\s+(open|closed)\b",
    re.I | re.S)
# Phrases that end an open span (anything past here may be a closure). The
# sentence-boundary stop (period + space + capital) keeps an open-boundary
# definition from bleeding into the next sentence, which is often a closure.
_OPEN_STOP = re.compile(
    r"with the following restriction|which includes those waters|are closed|is closed|"
    r"will be closed|regulatory marker|\(Figure|except|;\s*and the waters north|\.\s+[A-Z]")


def _clauses(flat):
    """Yield (subject, status, body) for every clause, body bounded by the next
    clause's *corrected* start so each owns only its own coordinates.

    The subject char class can begin a match inside the tail of the previous
    sentence — e.g. "…133°45.65′ W long. Section 15-A: will be open" captures the
    subject as "W long. Section 15-A", starting at "W" and cutting the previous
    clause's body mid-coordinate (dropping its trailing point). So when the head
    before a ". " looks like a coordinate/sentence tail (has a degree sign, a
    digit, or a lat/long unit), we advance the real start past that ". "."""
    items = []
    for m in _CLAUSE_START.finditer(flat):
        subj = m.group(1); status = m.group(2).lower()
        start = m.start(1); wb_end = m.end()
        k = subj.rfind(". ")
        if k != -1:
            head = subj[:k]
            if re.search(r"[°′]|\d|\b(?:lat|long)\b", head, re.I):
                start = m.start(1) + k + 2
                subj = subj[k + 2:]
        subj = re.sub(r"^(?:and|the|then|with|in|of|to|from|through)\s+", "", _clean(subj), flags=re.I)
        items.append((start, wb_end, subj, status))
    out = []
    for i, (start, wb_end, subj, status) in enumerate(items):
        end = items[i + 1][0] if i + 1 < len(items) else len(flat)
        out.append((subj, status, flat[wb_end:end], start))
    return out


def _body_text(t):
    """The announcement's readable body: page furniture and the mailing block
    stripped, wrapping undone, paragraph breaks kept. Never a re-typing — this
    is the PDF's own text, only de-hyphenated and re-flowed."""
    if not t:
        return None
    lines = [ln.rstrip() for ln in t.replace("\r", "").split("\n")]
    keep, drop = [], re.compile(
        r"^\s*(?:Page \d+|\d+\s*of\s*\d+|P\.?O\.? BOX|ADF&G|AWT\b|"
        r"Alaska Department of Fish and Game|Division of Commercial Fisheries|"
        r"www\.|http)", re.I)
    for ln in lines:
        if drop.match(ln):
            continue
        keep.append(ln)
    out, buf = [], []
    for ln in keep:
        if ln.strip():
            buf.append(ln.strip())
        elif buf:
            out.append(" ".join(buf)); buf = []
    if buf:
        out.append(" ".join(buf))
    body = "\n\n".join(out)
    body = re.sub(r"(\w)-\s+(\w)", r"\1\2", body)      # undo line-break hyphens
    body = re.sub(r"[ \t]{2,}", " ", body)
    return body.strip() or None


def parse(text, release_id=None):
    t = text.replace("\r", "")
    flat = _norm(t.replace("\n", " "))
    out = {"release_id": str(release_id) if release_id else None,
           "published": _published(t),
           "species": "salmon" if "salmon" in t.lower() else None,
           "gear": _gears(t), "_unparsed": []}

    m = (re.search(r"\bEO\s+([0-9][A-Z0-9]+)\b", flat)
         or re.search(r"Emergency Order[^.]*?\b([0-9][A-Z]\d{3,})\b", flat))
    out["emergency_order"] = m.group(1) if m else None

    m = (re.search(r"CONTACT:\s*([A-Za-z .'\-]+?)\s+[A-Z][a-z]+ Area", t)
         or re.search(r"CONTACT:\s*([A-Za-z .'\-]+)", t))
    ph = re.search(r"\((\d{3})\)\s*(\d{3})-(\d{4})", t)
    if m:
        out["contact"] = _clean(m.group(1)) + (
            f", ({ph.group(1)}) {ph.group(2)}-{ph.group(3)}" if ph else "")

    caps = re.findall(r"^\s*([A-Z0-9][A-Z0-9 ,'&()\-/]{12,})\s*$", t, re.M)
    caps = [c for c in caps if not c.strip().startswith(("PO BOX", "ADF&G", "AWT", "CONTACT"))]
    out["title"] = (_clean(" ".join(caps[:2])).title() if caps else None)

    m = re.search(r"(The next[^.]*?(?:announcement|fishery)[^.]*?\.)", flat, re.I)
    out["next_announcement"] = m.group(1).strip() if m else None

    out["region"] = "Southeast" if re.search(
        r"Juneau Area|Ketchikan|Petersburg|Sitka|Southeast", t) else None

    # THE ANNOUNCEMENT'S COMPLETE WORDS (ledger #89). Every clause this parser
    # files under a unit is a JUDGEMENT about which unit a sentence belongs to,
    # and a judgement can be wrong: District 15's "the Boat Harbor THA will
    # close for the season ... west of 135°09.57' W long" landed in the
    # unattributed bucket, so Section 15-C's sheet promised "with the following
    # restriction:" and then said nothing. The restriction a captain must obey
    # cannot depend on the parser winning an attribution. The whole body now
    # rides along, verbatim, so every sheet can show the announcement entire —
    # the parse decides what is DRAWN, never what the captain is allowed to READ.
    out["full_text"] = _body_text(t)

    rules = []
    # Open-boundary intros (THA definitions, channel-list openings). Each span
    # runs from the intro to the first closure phrase, so it holds only open
    # boundary coordinates.
    for rx in _OPEN_INTROS:
        for tm in rx.finditer(flat):
            span = flat[tm.end():tm.end() + 1600]
            stop = _OPEN_STOP.search(span)
            if stop:
                span = span[:stop.start()]
            pts = _pairs(span)
            if pts:
                segs = len(re.findall(r"\bof (?:a|the)?\s*lines?\b", span))
                subj = _clean(tm.group(1))
                if "boundary" not in subj.lower() and "THA" in subj:
                    subj = subj + " boundary"
                rules.append({"subject": subj, "status": "open", "side": None,
                              "geometry": "polygon" if segs >= 2 or len(pts) >= 5 else "line",
                              "points": pts})
    # every "will be (open|closed)" clause
    for subject, status, body, cpos in _clauses(flat):
        r = _classify(subject, status, body)
        r["_pos"] = cpos                      # document position, for window scoping
        rules.append(r)
    # restriction sub-clauses phrased "<Name>: waters ... are/is closed ..."
    for rm in _RESTR.finditer(flat):
        subj = _clean(rm.group(1))
        if re.search(r"\(\d{3}-\d{2}\)|\bTHA\b", subj):
            continue  # handled by the open-boundary intros
        body = rm.group(2)
        pts = _pairs(body)
        if not pts:
            continue
        st = _body_status(body)
        if not st:
            out["_unparsed"].append(f"ambiguous status: {subj}")
            continue
        segs = len(re.findall(r"\bof (?:a|the)?\s*lines?\b", body))
        rules.append({"subject": subj, "status": st, "side": None,
                      "geometry": "polygon" if segs >= 2 or len(pts) >= 5 else "line",
                      "points": pts})
    # trailing-status prose closures/openings ("... of a line from X to Y will be
    # closed"). This is the loosest pass, so it may only ADD coordinates the
    # authoritative passes above did not already place — it can never relabel a
    # coordinate the intros/clauses already resolved (precision guard).
    def _ckey(pt):
        return (tuple(re.findall(r"\d+\.?\d*", pt.get("lat_dm") or "")),
                tuple(re.findall(r"\d+\.?\d*", pt.get("lon_dm") or "")))
    emitted = set()
    for r in rules:
        for pt in r.get("points", []):
            k = _ckey(pt)
            if k[0] and k[1]:
                emitted.add(k)
    for pm in _PROSE.finditer(flat):
        span = "of a line from" + pm.group(1)
        pts = [p for p in _pairs(span) if not (_ckey(p)[0] and _ckey(p)[1] and _ckey(p) in emitted)]
        if not pts:
            continue
        st = pm.group(2).lower()
        segs = len(re.findall(r"\bof (?:a|the)?\s*lines?\b", span))
        rules.append({"subject": "prose boundary", "status": st, "side": None,
                      "geometry": "polygon" if segs >= 2 or len(pts) >= 5 else "line",
                      "points": pts})
        for p in pts:
            emitted.add(_ckey(p))

    # named-line definitions: "The <Name> line is described as <coords>", whose
    # open/closed status is stated elsewhere as "<side> of the <Name> line".
    for dm in re.finditer(r"[Tt]he\s+([A-Z][A-Za-z0-9\- ]{2,40}?)\s+line\s+is described as\s+(.+?)(?=\.\s+[A-Z]|$)", flat):
        name = _clean(dm.group(1)); span = dm.group(2)
        pts = [p for p in _pairs(span) if not (_ckey(p) in emitted)]
        if not pts:
            continue
        # governing status: "will close/open … <side> of the <Name> line" or
        # "closed/open <side> of the <Name> line"
        esc = re.escape(name)
        sm = re.search(r"\b(clos|open)[a-z]*\b[^.]{0,80}?\bof the\s+" + esc + r"\s+line", flat, re.I) \
            or re.search(r"\b(?:north|south|east|west)[a-z ]*?\bof the\s+" + esc + r"\s+line", flat, re.I)
        if not sm:
            out["_unparsed"].append(f"named line without a clear status: {name}")
            continue
        st = "closed" if re.search(r"\bclos", sm.group(0), re.I) or "clos" in flat[max(0, sm.start()-40):sm.start()].lower() else \
             ("open" if re.search(r"\bopen", sm.group(0), re.I) else None)
        if st is None:
            # look just before the side phrase for the verb
            pre = flat[max(0, sm.start()-60):sm.start()].lower()
            st = "closed" if "clos" in pre else ("open" if "open" in pre else None)
        if st is None:
            out["_unparsed"].append(f"named line without a clear status: {name}")
            continue
        segs = len(re.findall(r"\bto\b", span))
        rules.append({"subject": name + " line", "status": st, "side": None,
                      "geometry": "line", "points": pts})
        for p in pts:
            emitted.add(_ckey(p))

    # de-duplicate identical (subject,status,first-point) rules that a doubled
    # PDF layout can produce
    seen = set(); dedup = []
    for r in rules:
        key = (r["subject"], r["status"], r.get("geometry"),
               tuple((p.get("lat_dm"), p.get("lon_dm")) for p in r.get("points", [])))
        if key in seen:
            continue
        seen.add(key); dedup.append(r)
    rules = dedup

    # ---- area-level emission: what the status mapper actually places --------
    # per-unit areas from the clause subjects, plus region-wide fishery
    # statements ("The ... troll fishery will close ... and will reopen ...").
    out["areas"] = _regionwide_areas(flat) + _areas_from_rules(rules)
    # TERMINAL HARVEST AREA fishery sentences (client-caught, ledger #70): "the
    # Deep Inlet Terminal Harvest Area will close to all common property
    # commercial salmon fisheries effective 12:01 a.m., Monday, August 31" — a
    # POCKET statement with no section named, in a form neither the clause nor
    # the region-wide grammar matched, so a real closure in Sitka Sound parsed
    # to nothing. Emitted as a THA-scoped area carrying its own sentence;
    # restatus surfaces it as a named advisory note (words, never sections
    # painted — the surrounding fishery is unaffected by a pocket closure).
    for tm2 in re.finditer(
            r"[Tt]he\s+([A-Z][A-Za-z' ]{2,40}?)\s+(?:Terminal Harvest Area|THA)"
            r"(?:\s*\([A-Z]{2,5}\))?\s+will\s+(close|be\s+closed|reopen|be\s+reopened|open|be\s+open)\b", flat):
        sent = _sentence_at(flat, tm2.start())
        verb = re.sub(r"\s+", " ", tm2.group(2).lower())
        st = "closed" if "close" in verb else "open"
        out["areas"].append({"district": None, "section": None, "status": st,
                             "period_text": _clean(sent)[:350], "region_wide": False,
                             "tha_pocket": _clean(tm2.group(1)), "rules": []})
    # LIST-HEADER WINDOW INHERITANCE (client-caught, ledger #69): ADF&G's
    # coordinated openers put the time in a header sentence ("The following
    # areas will be open to purse seining from 6:00 a.m., Sunday, August 30,
    # through 9:00 p.m., Monday, August 31, 2026:") and each section's own
    # clause carries only its restrictions. Without inheriting that window a
    # section shows no opening time — no "opens in 18 h" for the captain
    # positioning, and no expiry after the period ends. The header's OWN words
    # are prepended (verbatim, same announcement) ONLY when every header
    # window in the release parses to the SAME period — differing windows stay
    # un-inherited rather than guessed onto the wrong section.
    _hdrs = [(hm.start(), hm.group(1).strip()) for hm in re.finditer(
        r"will (?:be )?open to [a-z ]{3,30}ing\s+(from\s+.{5,160}?20\d\d)[,.:\s]", flat)]
    if _hdrs:
        try:
            from timemodel import parse_period
            pubyear = int((out.get("published") or "2026")[:4])
            # subject -> the last header window PRECEDING that subject's clause
            # (ADF&G's list form: a district's window sentence, then its
            # sections). A clause before any header inherits nothing.
            _win_by_subj = {}
            for r in rules:
                if "_pos" not in r:
                    continue
                prior = [h for h in _hdrs if h[0] < r["_pos"]]
                if prior:
                    _win_by_subj[(r.get("subject") or "").strip().lower()] = prior[-1][1]
            _timepat = re.compile(
                r"\d{1,2}:\d{2}|(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d")
            for a in out["areas"]:
                pt = a.get("period_text") or ""
                if a.get("status") not in ("open", "partial") or _timepat.search(pt):
                    continue
                subj = None
                if a.get("section"):
                    subj = "section " + str(a["section"])
                elif a.get("district") is not None:
                    subj = "district " + str(a["district"])
                h = _win_by_subj.get((subj or "").lower())
                if h and parse_period(h, pubyear, out.get("published"))[0]:
                    a["period_text"] = ("open " + h + ("; " + pt.lstrip(" .:;") if pt.strip(" .:;") else "")).strip()[:400]
        except Exception:
            pass                                      # inheritance is best-effort, never fatal
    for r in rules:
        r.pop("_pos", None)
    coord_rules = [r for r in rules if r.get("points")]
    if not coord_rules and not any(a.get("region_wide") for a in out["areas"]):
        out["_unparsed"].append("no coordinate rules parsed")
    return out


# --------------------------------------------------------------------- validator
if __name__ == "__main__":
    import json, glob, os
    txtdir = os.path.join(os.path.dirname(__file__), "..", "eo_text")
    rawdir = os.path.join(os.path.dirname(__file__), "..", "..", "adfg", "raw")

    def nums(x):
        return tuple(re.findall(r"\d+\.?\d*", x or ""))

    def rulekeys(area_list):
        """Metric keys = (status, (lat-nums, lon-nums)) for every PAIRED point
        (both coordinates present) — the ones that place a real line on the map."""
        ks = set()
        for a in area_list:
            for r in a.get("rules", []):
                for pt in r.get("points", []):
                    k = (nums(pt.get("lat_dm")), nums(pt.get("lon_dm")))
                    if k[0] and k[1]:
                        ks.add((r.get("status"), k))
        return ks

    TP = FP = FN = 0; files = 0; eo_ok = 0; worst = []
    for tf in sorted(glob.glob(os.path.join(txtdir, "*.txt"))):
        rid = os.path.basename(tf)[:-4]; rawp = os.path.join(rawdir, rid + ".json")
        if not os.path.exists(rawp):
            continue
        files += 1
        gt = json.load(open(rawp)); ex = parse(open(tf, encoding="utf-8").read(), rid)
        if ex.get("emergency_order") == gt.get("emergency_order"):
            eo_ok += 1
        g = rulekeys(gt.get("areas", [])); e = rulekeys(ex.get("areas", []))
        tp = len(g & e); fp = len(e - g); fn = len(g - e)
        TP += tp; FP += fp; FN += fn
        if fp or fn:
            worst.append((fp, fn, rid))
    prec = TP / (TP + FP) if TP + FP else 0
    rec = TP / (TP + FN) if TP + FN else 0
    print(f"files={files}  EO ok={eo_ok}/{files}")
    print(f"coordinate-closure rules — precision={prec:.3f} recall={rec:.3f}  (TP={TP} FP={FP} FN={FN})")
    for fp, fn, rid in sorted(worst, reverse=True)[:8]:
        print(f"   {rid}: FP={fp} FN={fn}")
