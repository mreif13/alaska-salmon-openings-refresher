"""Anticipatory poll scheduler for the SE openings app (phase 2).

Decides WHEN to next fetch ADF&G Commercial Fisheries announcements, so the app
pulls right after an order posts instead of on a blind timer. Priority:
  1) explicit "next announcement" date stated in an EO's own text (strongest);
  2) per-office empirical cadence (modal weekday/hour) learned from history;
  3) a safety floor so we never go longer than max_gap without a check.
Pure stdlib. Mirrors the tracker's discipline: deterministic + self-tested.
"""
import re, datetime as dt
from collections import defaultdict, Counter

WEEKDAYS = {d:i for i,d in enumerate(
    ["monday","tuesday","wednesday","thursday","friday","saturday","sunday"])}
MONTHS = {m:i for i,m in enumerate(
    ["january","february","march","april","may","june","july","august",
     "september","october","november","december"],1)}
GEARS = ["seine","gillnet","troll","salmon"]  # 'salmon' = general/all-gear

def parse_next_announcements(text, published_year):
    """Extract (gear, datetime) targets stated in an EO's text.
    Handles 'The next <gear> announcement will be issued on <Weekday>, <Month> <day>[, <year>]'
    and '... anticipated to be released by <h:mm am/pm> on <Weekday>, <Month> <day>'."""
    out=[]
    if not text: return out
    t=re.sub(r"\s+"," ",text)
    pat=re.compile(
      r"next (?:scheduled )?(seine|gillnet|drift gillnet|troll|salmon|commercial salmon)[^.]*?"
      r"(?:issued|released|broadcast)[^.]*?"
      r"(?:by (\d{1,2}:\d{2}\s*[ap]\.?m\.?) )?on "
      r"(?:monday|tuesday|wednesday|thursday|friday|saturday|sunday),?\s*"
      r"([a-z]+)\s+(\d{1,2})(?:,?\s*(\d{4}))?", re.I)
    for m in pat.finditer(t):
        gear=m.group(1).lower().replace("drift ","").replace("commercial ","")
        tm=m.group(2); mon=MONTHS.get(m.group(3).lower()); day=int(m.group(4))
        yr=int(m.group(5)) if m.group(5) else published_year
        if not mon: continue
        hh,mm=12,0
        if tm:
            mt=re.match(r"(\d{1,2}):(\d{2})\s*([ap])",tm.lower())
            if mt:
                hh=int(mt.group(1))%12 + (12 if mt.group(3)=="p" else 0); mm=int(mt.group(2))
        try: out.append((gear, dt.datetime(yr,mon,day,hh,mm)))
        except ValueError: pass
    return out

def office_cadence(releases):
    """Learn each office's modal posting weekday(s)+hour from history."""
    byoff=defaultdict(list)
    for r in releases:
        p=r.get("published"); o=r.get("office")
        if not p: continue
        try: byoff[o].append(dt.datetime.fromisoformat(p))
        except ValueError: pass
    cad={}
    for o,ds in byoff.items():
        if not ds: continue
        dows=Counter(d.weekday() for d in ds)
        hrs=[d.hour for d in ds if d.hour]
        cad[o]={"weekdays":[wd for wd,_ in dows.most_common(3)],
                "hour": (sorted(hrs)[len(hrs)//2] if hrs else 12), "n":len(ds)}
    return cad

def _next_weekday(now, wd, hour):
    days=(wd - now.weekday()) % 7
    cand=(now+dt.timedelta(days=days)).replace(hour=hour,minute=0,second=0,microsecond=0)
    if cand<=now: cand+=dt.timedelta(days=7)
    return cand

def next_poll_times(releases, now=None, max_gap_hours=24, lead_minutes=20):
    """Return sorted upcoming poll datetimes. Explicit EO dates (poll lead_minutes
    after the stated time) win; office cadence fills gaps; a max_gap floor guarantees
    we never wait longer than max_gap_hours."""
    now = now or dt.datetime.now()
    polls=set()
    for r in releases:
        yr=dt.datetime.fromisoformat(r["published"]).year if r.get("published") else now.year
        for gear,when in parse_next_announcements(r.get("next_announcement") or "", yr):
            if when>now-dt.timedelta(hours=1):
                polls.add(when+dt.timedelta(minutes=lead_minutes))
    for o,c in office_cadence(releases).items():
        for wd in c["weekdays"]:
            polls.add(_next_weekday(now, wd, c["hour"])+dt.timedelta(minutes=lead_minutes))
    floor=now+dt.timedelta(hours=max_gap_hours)
    polls={p for p in polls if p>now}
    if not polls or min(polls)>floor: polls.add(floor)
    return sorted(polls)

def next_poll(releases, now=None, **kw):
    ts=next_poll_times(releases, now=now, **kw)
    return ts[0] if ts else (now or dt.datetime.now())+dt.timedelta(hours=kw.get("max_gap_hours",24))

# ---- self-test ----
if __name__=="__main__":
    import json,sys,os
    ad=json.load(open(os.path.join(os.path.dirname(__file__),"..","..","adfg","app_data.json")))
    rel=ad["releases"]; now=dt.datetime(2026,8,23,12,0)
    # 1 explicit parse
    found=[]
    for r in rel:
        found+=parse_next_announcements(r.get("next_announcement") or "", 2026)
    assert any(g=="seine" for g,_ in found), "should parse a seine next-date"
    assert any(w.month==8 for _,w in found)
    # 2 cadence
    cad=office_cadence(rel); assert "Southeast" in cad and cad["Southeast"]["n"]>=20
    assert 2 in cad["Southeast"]["weekdays"]  # Wednesday is modal
    # 3 schedule sane + bounded
    ts=next_poll_times(rel, now=now)
    assert ts and all(t>now for t in ts)
    assert (ts[0]-now)<=dt.timedelta(hours=24)
    print("scheduler self-test: PASS")
    print("  parsed explicit next-announcements:",len(found))
    print("  Southeast cadence:",cad["Southeast"])
    print("  next 5 anticipated polls from",now,":")
    for t in ts[:5]: print("    ",t)
