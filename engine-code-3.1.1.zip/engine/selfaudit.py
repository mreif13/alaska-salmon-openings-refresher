#!/usr/bin/env python3
"""SELF-AUDIT — the app checks its own statements against its own records, and
repairs what it can, on its own schedule.

WHY THIS EXISTS
---------------
`doctor.py` repairs DAMAGE: a truncated page, a corrupt record, a crash loop.
It answers "are my files intact?" It cannot answer the question that has
actually cost this project: **"is what I am telling the captain true?"**

Ledger #110: four salmon announcements were read, parsed, written to disk and
counted `ingested` while placing NOTHING on the chart. Every file was intact.
The doctor was content. Eighteen build-time gates would have caught it — but
gates run when someone runs them, and the app on a fisherman's machine rebuilds
itself every two hours with nobody watching. Ledger #111 built `claimcheck.py`
so *I* cannot state something the artifacts contradict; this is the same
discipline turned inward and made autonomous, so the APP cannot either.

WHAT IT IS
----------
A short list of CONTRADICTIONS — places where two things the app already knows
disagree — each with a repair where a repair exists. It runs after every
refresh, at boot, and on demand. What it fixes, it fixes silently. What it
cannot fix, it says out loud on the page, because an app that knows it is
wrong and stays quiet is worse than one that never checked.

    C1  a release placed nothing, and nothing says so           (axiom 38)
    C2  the page's "not on this chart" list disagrees with the ledger (axiom 37)
    C3  the page was built by a different engine than the one serving it (axiom 33)
    C4  a displayed status disagrees with the clock             (axiom 36)
    C5  the authority listed a release we have no disposition for (axiom 37)
    C6  the page is older than the newest announcement it holds (axiom 36)

Pure stdlib. Never raises: an audit that can crash the refresh is a liability,
not a safety net.
"""

import datetime as dt
import glob
import json
import os
import re

AUDIT_FILE = "selfaudit.json"


# ------------------------------------------------------------------ Alaska now
class _AlaskaTZ(dt.tzinfo):
    """Self-contained America/Anchorage — the same fallback the pipeline uses,
    because Windows has no system tz database and a status is judged on the
    fishery's clock, not the machine's (ledger #52)."""
    def _dst_on(self, d):
        y = d.year
        mar = dt.datetime(y, 3, 8); mar += dt.timedelta(days=(6 - mar.weekday()) % 7)
        nov = dt.datetime(y, 11, 1); nov += dt.timedelta(days=(6 - nov.weekday()) % 7)
        return mar.replace(hour=2) <= d.replace(tzinfo=None) < nov.replace(hour=2)
    def utcoffset(self, d): return dt.timedelta(hours=-8 if self._dst_on(d) else -9)
    def dst(self, d): return dt.timedelta(hours=1) if self._dst_on(d) else dt.timedelta(0)
    def tzname(self, d): return "AKDT" if self._dst_on(d) else "AKST"


def alaska_now():
    try:
        from zoneinfo import ZoneInfo
        return dt.datetime.now(ZoneInfo("America/Anchorage")).replace(tzinfo=None, microsecond=0)
    except Exception:
        return dt.datetime.now(_AlaskaTZ()).replace(tzinfo=None, microsecond=0)


# --------------------------------------------------------------------- helpers
def _jload(path, default=None):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def _c(cid, what, detail, repair=None, surface=True):
    """One contradiction. `repair` is the token the repair pass understands;
    `surface` says whether the captain must be told if it survives repair."""
    return {"id": cid, "what": what, "detail": detail[:400],
            "repair": repair, "repaired": False, "surface": surface}


SURFACED = ("unreadable", "unplaceable", "error", "no-units")
# every disposition that EXPLAINS a zero yield. C1 used to accept only
# "no-units", so the moment c1_reclassify wrote "subsistence-only" the other
# check flagged it again — two repairs rewriting each other every cycle, and
# seven contradictions "open" forever on the client's machine (ledger #116).
EXPLAINED_ZERO = ("no-units", "subsistence-only", "not-salmon")


# ------------------------------------------------------------------ invariants
def _is_announcement(rid):
    """Only ADF&G RELEASES are announcements.

    `raw/` also holds the regulation-derived geometry records (`se_reg_d1_d2`,
    `kodiak_regulations`, `se_tha_regulations` …). They carry no closure lines
    by their nature, and the first cut of this check flagged all ten of them as
    "announcements not on the chart" — thirteen false repairs and a banner full
    of nonsense in front of a captain. A guard that cries wolf is worse than no
    guard, because it gets switched off. An announcement id is numeric.
    """
    return str(rid).isdigit()


def _se_placed(rec):
    """Did a Southeast release place ANYTHING?

    NOT the same question as "does it carry coordinate lines" — that was the
    first cut, and it was simply wrong: release 1828817395 opens twelve Yakutat
    rivers by NAME with no coordinates at all, and would have been declared
    absent from a chart it is all over. A release has placed something if any
    of its areas names a unit, states a region-wide status, marks a hatchery
    pocket, or draws a line.
    """
    for a in (rec.get("areas") or []):
        if (a.get("section") or a.get("district") or a.get("region_wide")
                or a.get("tha_pocket") or (a.get("rules") or [])):
            return True
    return False


def c1_reclassify(data, led):
    """A VERDICT WRITTEN BY AN OLDER VERSION OF THIS CHECK IS NOT SACRED
    (ledger #115). The first self-audit filed every zero-yield release as
    `no-units` before the classifier existed; the classifier then arrived and
    never looked back, because C1 only examines records whose disposition is
    NOT already `no-units`. Six Yukon subsistence schedules and a kelp notice
    therefore stayed on the client's warning bar as "missing" — filed by the
    app, protected by the app. The repair must revisit its own conclusions.
    """
    out = []
    rel = (led or {}).get("releases") or {}
    for rid, v in rel.items():
        if (v or {}).get("disposition") != "no-units" or not _is_announcement(rid):
            continue
        why = _why_zero(data, rid)
        if why:
            out.append(_c("C1", "a release filed as missing is correctly absent",
                          f"{rid} is filed 'no-units' but its own words say "
                          f"{why!r}", repair="mark-no-units:" + rid, surface=False))
    return out


def c1_placed_nothing(data, led):
    """A RELEASE THAT PLACED NOTHING MUST SAY SO (axiom 38, ledger #110).

    This is the exact defect that reached the client. A release is held, its
    file is perfect, its disposition reads `ingested` — and not one word of it
    is on the chart. Held and absent at the same time, with nothing anywhere
    recording the second half.
    """
    out = []
    rel = (led or {}).get("releases") or {}
    for p in sorted(glob.glob(os.path.join(data, "areas", "*.json"))):
        rid = os.path.basename(p)[:-5]
        if not _is_announcement(rid):
            continue
        rec = _jload(p, {}) or {}
        if rec.get("units"):
            continue
        d = (rel.get(rid) or {}).get("disposition")
        if d not in EXPLAINED_ZERO:
            out.append(_c("C1", "a release placed nothing and nothing says so",
                          f"{rid} ({rec.get('region')}) holds 0 units but its "
                          f"disposition reads {d!r}", repair="mark-no-units:" + rid))
    for p in sorted(glob.glob(os.path.join(data, "raw", "*.json"))):
        rid = os.path.basename(p)[:-5]
        if not _is_announcement(rid):
            continue
        rec = _jload(p, {}) or {}
        # a record filed in the Southeast pipeline whose own region is another
        # area reaches no chart however many units it names (ledger #264, B)
        _reg = str(rec.get("region") or "").lower()
        _se = (not _reg) or any(w in _reg for w in ("southeast", "district 1", "lynn canal", "haines",
                                                    "chatham", "icy strait", "clarence"))
        if _se and _se_placed(rec):
            continue
        d = (rel.get(rid) or {}).get("disposition")
        if d not in EXPLAINED_ZERO:
            out.append(_c("C1", "a release placed nothing and nothing says so",
                          f"{rid} (Southeast) placed nothing on the chart but its "
                          f"disposition reads {d!r}", repair="mark-no-units:" + rid))
    return out


def c2_banner_matches_ledger(data, led, page_head):
    """THE BAR MUST BE CONSISTENT WITH ITSELF, AND NAME WHAT IT CLAIMS TO NAME.

    The first cut compared the page against the LEDGER, but the page applies
    supersession, ageing and classification the ledger knows nothing about, so
    the two legitimately disagree and C2 fired on a page that was right
    (ledger #115 — the purple "could not put right" line the client saw). The
    page now declares the full set it surfaces and the total it states; this
    check holds it to that declaration: every id it says it shows is linked,
    and the stated total is the size of the declared set.
    """
    if page_head is None:
        return []
    m = re.search(r"let UNREAD_ALL = (\[[^\]]*\]);", page_head)
    if not m:
        return []                      # a page built before the declaration existed
    try:
        allids = [str(x) for x in json.loads(m.group(1))]
    except Exception:
        return [_c("C2", "the page's own list of missing announcements is unreadable",
                   m.group(1)[:80], repair="rebuild")]
    # every declared id must be LINKED — its bare presence proves nothing, the
    # declaration itself contains it (bench catch)
    missing = [r for r in allids if f"dcfnewsrelease/{r}.pdf" not in page_head]
    # NEVER SURFACED (ledger #115, the client: "this part should just
    # autocorrect by naming the announcement that is missing"). This is a
    # contradiction between the page and itself; its repair is a rebuild, and a
    # rebuild always resolves it. A captain cannot act on "the page does not
    # name an announcement" — the app can, so it does, and if it somehow
    # cannot, that is a build defect for the record, not a line on his screen.
    if missing:
        return [_c("C2", "the page does not name an announcement it is missing",
                   f"{len(missing)} release(s) the page itself lists are not linked: "
                   f"{missing[:6]}", repair="rebuild", surface=False)]
    mt = re.search(r'"total":\s*(\d+)', page_head)
    if allids and mt and int(mt.group(1)) != len(allids):
        return [_c("C2", "the page does not say how many announcements it is not showing",
                   f"it declares {len(allids)} but states a total of {mt.group(1)}",
                   repair="rebuild", surface=False)]
    return []


def c3_page_engine(data, engine_stamp, page_head):
    """THE PAGE MUST CARRY THE ENGINE SERVING IT (axiom 33, ledger #85/#96/#107)."""
    if page_head is None or not engine_stamp:
        return []
    m = re.search(r'name="afo-engine" content="([^"]*)"', page_head)
    got = m.group(1) if m else ""
    if got != engine_stamp:
        return [_c("C3", "the page was built by a different engine than the one serving it",
                   f"page says {got or '(unstamped)'!r}, engine is {engine_stamp!r}",
                   repair="rebuild")]
    return []


def c4_clock(data, now):
    """A DISPLAYED STATUS IS A CLAIM ABOUT NOW, AT BOTH ENDS (axiom 36,
    ledger #105/#108).

    Three ways it goes wrong, all of which have shipped: a window that ended,
    a window that has not started, and a recurring fishery whose record carries
    no pattern to judge — the last being the worst, because nothing on the
    record can ever contradict it.
    """
    rd = _jload(os.path.join(data, "regions_data.json"))
    if not rd:
        return []
    nowiso = now.isoformat(timespec="minutes")
    ended, unstarted, unjudgeable = [], [], []
    for key, R in (rd.get("regions") or {}).items():
        for gear, st in (R.get("status") or {}).items():
            for code, rec in (st or {}).items():
                if rec.get("status") not in ("open", "partial"):
                    continue
                e, s = rec.get("ends"), rec.get("starts")
                if e and str(e) < nowiso:
                    ended.append(f"{key}/{gear}/{code} ended {e}")
                elif s and str(s) > nowiso:
                    unstarted.append(f"{key}/{gear}/{code} starts {s}")
                elif not e and not s and not rec.get("weekly"):
                    txt = (rec.get("period_text") or "").lower()
                    if re.search(r"\b(mondays|tuesdays|wednesdays|thursdays|fridays|"
                                 r"saturdays|sundays|each week|weekly|every week)\b", txt):
                        unjudgeable.append(f"{key}/{gear}/{code}")
    out = []
    if ended:
        out.append(_c("C4", "a status shown open has already ended",
                      f"{len(ended)}: {ended[:4]}", repair="rebuild"))
    if unstarted:
        out.append(_c("C4", "a status shown open has not started yet",
                      f"{len(unstarted)}: {unstarted[:4]}", repair="rebuild"))
    if unjudgeable:
        out.append(_c("C4", "a recurring fishery carries no pattern to judge it by",
                      f"{len(unjudgeable)}: {unjudgeable[:4]} — it would read open "
                      f"on every off day", repair="rebuild"))
    return out


def c5_listing_coverage(data, led):
    """EVERY RELEASE THE AUTHORITY LISTED IS ACCOUNTED FOR (axiom 37, #109).

    Not repairable here — it needs the network — so it is recorded and the next
    fetch cycle picks it up. Recorded is the point: a `continue` with no record
    is a destroyed fact.
    """
    if not led:
        return []
    rel = led.get("releases") or {}
    blank = sorted(r for r, v in rel.items() if not (v or {}).get("disposition"))
    if blank:
        return [_c("C5", "a release the authority listed has no disposition",
                   f"{len(blank)}: {blank[:6]}", repair=None)]
    return []


def c6_page_age(data, now):
    """THE PAGE MUST NOT BE OLDER THAN THE NEWEST ANNOUNCEMENT IT HOLDS.

    A rebuild that failed quietly leaves yesterday's chart in front of a
    captain with today's opening sitting in the data behind it.
    """
    rd = _jload(os.path.join(data, "regions_data.json"))
    if not rd:
        return []
    as_of = str(rd.get("as_of") or "")
    newest = ""
    for sub in ("areas", "raw"):
        for p in glob.glob(os.path.join(data, sub, "*.json")):
            pub = str((_jload(p, {}) or {}).get("published") or "")
            if pub > newest:
                newest = pub
    if as_of and newest and newest[:16] > as_of[:16]:
        return [_c("C6", "the chart is older than an announcement it already holds",
                   f"chart as_of {as_of}, newest held announcement published {newest}",
                   repair="rebuild")]
    return []


def c7_stale_parser(data):
    """A SHIPPED GRAMMAR FIX MUST REACH THE ANNOUNCEMENTS ALREADY HELD
    (ledger #113).

    Parsing happens once, when a release first arrives. So a parser improvement
    only ever helps announcements that have not come in yet — and the ones a
    captain needs today are already in the folder, parsed by last week's code.
    Kodiak #45 and Sand Point #26 were still holding zero units on the client's
    machine minutes after he installed the build that fixed exactly them.
    """
    try:
        import sys
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import reparse
        fp = reparse.fingerprint()
    except Exception:
        return []
    stale = []
    for sub in ("areas", "raw"):
        for p in glob.glob(os.path.join(data, sub, "*.json")):
            rid = os.path.basename(p)[:-5]
            if not _is_announcement(rid):
                continue
            rec = _jload(p, {}) or {}
            if rec.get("_parser") != fp and len((rec.get("full_text") or "").strip()) >= 200:
                stale.append(rid)
    if stale:
        return [_c("C7", "announcements are still parsed by an older grammar",
                   f"{len(stale)} record(s) carry a parser stamp that is not the "
                   f"installed one: {sorted(stale)[:6]}", repair="reparse")]
    return []


# --------------------------------------------------------------------- repairs
def _why_zero(data, rid):
    """Ask the announcement's own words WHY it placed nothing (ledger #113):
    a subsistence schedule and a kelp notice are correctly absent from a
    commercial salmon chart; only a real commercial announcement is a miss."""
    for sub in ("areas", "raw"):
        rec = _jload(os.path.join(data, sub, rid + ".json"))
        if not rec:
            continue
        text = rec.get("full_text") or ""
        if len(text.strip()) < 200:
            return None
        try:
            import sys
            sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
            import openparse
            return openparse.classify_zero_yield(text)
        except Exception:
            return None
    return None


def _mark_no_units(data, rid, log):
    """Write the truth into the ledger so the banner can name it.

    The repair is deliberately the SMALLEST one that makes the app honest: it
    does not try to re-parse the announcement (that is a code change, and this
    module must never invent placements). It records that nothing was placed,
    which turns a silent miss into a named one on the captain's screen.
    """
    p = os.path.join(data, AUDIT_FILE)          # never written here; see run()
    led_p = os.path.join(data, "dispositions.json")
    led = _jload(led_p, {}) or {}
    rel = led.setdefault("releases", {})
    prev = (rel.get(rid) or {}).get("disposition")
    rec = rel.setdefault(rid, {})
    why = _why_zero(data, rid)
    rec["disposition"] = why or "no-units"
    rec.setdefault("why", ["self-audit: held but placed nothing on the chart"])
    rec["was"] = prev
    if not rec.get("published"):
        for sub in ("areas", "raw"):
            r0 = _jload(os.path.join(data, sub, rid + ".json"))
            if r0 and r0.get("published"):
                rec["published"] = r0["published"]
                break
    led.setdefault("checked_at", "")
    tmp = led_p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(led, f, indent=1)
    os.replace(tmp, led_p)
    log(f"  SELF-AUDIT repaired: {rid} disposition {prev!r} -> {rec['disposition']!r}")
    return True


# ------------------------------------------------------------------------- run
def _page_head(data, nbytes=400_000):
    p = os.path.join(data, "SE_Openings.html")
    try:
        with open(p, encoding="utf-8", errors="replace") as f:
            return f.read(nbytes)
    except Exception:
        return None


def collect(data, engine_stamp=None, now=None):
    """Every invariant, once. Returns the contradictions found."""
    now = now or alaska_now()
    led = _jload(os.path.join(data, "dispositions.json"))
    head = _page_head(data)
    out = []
    for fn in (lambda: c1_placed_nothing(data, led),
               lambda: c1_reclassify(data, led),
               lambda: c2_banner_matches_ledger(data, led, head),
               lambda: c3_page_engine(data, engine_stamp, head),
               lambda: c4_clock(data, now),
               lambda: c5_listing_coverage(data, led),
               lambda: c6_page_age(data, now),
               lambda: c7_stale_parser(data)):
        try:
            out.extend(fn() or [])
        except Exception as e:                    # one bad check never stops the audit
            out.append(_c("C0", "a self-audit check could not run", str(e),
                          repair=None, surface=False))
    return out


def run(data, engine_stamp=None, rebuild_fn=None, repair=True, log=print):
    """Audit, repair what is repairable, re-audit ONCE, record, return.

    Exactly one repair round. A self-healer that loops is a self-healer that
    burns a laptop's battery all night on a contradiction it cannot fix; the
    second pass exists to prove the repair worked, not to keep trying.
    """
    found = collect(data, engine_stamp)
    repaired = []
    if repair and found:
        need_rebuild = False
        for c in found:
            r = c.get("repair") or ""
            try:
                if r.startswith("mark-no-units:"):
                    if _mark_no_units(data, r.split(":", 1)[1], log):
                        c["repaired"] = True
                        repaired.append(c["id"] + " " + c["detail"][:80])
                        need_rebuild = True      # the banner must be re-rendered
                elif r == "reparse":
                    import sys
                    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
                    import reparse
                    rr = reparse.run(data, log=log)
                    ch = [x for x in rr.get("reparsed", []) if "->" in x]
                    if ch or rr.get("kept_old"):
                        repaired.append(f"re-parsed {len(ch)} record(s) with the "
                                        f"installed grammar, recovering "
                                        f"{rr.get('gained', 0)} placement(s)")
                        c["repaired"] = True
                    need_rebuild = True
                elif r == "rebuild":
                    need_rebuild = True
            except Exception as e:
                log(f"  SELF-AUDIT repair failed: {e}")
        if need_rebuild and rebuild_fn:
            try:
                log("  SELF-AUDIT: rebuilding to clear a contradiction")
                rebuild_fn()
                repaired.append("rebuilt the page")
            except Exception as e:
                log(f"  SELF-AUDIT rebuild failed: {e}")
        found = collect(data, engine_stamp)       # the proof, not the intention

    stubborn = [c for c in found if c.get("surface")]
    res = {"checked_at": dt.datetime.now().replace(microsecond=0).isoformat(),
           "alaska_now": alaska_now().isoformat(timespec="minutes"),
           "contradictions": found, "open": stubborn, "repaired": repaired,
           "ok": not stubborn}
    try:
        p = os.path.join(data, AUDIT_FILE)
        tmp = p + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(res, f, indent=1)
        os.replace(tmp, p)
    except Exception as e:
        log(f"  SELF-AUDIT could not write its record: {e}")
    for c in stubborn:
        log(f"  SELF-AUDIT UNRESOLVED [{c['id']}] {c['what']}: {c['detail'][:140]}")
    if repaired:
        log(f"  SELF-AUDIT repaired {len(repaired)} thing(s)")
    return res


# ---------------------------------------------------------------------- selftest
if __name__ == "__main__":
    import shutil, sys, tempfile
    tmp = tempfile.mkdtemp()
    fails = []
    try:
        os.makedirs(os.path.join(tmp, "areas")); os.makedirs(os.path.join(tmp, "raw"))
        # the #110 shape: held, perfect, placed nothing, filed "ingested"
        json.dump({"release_id": "1833462759", "region": "Kodiak", "units": [],
                   "published": "2026-09-02T00:00"},
                  open(os.path.join(tmp, "areas", "1833462759.json"), "w"))
        json.dump({"checked_at": "x", "listed": 2,
                   "releases": {"1833462759": {"disposition": "ingested"},
                                # flagged for the captain, and the page never
                                # names it — the C2 shape
                                "1834219457": {"disposition": "unreadable"},
                                "1899999999": {}}},
                  open(os.path.join(tmp, "dispositions.json"), "w"))
        json.dump({"as_of": "2026-09-01T00:00", "regions": {"SE": {"status": {
            "drift gillnet": {
                "1-A": {"status": "open", "ends": "2026-01-01T00:00"},
                "1-B": {"status": "open", "starts": "2099-01-01T00:00"},
                "1-C": {"status": "open", "period_text": "on Tuesdays and Fridays"}}}}}},
            open(os.path.join(tmp, "regions_data.json"), "w"))
        open(os.path.join(tmp, "SE_Openings.html"), "w").write(
            '<meta name="afo-engine" content="2.9.0+deadbeef">'
            'let UNREAD_ALL = ["1834219457"];')      # declares it, never links it

        # a REGULATION record is not an announcement (bench catch)
        json.dump({"areas": []}, open(os.path.join(tmp, "raw", "se_reg_d1_d2.json"), "w"))
        # an SE release that places by NAME with no coordinates has placed
        # plenty — the first cut of C1 called this "nothing" (bench catch)
        json.dump({"release_id": "1828817395", "published": "2026-08-22T00:00",
                   "areas": [{"district": "Yakutat District",
                              "section": "East Alsek River", "status": "open",
                              "rules": []}]},
                  open(os.path.join(tmp, "raw", "1828817395.json"), "w"))

        # C7: a record parsed by an older grammar, with its own words present —
        # the shape that left Kodiak #45 empty on the client's machine minutes
        # after he installed the build that fixed it (ledger #113)
        fx = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                          "tests", "fixtures", "nseo_recon", "KOD45.txt")
        if os.path.exists(fx):
            json.dump({"release_id": "1833462759", "region": "Kodiak", "units": [],
                       "published": "2026-09-02T00:00", "_parser": "old00000",
                       "full_text": open(fx, encoding="utf-8").read()},
                      open(os.path.join(tmp, "areas", "1833462759.json"), "w"))

        found = collect(tmp, "2.9.8+cafe1234")
        if os.path.exists(fx) and not any(c["id"] == "C7" for c in found):
            fails.append("a record parsed by an older grammar was not detected")
        c1s = [c["detail"] for c in found if c["id"] == "C1"]
        if any("se_reg_d1_d2" in d for d in c1s):
            fails.append("a regulation record was flagged as an announcement "
                         "that placed nothing — the banner would carry nonsense")
        if any("1828817395" in d for d in c1s):
            fails.append("a release that opens twelve rivers BY NAME was called "
                         "'placed nothing' because it carries no coordinates")
        ids = [c["id"] for c in found]
        for want, why in (("C1", "a zero-yield release filed as ingested"),
                          ("C2", "a flagged release the page never names"),
                          ("C3", "a page built by another engine"),
                          ("C4", "a clock contradiction"),
                          ("C5", "a listed release with no disposition"),
                          ("C6", "a chart older than an announcement it holds")):
            if want not in ids:
                fails.append(f"{want} not detected — {why}")
        n4 = sum(1 for c in found if c["id"] == "C4")
        if n4 < 3:
            fails.append(f"only {n4} of the 3 clock contradictions found "
                         f"(ended / unstarted / unjudgeable recurrence)")

        # the repair must actually change the record, and be PROVEN by re-audit
        res = run(tmp, "2.9.8+cafe1234", rebuild_fn=None, log=lambda *a: None)
        led = json.load(open(os.path.join(tmp, "dispositions.json")))
        if led["releases"]["1833462759"]["disposition"] != "no-units":
            fails.append("the C1 repair did not write 'no-units' into the ledger")
        if not any(c["id"] == "C1" for c in res["contradictions"]) is False:
            pass
        if any(c["id"] == "C1" for c in res["contradictions"]):
            fails.append("C1 survived its own repair")
        if res["ok"]:
            fails.append("the audit reported ok while C3/C4/C5/C6 were unresolved")
        if not os.path.exists(os.path.join(tmp, AUDIT_FILE)):
            fails.append("no selfaudit.json written — nothing to surface or audit")
        # and the re-parse repair must actually have RECOVERED the openings
        if os.path.exists(fx):
            k = json.load(open(os.path.join(tmp, "areas", "1833462759.json")))
            if len(k.get("units") or []) < 20:
                fails.append(f"the C7 repair left Kodiak #45 at "
                             f"{len(k.get('units') or [])} units — a shipped "
                             f"grammar fix still has not reached the record")

        # a clean tree must report clean, or the bar cries wolf forever
        clean = tempfile.mkdtemp()
        os.makedirs(os.path.join(clean, "areas")); os.makedirs(os.path.join(clean, "raw"))
        json.dump({"as_of": "2099-01-01T00:00", "regions": {}},
                  open(os.path.join(clean, "regions_data.json"), "w"))
        json.dump({"checked_at": "x", "releases": {}},
                  open(os.path.join(clean, "dispositions.json"), "w"))
        open(os.path.join(clean, "SE_Openings.html"), "w").write(
            '<meta name="afo-engine" content="2.9.8+cafe1234">')
        r2 = run(clean, "2.9.8+cafe1234", rebuild_fn=None, log=lambda *a: None)
        if not r2["ok"] or r2["contradictions"]:
            fails.append(f"a healthy tree reported contradictions: "
                         f"{[c['id'] for c in r2['contradictions']]}")
        shutil.rmtree(clean, ignore_errors=True)

        for f in fails:
            print("  FAIL:", f)
        print("SELFTEST PASS — the app detects and repairs its own contradictions"
              if not fails else f"SELFTEST FAILED ({len(fails)})")
        sys.exit(0 if not fails else 1)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
