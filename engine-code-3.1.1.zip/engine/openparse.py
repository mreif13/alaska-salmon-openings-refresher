"""Named-unit opening/closing parser for the NON-Southeast management areas.

Southeast's announcements draw closures as coordinate lines; extract.py parses
those. Every other ADF&G area announces openings and closings by NAMED unit —
"the Copper River District will open at 7:00 am Monday", "the following areas
will close at 6:00 p.m. Monday: The Eastside Kodiak District; ...". This module
turns that templated grammar into per-unit status records, which areastatus.py
then maps to each area's geometry (district/section codes).

DESIGN — precision is the hard constraint, same as extract.py:
  * Every unit it emits is named EXPLICITLY in the announcement with an
    EXPLICIT status word (open / closed). It never infers a status.
  * "will close AT <time> <day>" means the unit is OPEN now and closes then, so
    it is emitted status=open with that window; the time model then decides
    open-now / not-today / expired. "for the season" / "remain closed" /
    "will remain closed" are closed.
  * A section-specific statement outranks a district-wide one for that section
    (areastatus applies that precedence), so "Afognak District will close" plus
    "Southwest Afognak Section is extended" resolves correctly.
  * A unit it cannot confidently name+status is dropped, never guessed;
    areastatus refuses to map any name it is not sure of. The worst a miss can
    do is leave a unit boundaries-shown — never show a wrong status.

Pure stdlib.
"""
import re

# ------------------------------------------------------------------- region id
# Prefer the ADF&G "X Area Office" / "Headquarters Office" letterhead, then fall
# back to distinctive title text. Yakutat and Cordova(PWS) are Southeast-region
# offices but SEPARATE management areas in this app, so they are tested first.
_OFFICE_REGION = [
    (r"Yakutat Area Office", "Yakutat"),
    (r"Cordova Area Office", "PWS"),
    (r"Kodiak.*Office|Kodiak Fish and Game", "Kodiak"),
    (r"Chignik.*Office", "Chignik"),
    (r"(Sand Point|Alaska Peninsula).*Office", "AreaM"),
    (r"(Homer|Soldotna|Cook Inlet).*Office", "CookInlet"),
    (r"(Dillingham|Bristol Bay|King Salmon).*Office", "BristolBay"),
    (r"(Nome|Kotzebue|Emmonak|Bethel|Fairbanks).*Office", "AYK"),
    (r"(Juneau|Ketchikan|Petersburg|Sitka|Douglas).*Area Office", "SE"),
]
_TITLE_REGION = [
    ("Yakutat",    r"\bYakutat\b"),
    ("PWS",        r"Prince William Sound"),
    ("Kodiak",     r"\bKodiak\b"),
    ("Chignik",    r"\bChignik\b"),
    ("AreaM",      r"Alaska Peninsula|Sand Point|\bArea M\b|South Peninsula|North Peninsula"),
    ("CookInlet",  r"Cook Inlet"),
    ("BristolBay", r"Bristol Bay|Nushagak|Naknek|Egegik|Ugashik|Togiak"),
    ("AYK",        r"\bYukon\b|Kuskokwim|Norton Sound|Kotzebue|Port Clarence"),
    ("SE",         r"Southeast Alaska|Juneau Area|Ketchikan|Petersburg\b|Sitka"),
]


def detect_region(text):
    head = text[:1400]                       # letterhead + title live at the top
    for rx, key in _OFFICE_REGION:
        if re.search(rx, head, re.I):
            return key
    for key, rx in _TITLE_REGION:
        if re.search(rx, text, re.I):
            return key
    return None


GEARMAP = [("purse seine", "purse seine"), ("drift gillnet", "drift gillnet"),
           ("set gillnet", "set gillnet"), ("troll", "troll"), ("seine", "purse seine")]
_BARE_GILLNET = re.compile(r"(?<!set )(?<!drift )\bgillnet", re.I)
MONTHS = {m.lower(): i for i, m in enumerate(
    ["January", "February", "March", "April", "May", "June", "July", "August",
     "September", "October", "November", "December"], 1)}


def _norm_ws(t):
    return re.sub(r"[ \t ]+", " ", t)


def _flat(text):
    return _norm_ws(text.replace("\r", "").replace("\n", " "))


def _gears(t):
    """Gear names in a text. 'gillnet' alone (not 'set gillnet'/'drift gillnet')
    reads as drift gillnet; a 'set gillnet' fishery must NOT also register as
    drift — a wrong gear is a wrong opening for that gear's captains."""
    tl = t.lower(); found = []
    for k, v in GEARMAP:
        if k in tl and v not in found:
            found.append(v)
    if re.search(r"set and drift gillnett?", tl):
        for v in ("set gillnet", "drift gillnet"):
            if v not in found:
                found.append(v)
    if "drift gillnet" not in found and _BARE_GILLNET.search(tl):
        found.append("drift gillnet")
    return found or None


# ADF&G writes its release line four ways, and the first cut of this only read
# two of them: "Released: 10:00 a.m. September 2, 2026" and "For Immediate
# Release: Fri., Sept. 4, 2026" both fell through and left `published` NULL —
# on Kodiak #45 and Lower Cook Inlet #20 among others (ledger #114). A missing
# publication date is not cosmetic: it is what orders announcements, decides
# which one supersedes which, and ages a warning off the chart.
_MONABBR = {m[:3]: i for m, i in MONTHS.items()}
_PUBLINE = re.compile(
    r"(?:For\s+Immediate\s+)?Release[d]?\s*:?\s*"          # the label, either form
    r"(?:\d{1,2}:\d{2}\s*[ap]\.?\s?m\.?\s*,?\s*)?"          # an optional time
    # the weekday must be a WEEKDAY: a generic word here greedily ate the month
    # itself ("Released: August 26" -> weekday "August", then no month left)
    r"(?:(?:Mon|Tues?|Weds?|Thur?s?|Fri|Sat|Sun)[a-z]*\.?\s*,?\s*)?"
    r"([A-Z][a-z]{2,8})\.?\s+(\d{1,2})\s*,?\s*(\d{4})", re.I)


def _published(t):
    for m in _PUBLINE.finditer(t or ""):
        word = m.group(1).lower()
        mo = MONTHS.get(word) or _MONABBR.get(word[:3])
        if mo:
            return f"{int(m.group(3)):04d}-{mo:02d}-{int(m.group(2)):02d}T00:00"
    return None


# ------------------------------------------------------- naming an announcement
# A CAPTAIN CANNOT READ A RELEASE ID (ledger #114, the client: "labeling the
# announcements with numbers as 1834 etc doesn't help communicate to the human
# eye at a quick glance"). Every ADF&G release names itself in the same shape —
# "KODIAK COMMERCIAL SALMON FISHERY ADVISORY ANNOUNCEMENT # 45", "Norton Sound
# Advisory Announcement #19", "Lower Cook Inlet Salmon Fishery Advisory
# Announcement #20" — so the name is there to be read, not invented.
_NAMEWORD = (r"(?!COMMERCIAL\b|SALMON\b|FISHERY\b|FISHERIES\b|ADVISORY\b|"
             r"ANNOUNCEMENT\b|AREA\b|OFFICE\b|EMERGENCY\b|ORDER\b)"
             r"[A-Za-z][A-Za-z'\-]+")
_ANNLABEL = re.compile(
    r"(" + _NAMEWORD + r"(?:\s+" + _NAMEWORD + r"){0,3})\s+"
    r"(?:COMMERCIAL\s+)?(?:SALMON\s+)?(?:FISHER(?:Y|IES)\s+)?"
    r"ADVISORY\s+ANNOUNCEMENT\s*#?\s*(\d+)", re.I)


def announcement_label(text):
    """-> {'series': 'Kodiak', 'number': 45, 'label': 'Kodiak #45'} or {}.

    `series` is what makes supersession answerable: Norton Sound #19 is
    replaced by Norton Sound #20, and neither has anything to do with a Yukon
    subsistence schedule that happens to share the AYK region.
    """
    t = text or ""
    m = None
    for cand in _ANNLABEL.finditer(t):
        # the release's OWN title, not a cross-reference inside the body:
        # "Please see Fall Season Announcement #7" is someone else's number
        # (caught on the client's Yukon records, ledger #115)
        before = t[max(0, cand.start() - 40):cand.start()].lower()
        if re.search(r"\b(see|refer to|per|in|under|from)\s*$", before):
            continue
        if cand.group(1).strip().lower().startswith(("please", "see ")):
            continue
        m = cand
        break
    if not m:
        return {}
    name = re.sub(r"\s+", " ", m.group(1)).strip()
    if name.isupper() or name.islower():
        name = name.title()
    return {"series": name, "number": int(m.group(2)),
            "label": f"{name} #{int(m.group(2))}"}




def _eo(flat):
    m = (re.search(r"Emergency Order\s*#?\s*([0-9][A-Za-z0-9\-]{3,})", flat)
         or re.search(r"\bEO\s*#?\s*([0-9][A-Za-z0-9\-]{3,})", flat))
    return m.group(1) if m else None


# ------------------------------------------------------------- unit-name parsing
_SECTIONS_OF = re.compile(r"^(.+?)\s+Sections?\s+of\s+the\s+(.+?\bDistrict)\b", re.I)
_SUBDISTRICT_OF = re.compile(r"^(.+?)\s+Subdistricts?\s+of\s+the\s+(.+?\bDistrict)\b", re.I)
_WHOLE_DISTRICT = re.compile(r"^(.+?\bDistrict)\b", re.I)
# a bare section list with no parent: "the Duck Bay, Izhut Bay, Outer Kitoi Bay,
# and Inner Kitoi Bay Sections" (Kodiak's "(except ... remain closed)" form)
_SECTIONS_BARE = re.compile(r"^(.+?)\s+Sections?$", re.I)


def _split_names(s):
    """'Cape Alitak, Alitak Bay, Moser Bay, and Olga Bay' -> the four names."""
    s = re.sub(r",?\s+and\s+", ",", s, flags=re.I)
    return [re.sub(r"\s+", " ", x).strip(" .;") for x in s.split(",") if x.strip(" .;")]


# ---- coordinate scan: the "exactly where" of a partial ----------------------
# The advisories often carry the dividing line's own coordinates ("south of a
# line from 60º 56.00' N. Lat.", "east of a line from ... 59° 49.91' N. lat.,
# 153° 05.47' W. long., to ... 59° 51.67' N. lat., 153° 07.92' W. long").
# Copied byte-for-byte, never retyped; the applier converts and the map draws
# the line — the same standard Southeast partials already meet.
_CDEG = r"[°º˚]"
_CMIN = r"[′'’´]"
_CLAT = r"\d{1,3}\s*" + _CDEG + r"\s*\d{1,2}(?:\.\d+)?\s*" + _CMIN + r"?\s*N"
_CLON = r"\d{1,3}\s*" + _CDEG + r"\s*\d{1,2}(?:\.\d+)?\s*" + _CMIN + r"?\s*W"
_CPAIR = re.compile(r"(" + _CLAT + r")\.?\s*(?:lat)?\.?,?\s*(" + _CLON + r")", re.I)
_CLATONLY = re.compile(r"(" + _CLAT + r")\.?\s*(?:Lat|lat)", re.I)
_CSIDE = re.compile(r"\b(north|south|east|west)\s+of\s+(?:a|the|this)\s+line", re.I)
_GEAR_WATERS = re.compile(
    r"waters open to ((?:drift|set|purse)[a-z ]{0,14}?(?:gillnett?ing|sein(?:e|ing)))\s+"
    r"in\s+([A-Z][A-Za-z ]{2,40}?)\s+occur\s+(east|west|north|south)\s+of\s+a\s+line"
    r"(.{0,360}?)(?=\.\s+[A-Z]|$)", re.S)


def _line_status(body, sm, fallback):
    """The open/closed of a boundary line comes from ITS OWN sentence's verb,
    never from the unit's overall status: Copper River is partial-OPEN as a
    unit, but 'Waters north of this line ... are closed' is a CLOSED side —
    inheriting 'open' would paint the closed delta water green."""
    lo = max(0, sm.start() - 160); hi = min(len(body), sm.end() + 200)
    win = body[lo:hi].lower()
    if re.search(r"\b(?:are|is|will be|remains?|remain)\s+closed\b|\bclosed to\b", win):
        return "closed"
    if re.search(r"\b(?:are|is|will be|will|remains?|remain)\s+(?:be\s+)?open\b|\bopen to\b|\boccur\b", win):
        return "open"
    return fallback


def _unit_rules(body, fallback_status):
    """Coordinate rules inside a unit's own sentence: a sided line of pairs, or
    a single-latitude cutoff. Coordinates are copied byte-for-byte. Returns []
    when the digits are present but their structure is ambiguous (a flattened
    coordinate TABLE reads as many bare latitudes) — the map then shows the
    words, never a guessed line."""
    if not body:
        return []
    pairs = [{"lat_dm": re.sub(r"\s+", " ", m.group(1)).strip(),
              "lon_dm": re.sub(r"\s+", " ", m.group(2)).strip()}
             for m in _CPAIR.finditer(body)]
    sm = _CSIDE.search(body)
    side = sm.group(1).lower() if sm else None
    st = _line_status(body, sm, fallback_status) if sm else fallback_status
    if pairs:
        return [{"status": st, "side": side,
                 "geometry": "line" if len(pairs) >= 2 else "lat_cutoff",
                 "points": pairs, "text": re.sub(r"\s+", " ", body).strip()[:300]}]
    stripped = _CPAIR.sub(" ", body)
    lats = _CLATONLY.findall(stripped)
    if len(lats) == 1 and side:
        return [{"status": st, "side": side, "geometry": "lat_cutoff",
                 "points": [{"lat_dm": re.sub(r"\s+", " ", lats[0]).strip(), "lon_dm": None}],
                 "text": re.sub(r"\s+", " ", body).strip()[:300]}]
    # >1 bare latitude with no pairs = a flattened table; unmappable, words only
    return []


def _emit(out, seen, name, kind, parent, status, period_text, body=None):
    name = re.sub(r"^(the|and,?|then)\s+", "", name, flags=re.I).strip(" .;-–")
    name = re.sub(r"\s+", " ", name)
    if not name or len(name) < 3 or len(name) > 60:
        return
    # the dedupe key keeps the window/gear context — the same district can be
    # opened in two different per-gear blocks (Sand Point opens Unimak District
    # for seine/set AND for drift, in separate sentences) and both must emit
    key = (name.lower(), kind, (parent or "").lower(), status, (period_text or "")[:48])
    if key in seen:
        return
    seen.add(key)
    src = body if body is not None else period_text
    # a carve inside an OPEN/PARTIAL sentence gives the rule the OPEN side; a
    # CLOSED sentence's line is a closed boundary
    rside = "open" if status in ("open", "partial") else "closed"
    out.append({"name": name, "kind": kind, "parent": parent,
                "status": status, "period_text": period_text,
                "rules": _unit_rules(src, rside)})


def _parse_item(item, status, period_text, out, seen):
    """One list item (a phrase naming one or more units) -> unit records."""
    item = re.sub(r"^(?:the|and,?)\s+", "", re.sub(r"\s+", " ", item).strip(" .;-–"), flags=re.I)
    if not item or len(item) > 200:
        return
    m = _SECTIONS_OF.match(item)
    if m:
        parent = re.sub(r"^the\s+", "", m.group(2).strip(), flags=re.I)
        for nm in _split_names(m.group(1)):
            _emit(out, seen, nm, "section", parent, status, period_text)
        return
    m = _SUBDISTRICT_OF.match(item)
    if m:
        parent = re.sub(r"^the\s+", "", m.group(2).strip(), flags=re.I)
        for nm in _split_names(m.group(1)):
            _emit(out, seen, nm, "subdistrict", parent, status, period_text)
        return
    m = _WHOLE_DISTRICT.match(item)
    if m and m.group(1).strip().lower().endswith("district"):
        _emit(out, seen, m.group(1).strip(), "district", None, status, period_text)
        return
    m = _SECTIONS_BARE.match(item)
    if m:
        for nm in _split_names(m.group(1)):
            _emit(out, seen, nm, "section", None, status, period_text)
        return
    _emit(out, seen, item, "other", None, status, period_text)


# abbreviations whose full stop is NOT a sentence end — "6:00 p.m. Sunday" must
# stay one item, or every window in the list is cut in half.
_ABBR = re.compile(r"\b(a\.m|p\.m|No|Approx|Mt|St|U\.S|Rd|Ave|Dr|Sec|Nos)\.", re.I)
_SENT = re.compile(r"\.\s+(?=[A-Z])")


def _list_items(body):
    """Break a 'following areas' body into list items, separated by ';' OR by a
    sentence break before a capital.

    THE SENTENCE BREAK IS NOT COSMETIC (ledger #110). The last item of a Kodiak
    list runs straight into the next sentence ("...Sections of the Northwest
    Kodiak District. Chinook salmon 28 inches or greater..."), which pushed the
    item past the 200-character sanity limit in _parse_item and silently
    dropped six real openings — Uyak Bay, Zachar Bay, Spiridon Bay, Terror Bay,
    Kizhuyak Bay and Sharatin Bay. Abbreviated stops are masked first so a
    fishing window ("6:00 p.m. Sunday, September 6") is never cut."""
    masked = _ABBR.sub(lambda m: m.group(0).replace(".", "\x00"), body)
    items = []
    for chunk in re.split(r";", masked):
        for p in _SENT.split(chunk):
            p = p.replace("\x00", ".").strip(" .;-–•\t")
            if p:
                items.append(p)
    return items


# ----------------------------------------------------------------- block finder
# List-colon = a ':' followed by (optional bullet) 'The'/capital — distinct from
# a time colon ('6:00'), which is followed by digits. The intro window text is
# captured for the time model.
# THE REAL PDF TEXT CARRIES A ROW OF BULLET DASHES AFTER THE COLON — "areas:
# \n\n- - -\n\nThe Outer Karluk Section" — one dash per list item, flattened
# onto their own line by the PDF extractor. This pattern allowed exactly ONE.
# Ledger #70 recorded the flattened-bullet form as the reason two Kodiak
# releases parsed to zero; ledger #110 "fixed" the Kodiak grammar against a
# TRANSCRIBED fixture with no dashes, verified it, shipped it, and it placed
# nothing on the client's machine (ledger #115). Any number of bullets now.
_LISTCOLON = r":\s*(?:[-•–]\s*)*(?=(?:The\b|[A-Z]))"
_BLK_STOP = r"(?=(?:There will be a|The following areas|As Previously|Other closed|-end-|$))"
# "in the following <noun>:" — ADF&G writes areas / districts / sections /
# "districts and sections" interchangeably, and the space before "in" is
# sometimes missing in the PDF text ("September 7in the following sections").
_INTRO = (r"\s*in the following (?:areas|districts and sections|sections and districts|"
          r"districts|sections|subdistricts)")
_BLOCK_OPEN = [
    # KODIAK GRAMMAR — GENERAL, NOT KEYED TO ONE NOUN (ledger #110).
    # This used to require the literal word "extension", so Kodiak #45's second
    # and third blocks ("There will be a 78-hour commercial salmon fishing
    # period ... in the following areas:") matched nothing and their openings —
    # Outer Ayakulik, the whole Alitak District, Eastside Kodiak — were absent
    # from the chart. The announced thing is a fishing PERIOD; whether ADF&G
    # calls it a period, an extension, or an opening is style, not substance,
    # so the pattern now keys on the sentence shape and carries the window text
    # through whatever the noun.
    re.compile(r"There will be an? (.{0,200}?)" + _INTRO + _LISTCOLON
               + r"(.*?)" + _BLK_STOP, re.I | re.S),
    re.compile(r"The following areas (?:will|are scheduled to) close at (.{0,90}?)" + _LISTCOLON
               + r"(.*?)" + _BLK_STOP, re.I | re.S),
    re.compile(r"OPEN AREAS\s*(\([^)]*\))" + _LISTCOLON + r"(.*?)(?=(?:CLOSED|All waters|-end-|$))", re.I | re.S),
]
_BLOCK_CLOSED = [
    re.compile(r"The following areas will remain closed(.{0,90}?)" + _LISTCOLON
               + r"(.*?)" + _BLK_STOP, re.I | re.S),
]
# "(except the Izhut Bay, Outer Kitoi Bay, and Inner Kitoi Bay Sections WILL
# REMAIN closed...)" — without the optional "will"/"shall" the capture swallowed
# the verb, the item stopped looking like a section list, and three sections
# ADF&G had explicitly closed were left inside an OPEN district. That is a wrong
# opening, the one thing this app must never show (ledger #110).
_EXCEPT = re.compile(
    r"\(except\s+(.+?)\s+(?:will\s+|shall\s+|are\s+to\s+)?(?:remain|are|is|be)\s+closed",
    re.I | re.S)
# Sand Point / Area M grammar: per-gear "will be allowed" blocks —
#   "Commercial salmon fishing by purse seine and set gillnet gear will be
#    allowed for 109 hours from 8:00 a.m. Wednesday, August 26 until 9:00 p.m.
#    Sunday, August 30 in the following districts and sections: Unimak
#    District, ... and East Stepovak Sections of the Southeastern District."
# AREA M: "allowed" AND "extended" AND "open" ARE THE SAME ANNOUNCEMENT
# (ledger #110). Keyed to "will be allowed" alone, this missed every one of
# Sand Point #26's three blocks — all three say "will be extended" — so an
# open Unimak District, Southwestern District, South Central District, the
# Shumagin Islands Section and the Stepovak sections were absent from the
# chart. The verb is style; the sentence shape is the announcement.
_ALLOWED_VERB = r"will be (?:allowed|extended|open(?:ed)?)"
_ALLOWED_LIST = re.compile(
    r"[Cc]ommercial salmon fishing by (.{0,80}?) gear " + _ALLOWED_VERB + r"\s*(.{0,160}?)"
    + _INTRO + r":\s*(.*?)"
    r"(?=(?:[Cc]ommercial salmon fishing|All closed waters|Statistical charts|$))", re.S)
_ALLOWED_ONE = re.compile(
    r"[Cc]ommercial salmon fishing by (.{0,80}?) gear " + _ALLOWED_VERB + r"\s*(.{0,160}?)\s*"
    r"in the ([A-Z][A-Za-z '\-]+?)\s+Section of the ([A-Z][A-Za-z ]+?District)", re.S)
_SECS_OF_INLINE = re.compile(
    r"([A-Z][A-Za-z ,'\-]+?)\s+Sections?\s+of\s+the\s+([A-Z][A-Za-z ]+?District)")


_PERIOD_ONE = re.compile(
    r"There will be an? (\d{1,3}-hour commercial salmon (?:fishing )?(?:period|extension|opening)"
    r".{0,160}?)\s+in the ([A-Z][A-Za-z ,'\-]+?)\s+Sections?\s+of\s+the\s+"
    r"([A-Z][A-Za-z ]+?District)\s*\.", re.S)
_PAIRED = re.compile(r"^(Inner|Outer|North|South|East|West|Upper|Lower)\s+and\s+"
                     r"(Inner|Outer|North|South|East|West|Upper|Lower)\s+(.+)$")


def _parse_period_one(flat, out, seen):
    """Kodiak #43 (ledger #264): "There will be a 78-hour commercial salmon
    fishing period from noon Friday, August 28 to 6:00 p.m. Monday, August 31
    in the Inner and Outer Ugak Bay Sections of the Eastside District." — a
    period named in one sentence, not over a list, matched no block and two
    sections were absent from the chart. "Inner and Outer Ugak Bay" is two
    sections, each with the full name."""
    for m in _PERIOD_ONE.finditer(flat):
        window = re.sub(r"\s+", " ", m.group(1)).strip()
        names = []
        raw = re.sub(r"\s+", " ", m.group(2)).strip()
        pm = _PAIRED.match(raw)
        if pm:
            names = [pm.group(1) + " " + pm.group(3), pm.group(2) + " " + pm.group(3)]
        else:
            names = _split_names(raw)
        parent = re.sub(r"\s+", " ", m.group(3)).strip()
        for nm in names:
            _emit(out, seen, nm, "section", parent, "open", window[:240])


def _parse_allowed(flat, out, seen):
    """Area M 'will be allowed' blocks. The gear names ride in the window text
    so the per-unit gear resolver attributes each block to its own gears."""
    for m in _ALLOWED_LIST.finditer(flat):
        gearstxt, window, blob = m.group(1), m.group(2), m.group(3)
        wt = re.sub(r"\s+", " ", f"{gearstxt} gear allowed {window}").strip()[:240]
        rest = blob
        for sm in _SECS_OF_INLINE.finditer(blob):
            parent = sm.group(2).strip()
            for nm in _split_names(sm.group(1)):
                # the comma list can start with whole districts ("Unimak
                # District, Southwestern District, and Shumagin Islands, ...
                # Sections of the Southeastern District") — a token that is
                # itself a District is its own unit, not a section of the parent
                if nm.lower().endswith("district"):
                    _emit(out, seen, nm, "district", None, "open", wt)
                else:
                    _emit(out, seen, nm, "section", parent, "open", wt)
        rest = _SECS_OF_INLINE.sub(" ", rest)
        for tok in re.split(r",|\band\b|\n", rest):
            tok = re.sub(r"\s+", " ", tok).strip(" .;")
            if tok.lower().endswith("district"):
                _emit(out, seen, tok, "district", None, "open", wt)
    for m in _ALLOWED_ONE.finditer(flat):
        wt = re.sub(r"\s+", " ", f"{m.group(1)} gear allowed {m.group(2)}").strip()[:240]
        _emit(out, seen, m.group(3).strip(), "section", m.group(4).strip(), "open", wt)



def _split_carved(body, emitted, seen, wt):
    """Block body -> [{text, status}]. An item carrying its own "(except ...
    closed)" clause is OPEN only when every section that clause names was
    actually emitted closed; otherwise it is PARTIAL, because an open district
    with an unparsed carve is a wrong opening."""
    out = []
    names = {u["name"].lower() for u in emitted if u["status"] == "closed"}
    for raw in re.split(r";", body):
        st = "open"
        for em in _EXCEPT.finditer(raw):
            wanted = [re.sub(r"^(the)\s+", "", n, flags=re.I).strip().lower()
                      for it in _list_items(em.group(1)) for n in _split_names(
                          re.sub(r"\s+Sections?$", "", it, flags=re.I))]
            wanted = [w for w in wanted if len(w) > 2]
            if not wanted or not all(w in names for w in wanted):
                st = "partial"
        stripped = _EXCEPT.sub(" ", raw)
        stripped = re.sub(r"\([^()]{0,400}?\)", " ", stripped)   # drop the rest of the paren
        for it in _list_items(stripped):
            out.append({"text": it, "status": st})
    return out

def _parse_blocks(flat, out, seen):
    for rx in _BLOCK_OPEN:
        for m in rx.finditer(flat):
            window, body = m.group(1).strip(), m.group(2)
            wt = "close at " + window if "close" not in window.lower() else window
            for em in _EXCEPT.finditer(body):
                for it in _list_items(em.group(1)):
                    _parse_item(it, "closed", wt, out, seen)
            # AN UNPARSED CARVE MAY NEVER BE PAINTED GREEN (ledger #110).
            # "The Afognak District (except the Izhut Bay, Outer Kitoi Bay and
            # Inner Kitoi Bay Sections will remain closed)" is an OPEN district
            # only because those three sections are emitted closed and outrank
            # it. If the except clause names sections this parser could not
            # emit, the district's open would spread over water ADF&G just
            # closed — so the district degrades to PARTIAL instead. The status
            # is decided by what actually got emitted, not by the wording.
            for it in _split_carved(body, out, seen, wt):
                _parse_item(it["text"], it["status"], wt, out, seen)
    for rx in _BLOCK_CLOSED:
        for m in rx.finditer(flat):
            for it in _list_items(m.group(2)):
                _parse_item(it, "closed", m.group(1).strip(), out, seen)


# --------------------------------------------------------------- heading finder
# "COPPER RIVER DISTRICT: ... will open at 7:00 am Monday ..."   (PWS, ALL CAPS)
# "East Alsek River: will be open from 12:01 p.m. Sunday ..."     (Yakutat, Title)
# "The Outer District will close for the season at ..."           (Lower CI, inline)
_UNIT_WORD = r"(?:District|Subdistrict|Section|River|Bay|Inlet|Sound|Islands|Flats|Waters)"
# ALL-CAPS heading anchor: "NORTHERN DISTRICT:", "COPPER RIVER DISTRICT:".
_CAPS_ANCHOR = re.compile(r"([A-Z][A-Z '&/\-]{2,44}?\b(?:DISTRICT|SUBDISTRICT|SECTION))\s*:")
# Title-case heading: "East Alsek River: will be open ..." — anchored on a unit
# word + colon + an immediate status verb, so table labels ("Point:", "Latitude:")
# and descriptive sub-clauses ("Kaliakh River: the Tsiu River delta ... will be
# closed" — an interior spot closure, not the river's status) never match.
_TITLE_ANCHOR = re.compile(
    r"([A-Z][A-Za-z0-9''\-–/ ]{2,60}?\b" + _UNIT_WORD + r")\s*:\s*"
    r"(?=will\b|opens\b|is\b|are\b|remains?\b)")
_TITLE_OPEN = re.compile(r"^(?:will\s+(?:be\s+)?(?:re)?open\b|opens\b|will\s+remain\s+open\b|is\s+open\b|are\s+open\b)", re.I)
_TITLE_CLOSED = re.compile(r"^(?:will\s+(?:be\s+|remain\s+)?closed?\b|is\s+closed\b|are\s+closed\b|remains?\s+closed\b|will\s+close\s+for\s+the\s+season\b)", re.I)
_TITLE_CLOSE_AT = re.compile(r"^will\s+close\b(?!\s+for\s+the\s+season)", re.I)
_RESTRICTED = re.compile(r"with the following restriction", re.I)
# a body that opens only PART of the named district (a subdistrict / a line cut /
# a portion), or that also states an interior closure ("Waters north of this line
# ... are closed ... during all periods" — the Copper River grass-bank line), is
# a PARTIAL, never a blanket open — green paint must not cover closed water.
_PARTIAL_BODY = re.compile(
    r"\bsubdistrict\b|\bsection\b|(?:north|south|east|west)(?:erly|ward)?\s+of\s+(?:a|this)\s+line|"
    r"\bwaters of the\b|\bportion of\b|\bthat portion\b|"
    r"\bare closed\b|\bis closed\b|\bwill be closed\b|\bremains? closed\b", re.I)
_INLINE = re.compile(
    r"\bThe\s+([A-Z][A-Za-z0-9''\-–/ ]{2,58}?\b(?:District|Subdistrict))\s+"
    r"(will (?:be )?open|will open|opens|will remain closed|will (?:be )?closed?|"
    r"will close for the season|will close at|remains? closed)\b(.{0,160}?)(?=\.\s|$)", re.I | re.S)
# "Commercial fishing will open in the Kotzebue District as follows: • will
#  open for 8 hours from 10:00 a.m. until 6:00 p.m. Sunday, August 30"
_OPEN_IN = re.compile(
    r"\b(?:[Cc]ommercial(?:\s+salmon)?\s+fishing\s+)?will\s+open\s+in\s+the\s+"
    r"([A-Z][A-Za-z0-9''\-–/ ]{2,50}?\s+(?:District|Subdistrict))\b(.{0,400}?)(?=(?:[A-Z][a-z]+\s+holders|Two buyers|The 20\d\d|-end-|$))",
    re.S)
# "opens set and drift gillnetting in the Chinitna Bay Subdistrict of the
#  Central District on Tuesdays and Fridays from 7:00 a.m. ..."
_OPENS_GEAR_IN = re.compile(
    r"\bopens?\s+[a-z, ]{0,40}?gillnett?ing\s+in\s+the\s+"
    r"([A-Z][A-Za-z0-9''\-–/ ]{2,50}?\s+Subdistrict)\s+of\s+the\s+([A-Z][A-Za-z ]+?District)\b(.{0,260}?)(?=\.\s+[A-Z]|$)",
    re.S)
# "Waters of the Cannery Creek Subdistrict, south of a line from 60º 56.00' N.
#  Lat., will open to commercial purse seine fishing ..."
_WATERS_SUB = re.compile(
    r"\bWaters\s+of\s+the\s+([A-Z][A-Za-z0-9''\-–/ ]{2,50}?\s+Subdistrict)\b"
    r"(.{0,200}?)\bwill\s+open\b(.{0,220}?)(?=\.\s+[A-Z]|$)", re.S)
# a statement about SUBSISTENCE (or personal use) fishing is not a commercial
# status — this map is commercial-only, and painting commercial water from a
# subsistence schedule would be a wrong status in both directions
_SUBSIST = re.compile(r"\bsubsistence\b|\bpersonal use\b", re.I)
_JUNK_HEAD = re.compile(r"^(contact|point|latitude|longitude|note|gear|"
                        r"advisory announcement|for immediate release|division of|"
                        r"headquarters|www|po box|the department)", re.I)


def _status_from_body(body):
    b = body.lower()
    close_at = re.search(r"will close (?:for the season )?at\b|close at the conclusion|scheduled to close", b)
    opens = re.search(r"will (?:be )?open\b|will open\b|\bopens\b|will remain open", b)
    season = re.search(r"for the season|remain[s]? closed|will (?:be )?closed\b|closed for the (?:20\d\d )?season", b)
    if close_at and not re.search(r"for the season", b):
        return "open"
    if opens and not season:
        return "open"
    if season and not opens:
        return "closed"
    if close_at:
        return "open"          # "will close for the season at conclusion of Mon period" = open until then
    # OPENS, WITH WATERS INSIDE IT CLOSED (ledger #264, cause K): "Waters of the
    # Eastern District ... will open ... Waters inside the following ... markers
    # will be closed for this period". Both verbs, neither about the season:
    # that is a partial opening, and returning nothing dropped the Eastern
    # District's four days of seining from the chart.
    # "Remain closed ... will open Monday" is a closure now and an opening
    # later (cause G) — the sentence grammar keeps both; it is not partial.
    if (opens and re.search(r"will be closed|closed for this period|are closed", b)
            and not re.search(r"remain[s]? closed|for the (?:20\d\d )?season", b)):
        return "partial"
    return None


def _kind_of(name):
    low = name.lower()
    if "subdistrict" in low: return "subdistrict"
    if "district" in low: return "district"
    if "section" in low: return "section"
    return "other"


def _parse_headings(flat, out, seen):
    # ALL-CAPS district headings (PWS). A partial-opening body -> "partial".
    anchors = [(m.start(), m.end(), m.group(1)) for m in _CAPS_ANCHOR.finditer(flat)]
    # bodies end at the next heading of ANY kind — unit heading or generic
    # all-caps header ("SEINE FISHERIES:"). Without the generic bound, Eshamy's
    # body bleeds into the seine header and the word "seine" re-gears a
    # drift+seine district closure to seine-only — a closure a drift captain
    # would then never see.
    _GEN_HEAD = re.compile(r"(?:[A-Z][A-Z&/'’\-]{2,}\s+){1,5}[A-Z][A-Z&/'’\-]{2,}\s*:")
    hbounds = sorted({a[0] for a in anchors} | {m.start() for m in _GEN_HEAD.finditer(flat)})
    for i, (s, e, raw) in enumerate(anchors):
        nxt = next((b for b in hbounds if b > e), None)
        if nxt is None:
            nxt = min(len(flat), e + 400)
        body = flat[e:nxt]
        head = re.sub(r"\s+", " ", raw).strip(" .:;-–").title()
        head = re.sub(r"^(the)\s+", "", head, flags=re.I)
        # a stray status word printed above a heading ("CLOSED" between two
        # PWS district paragraphs) glued itself to the name: "Closed Montague
        # District" (ledger #264). The word is not part of the unit's name.
        head = re.sub(r"^(?:closed|open|opening|closure)\s+(?=\w)", "", head, flags=re.I)
        if not head or _JUNK_HEAD.match(head):
            continue
        st = _status_from_body(body)
        if not st:
            continue
        if st == "open" and _PARTIAL_BODY.search(body):
            st = "partial"
        _emit(out, seen, head, _kind_of(head), None, st,
              re.sub(r"\s+", " ", body).strip()[:520], body=body[:700])
    # Title-case headings (Yakutat rivers/inlets/bays; Norton Sound subdistricts).
    # Bodies are bounded at the NEXT heading (title or caps), so a unit's status
    # comes from its own verb — never from a later heading bleeding into a fixed
    # window (that bleed silently dropped Situk-Ahrnklin, Lost River, Yakataga).
    tanchors = [(m.start(), m.end(), m.group(1)) for m in _TITLE_ANCHOR.finditer(flat)]
    bounds = sorted(set([a[0] for a in tanchors]
                        + [m.start() for m in _CAPS_ANCHOR.finditer(flat)]
                        + [m.start() for m in _GEN_HEAD.finditer(flat)]))
    for s0, e0, raw in tanchors:
        nxt = next((b for b in bounds if b > s0), len(flat))
        body = flat[e0:min(nxt, e0 + 420)]
        head = re.sub(r"\s+", " ", raw).strip(" .:;-–")
        # an all-caps run glued to the front ("...ANNOUNCEMENT East Alsek River")
        head = re.sub(r"^(?:[A-Z0-9'&/\-]{2,}\s+)+(?=[A-Z][a-z])", "", head)
        head = re.sub(r"^(the)\s+", "", head, flags=re.I)
        if not head or _JUNK_HEAD.match(head):
            continue
        if _TITLE_OPEN.match(body):
            st = "partial" if _RESTRICTED.search(body) else "open"
        elif _TITLE_CLOSED.match(body):
            st = "closed"
        elif _TITLE_CLOSE_AT.match(body):
            st = "open"                      # "will close at <time>" = open until then
        else:
            continue
        _emit(out, seen, head, _kind_of(head), None, st,
              re.sub(r"\s+", " ", body).strip()[:520], body=body[:700])
    # inline "The <Name> District will ..." (Lower Cook Inlet phrasing). A name
    # the heading passes already carried is theirs — they saw the whole body;
    # emitting it again here can attach a contradictory status (Copper River:
    # heading says partial over the grass-bank closure, inline would say open).
    claimed = {u["name"].lower() for u in out}
    for m in _INLINE.finditer(flat):
        head = re.sub(r"\s+", " ", m.group(1)).strip()
        if re.sub(r"^(the)\s+", "", head, flags=re.I).lower() in claimed:
            continue
        sent = flat[max(0, m.start() - 80):m.end() + 80]
        if _SUBSIST.search(sent):
            continue                       # subsistence schedule, not commercial water
        verb = m.group(2).lower()
        if re.search(r"open", verb):
            st = "open"
        elif "close at" in verb or "conclusion" in (m.group(3) or "").lower():
            st = "open"
        else:
            st = "closed"
        _emit(out, seen, head, _kind_of(head), None, st,
              (verb + " " + re.sub(r"\s+", " ", m.group(3))).strip()[:240])
    # Norton Sound: "Shaktoolik Subdistrict 5 o will open ..." bullets.
    if re.search(r"Norton\s+Sound", flat):
        groups = {}
        for m in re.finditer(r"([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?\s+Subdistrict\s+\d)\s*:?\s*(?:o\s+)?"
                             r"will\s+open\b([^\u2022]{0,260}?)(?=\u2022|$|(?<![ap]\.m)\.\s+[A-Z])", flat):
            if _SUBSIST.search(flat[max(0, m.start() - 120):m.end()]):
                continue
            win = re.sub(r"\s+", " ", re.sub(r"[\uf000-\uf8ff]", " ", m.group(2))).strip().rstrip(".").strip()
            groups.setdefault(win, []).append(re.sub(r"\s+", " ", m.group(1)).strip())
        # each subdistrict is its own unit: Norton Sound's statistical areas
        # carry the subdistrict number (333-20 Golovin ... 333-60 Unalakleet),
        # so "Subdistricts 2-6" never paints Nome (Subdistrict 1) — red team,
        # ledger #264
        for win, names in groups.items():
            for nm in names:
                n = re.search(r"Subdistrict\s+(\d)", nm)
                if n:
                    _emit(out, seen, "Norton Sound Subdistrict " + n.group(1), "subdistrict",
                          "Norton Sound District", "open", (nm + ": will open " + win)[:300])
    # "Commercial fishing will open in the Kotzebue District ..." — the window
    # rides in the bullets that follow ("from 10:00 a.m. until 6:00 p.m.
    # Sunday, August 30").
    claimed = {u["name"].lower() for u in out}
    for m in _OPEN_IN.finditer(flat):
        head = re.sub(r"\s+", " ", m.group(1)).strip()
        if head.lower() in claimed or _SUBSIST.search(flat[max(0, m.start() - 80):m.start()]):
            continue
        _emit(out, seen, head, _kind_of(head), None, "open",
              re.sub(r"\s+", " ", m.group(2)).strip()[:240])
    # "opens set and drift gillnetting in the Chinitna Bay Subdistrict of the
    #  Central District on Tuesdays and Fridays from 7:00 a.m. ..."
    for m in _OPENS_GEAR_IN.finditer(flat):
        _emit(out, seen, re.sub(r"\s+", " ", m.group(1)).strip(), "subdistrict",
              re.sub(r"\s+", " ", m.group(2)).strip(), "open",
              re.sub(r"\s+", " ", (m.group(0))).strip()[:240])
    # "Waters of the Cannery Creek Subdistrict, south of a line ... will open"
    # — a line-cut inside the subdistrict makes it PARTIAL, never blanket open.
    for m in _WATERS_SUB.finditer(flat):
        cut = bool(re.search(r"\bof\s+a\s+line\b|north of|south of|east of|west of", m.group(2), re.I))
        _emit(out, seen, re.sub(r"\s+", " ", m.group(1)).strip(), "subdistrict", None,
              "partial" if cut else "open",
              re.sub(r"\s+", " ", m.group(0)).strip()[:240], body=m.group(0)[:700])


# --------------------------------------------------- why a release placed nothing
# A ZERO-YIELD RELEASE IS NOT ALWAYS A MISS (ledger #113). Three different
# things reach this code path and only one of them is a defect:
#   * a Yukon SUBSISTENCE / personal-use schedule — correctly absent from a
#     COMMERCIAL chart, and telling a captain it is "missing" is noise;
#   * a fishery that is not salmon at all (aquatic plants, herring, crab …)
#     that slipped past the crude "does the word salmon appear" filter;
#   * a genuine commercial salmon announcement this parser could not place —
#     the only one of the three a captain must be told about.
# Surfacing all three identically is how a warning bar becomes wallpaper.
_NONSALMON_FISHERY = re.compile(
    r"\b(aquatic plants?|kelp|herring|tanner crab|king crab|dungeness|shrimp|"
    r"sea cucumber|scallop|geoduck|dive fishery|halibut|sablefish|groundfish|"
    r"black rockfish|lingcod)\b", re.I)
_COMMERCIAL_ACTION = re.compile(
    r"commercial[^.]{0,120}?\b(will open|will be open|will reopen|is open|"
    r"will be allowed|will be extended|will close|will remain closed|"
    r"remains? closed|will be closed|is closed)\b", re.I)


_SALMON_GEAR = re.compile(r"\b(?:purse\s+seine|seine|drift\s+gillnet|set\s+gillnet|gillnet|hand\s+troll|power\s+troll|troll)\b", re.I)
_SALMON_UNIT = re.compile(r"\b(?:District\s+\d{1,3}|Districts\s+\d|Section\s+\d{1,3}-[A-Z]|Terminal\s+Harvest\s+Area|THA|"
                          r"Subdistrict|Special\s+Harvest\s+Area)\b")
_OTHER_SPECIES = re.compile(r"\b(?:herring|cod|crab|sea\s+cucumber|urchin|scallop|lingcod|rockfish|sablefish|shrimp|"
                            r"geoduck|halibut|pollock|clam|octopus|dungeness|tanner|eulachon|smelt|groundfish|kelp|"
                            r"aquatic\s+plants?|sea\s+otter|abalone|shark|skate|ling\s*cod)\b", re.I)


def is_commercial_salmon(text):
    """Is this a commercial SALMON fishery announcement? (ledger #264, cause C)

    The test used to be the word "salmon". Southeast drift gillnet and seine
    orders often never use it: "DISTRICT 11 DRIFT GILLNET FISHERY EXTENSION IN
    SPEEL ARM TERMINAL HARVEST AREA" and "DISTRICTS 6 AND 8 DRIFT GILLNET
    FISHERY EXTENSION" were filed "not salmon", and those fisheries never
    reached the chart or the warning bar. A salmon gear plus a salmon
    management unit, with no other species named as the fishery in the
    heading, is a salmon announcement. Herring sac roe uses the same gear and
    districts; it names herring, so it stays out."""
    t = text or ""
    if "salmon" in t.lower():
        return True
    head = t[:700]
    if _OTHER_SPECIES.search(head):
        return False
    return bool(_SALMON_GEAR.search(t) and _SALMON_UNIT.search(t))


def classify_zero_yield(text):
    """Why did this release place nothing? -> 'subsistence-only' | 'not-salmon'
    | None (None means: a real commercial announcement we failed to place).

    Deliberately conservative in the safe direction: anything that states a
    COMMERCIAL action stays a miss and stays surfaced, however much subsistence
    text surrounds it.
    """
    t = text or ""
    if _COMMERCIAL_ACTION.search(t):
        return None                      # a commercial statement: this is a miss
    low = t.lower()
    subs = len(re.findall(r"subsistence|personal use", low))
    if subs >= 3 and "commercial" not in low[:2000]:
        return "subsistence-only"
    if subs >= 8:
        return "subsistence-only"
    m = _NONSALMON_FISHERY.search(t)
    if m and low.count("salmon") <= 2:
        return "not-salmon"
    return None


# ---------------------------------------------- season-end closures (Lower CI)
# "The Outer, Eastern, Southern, and Kamishak Bay districts closed to purse
# seine harvest for the 2026 season at 10:00 PM on Tuesday, September 1." and
# "The commercial set gillnet fishery in the Southern District closed on August
# 15." — Lower Cook Inlet's wrap-up announcement (ledger #114). Neither form
# has a list-colon and both use the PAST tense, so every existing block and
# heading pattern walked past them and the newest word for that whole area
# placed nothing. These emit CLOSURES only: a pattern that can only ever close
# water cannot manufacture an opening, which is why it is safe to be generous
# here in a way this parser is never generous about opening.
_CLOSED_DISTRICT_LIST = re.compile(
    r"\b(?:The\s+)?([A-Z][A-Za-z ,'\-]{4,120}?)\s+[Dd]istricts?\s+"
    r"(?:were\s+|are\s+|was\s+|is\s+|have\s+been\s+|has\s+been\s+)?"
    r"clos(?:ed|e)\b(.{0,180}?)(?=\.\s|$)", re.S)
_CLOSED_FISHERY_IN = re.compile(
    r"\b[Cc]ommercial\s+([a-z ]{0,26}?(?:gillnet|seine|troll)[a-z]*)\s+fisher(?:y|ies)\s+"
    r"in\s+the\s+([A-Z][A-Za-z '\-]{2,40}?\s+(?:District|Subdistrict|Section))\s+"
    r"clos(?:ed|e[sd]?)\b(.{0,140}?)(?=\.\s|$)", re.S)


def _parse_season_closures(flat, out, seen):
    for m in _CLOSED_DISTRICT_LIST.finditer(flat):
        names, tail = m.group(1), m.group(2)
        if len(_split_names(names)) > 8:
            continue                      # a run-on sentence, not a district list
        # the name group must be a LIST OF PLACES, not a clause that happens to
        # end in "District": "commercial set gillnet fishery in the Southern"
        # is the other pattern's sentence, and emitting it here produced a unit
        # named after half a sentence (caught on the bench)
        if re.search(r"\b(fisher(?:y|ies)|commercial|harvest|in the|waters of)\b",
                     names, re.I):
            continue
        wt = re.sub(r"\s+", " ", m.group(0)).strip()[:240]
        for nm in _split_names(names):
            nm = nm.strip()
            if not nm or nm.lower() in ("the",):
                continue
            if not nm.lower().endswith("district"):
                nm = nm + " District"
            _emit(out, seen, nm, "district", None, "closed", wt)
    for m in _CLOSED_FISHERY_IN.finditer(flat):
        wt = re.sub(r"\s+", " ", m.group(0)).strip()[:240]
        _emit(out, seen, m.group(2).strip(), _kind_of(m.group(2)), None, "closed", wt)


def parse(text, release_id=None):
    """Announcement text -> {region, gear, published, units:[...], ...}. Non-SE
    only. region may be SE (caller then uses extract.py instead)."""
    flat = _flat(text)
    region = detect_region(text)
    out = {"release_id": str(release_id) if release_id else None,
           "region": region, "office": None,
           "published": _published(text), "emergency_order": _eo(flat),
           "gear": _gears(text),
           "species": "salmon" if "salmon" in text.lower() else None,
           "units": [], "all_others_closed": False, "_unparsed": [],
           # the announcement's complete words ride along (ledger #89) — the
           # parse decides what is DRAWN, never what the captain may READ
           "full_text": None}
    m = re.search(r"([A-Za-z .'\-]+? Area Office|Cordova Area Office|Headquarters Office)", text)
    if m:
        out["office"] = re.sub(r"\s+", " ", m.group(1)).strip()
    if re.search(r"(all|any)\s+waters\s+not\s+(?:listed|(?:otherwise )?mentioned)[^.]*?remain[s]? closed", flat, re.I) \
       or re.search(r"not listed above remain closed", flat, re.I):
        out["all_others_closed"] = True
    try:
        from extract import _body_text
        out["full_text"] = _body_text(text)
    except Exception:
        pass
    units = []; seen = set()
    _parse_blocks(flat, units, seen)
    _parse_allowed(flat, units, seen)
    _parse_period_one(flat, units, seen)
    _parse_season_closures(flat, units, seen)
    _parse_headings(flat, units, seen)
    # gear-scoped water carves: "waters open to drift gillnetting in Chinitna
    # Bay occur east of a line from ... 59° 49.91' N. lat., 153° 05.47' W. long.,
    # to ... 59° 51.67' N. lat., 153° 07.92' W. long." — attach to the named
    # unit as a rule limited to that gear, so the drift tab shows exactly where.
    for m in _GEAR_WATERS.finditer(flat):
        geartxt, place, side, span = m.group(1), m.group(2), m.group(3), m.group(4)
        pairs = [{"lat_dm": re.sub(r"\s+", " ", q.group(1)).strip(),
                  "lon_dm": re.sub(r"\s+", " ", q.group(2)).strip()}
                 for q in _CPAIR.finditer(span)]
        if len(pairs) < 2:
            continue
        gl = geartxt.lower()
        gears = ([g for k, g in (("drift", "drift gillnet"), ("set", "set gillnet"),
                                 ("purse", "purse seine")) if k in gl]) or None
        pk = re.sub(r"\s+", " ", place).strip().lower()
        for u in units:
            un = u["name"].lower()
            if pk in un or un.split(" subdistrict")[0].split(" section")[0] in pk:
                u.setdefault("rules", []).append(
                    {"status": "open", "side": side.lower(), "geometry": "line",
                     "points": pairs, "gears": gears,
                     "text": re.sub(r"\s+", " ", m.group(0)).strip()[:300]})
                break
    # ownership guard: a coordinate rule whose own sentence names a DIFFERENT
    # parsed unit belongs to that unit, not to whichever heading's body window
    # happened to cover it. Without this, "Waters of the Cannery Creek
    # Subdistrict, south of ... will open" attaches to Northern District too
    # and would paint a green carve across the whole district — an opening
    # shown where none exists. Keep a rule only if its text names the unit it
    # sits on, or names no other parsed unit at all.
    names = [u["name"] for u in units]
    for u in units:
        if not u.get("rules"):
            continue
        kept = []
        for r in u["rules"]:
            rt = (r.get("text") or "").lower()
            own_pos = rt.find(u["name"].lower())
            other_pos = [p for p in (rt.find(n.lower()) for n in names
                                     if n != u["name"] and len(n) > 6)
                         if p >= 0]
            # the earliest-named unit in the sentence is its subject; a rule
            # whose text names another unit before (or instead of) this one
            # belongs to that unit.
            if not other_pos or (own_pos >= 0 and own_pos <= min(other_pos)):
                kept.append(r)
        if kept:
            u["rules"] = kept
        else:
            u.pop("rules", None)
    out["units"] = units
    if not units:
        out["_unparsed"].append("no named units parsed")
    return out


# ----------------------------------------------------------------------- test
if __name__ == "__main__":
    import os, glob
    for tf in sorted(glob.glob("/home/claude/bof/nseo_text/*.txt")):
        name = os.path.basename(tf)[:-4]
        r = parse(open(tf, encoding="utf-8").read(), name)
        print(f"\n===== {name}  region={r['region']} gear={r['gear']} "
              f"EO={r['emergency_order']} pub={r['published']} others_closed={r['all_others_closed']}")
        for u in r["units"]:
            print(f"   [{u['status']:6}] {u['kind']:11} {u['name']!r}"
                  + (f"  of {u['parent']!r}" if u['parent'] else "")
                  + f"   | {u['period_text'][:60]!r}")
        if r["_unparsed"]:
            print("   _unparsed:", r["_unparsed"])
