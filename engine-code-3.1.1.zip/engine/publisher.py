"""Auto-publish the freshly rebuilt map to the client's own Netlify site,
so the public phone page is an EXTENSION OF THE ANNOUNCEMENT REFRESH — not a
snapshot anyone has to re-drag (client requirement, ledger #79).

Flow: after every successful refresh/rebuild, app.py calls maybe_publish().
If publishing is configured (the client pasted his own Netlify token into the
app's local settings — it lives ONLY in data/publish.json on his computer,
never anywhere else) and the page's bytes changed since the last push, the
page is zipped as index.html and POSTed to Netlify's deploy API. The site
then serves exactly what the desktop app serves, minutes after ADF&G posts.

Design rules:
  - the token is never logged, never echoed back by any API route;
  - publish only AFTER doctor validation (app.py's refresh order guarantees
    a damaged page is repaired before we are called);
  - skip when the page hash is unchanged (no churn deploys);
  - a network failure never breaks the refresh — recorded, retried next cycle.
"""
import hashlib, io, json, os, ssl, urllib.request, urllib.error, zipfile
import datetime as dt

API = "https://api.netlify.com/api/v1"
TIMEOUT = 60


def _cfg_path(data_dir):
    return os.path.join(data_dir, "publish.json")


def load_cfg(data_dir):
    try:
        return json.load(open(_cfg_path(data_dir), encoding="utf-8"))
    except Exception:
        return {}


def save_cfg(data_dir, cfg):
    p = _cfg_path(data_dir)
    json.dump(cfg, open(p, "w", encoding="utf-8"), indent=1)
    try:
        os.chmod(p, 0o600)
    except Exception:
        pass


def _req(url, token, data=None, ctype=None, method=None, raw=False):
    headers = {"Authorization": "Bearer " + token, "User-Agent": "AlaskaFisheryOpenings"}
    if ctype:
        headers["Content-Type"] = ctype
    r = urllib.request.Request(url, data=data, headers=headers, method=method)
    ctx = ssl.create_default_context()
    with urllib.request.urlopen(r, timeout=TIMEOUT, context=ctx) as resp:
        body = resp.read()
    if raw:
        return body
    return json.loads(body.decode("utf-8", "replace") or "{}")


def resolve_site(token, site_name):
    """Find the site's id from its name (the *.netlify.app subdomain) or
    accept a raw site id / full domain pasted instead."""
    site_name = (site_name or "").strip().lower()
    site_name = site_name.replace("https://", "").replace("http://", "").split("/")[0]
    if site_name.endswith(".netlify.app"):
        site_name = site_name[:-len(".netlify.app")]
    sites = _req(API + "/sites?filter=all", token)
    for s in sites:
        if s.get("name") == site_name or s.get("id") == site_name or \
           (s.get("ssl_url") or "").rstrip("/").endswith(site_name + ".netlify.app"):
            return s["id"], s.get("name"), s.get("ssl_url") or s.get("url")
    raise LookupError(f"no Netlify site named '{site_name}' on this account "
                      f"({len(sites)} sites visible)")


def _page_hash(page_path):
    h = hashlib.sha256()
    with open(page_path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def build_src_zip():
    """Bundle this installation's engine (app.py + engine + pipeline + tests +
    seeds, minus bulky PDFs and runtime) as app-src.zip bytes. Published
    beside the page so the CLOUD refresher always runs THIS engine version —
    the desktop app updating itself updates the cloud too (ledger #83)."""
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        ap = os.path.join(root, "app.py")
        if os.path.exists(ap):
            z.write(ap, "app.py")
        for sub in ("engine", "pipeline", "tests", "seeds"):
            base = os.path.join(root, sub)
            for dp, dns, fns in os.walk(base):
                if "eo_pdfs" in dp:
                    continue
                for fn in fns:
                    if fn.endswith((".pyc",)):
                        continue
                    full = os.path.join(dp, fn)
                    z.write(full, os.path.relpath(full, root).replace(os.sep, "/"))
    return buf.getvalue()


def _engine_version():
    import re as _re
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    try:
        with open(os.path.join(root, "app.py"), encoding="utf-8") as f:
            m = _re.search(r'^VERSION\s*=\s*"([^"]+)"', f.read(), _re.M)
            return m.group(1) if m else "unknown"
    except Exception:
        return "unknown"


def _sha1(b):
    return hashlib.sha1(b).hexdigest()


def extra_files(data_dir):
    """Anything in data/publish_extra/ ships to the site as-is, at the same
    relative path. This is how a DOWNLOAD lives beside the page: a link that
    does not depend on OneDrive, a share, or me being awake (client's ask,
    2026-09-01) — and the file name carries its version, per axiom 33."""
    out = {}
    root = os.path.join(data_dir, "publish_extra")
    if not os.path.isdir(root):
        return out
    for dirpath, _dirs, files in os.walk(root):
        for fn in files:
            full = os.path.join(dirpath, fn)
            rel = os.path.relpath(full, root).replace(os.sep, "/")
            try:
                with open(full, "rb") as f:
                    out["/" + rel] = f.read()
            except Exception:
                pass
    # a plain index so the link is readable by a person, with each file's
    # version (in its name) and its sha256 — axiom 33 on a web page
    downloads = {p: b for p, b in out.items() if p.startswith("/downloads/")
                 and not p.endswith("index.html")}
    if downloads:
        rows = []
        for p in sorted(downloads):
            b = downloads[p]
            rows.append(
                f'<tr><td><a href="{p}">{p.rsplit("/", 1)[-1]}</a></td>'
                f'<td>{len(b)/1048576:.1f} MB</td>'
                f'<td class="sha">{hashlib.sha256(b).hexdigest()[:16]}…</td></tr>')
        out["/downloads/index.html"] = ("""<!doctype html><meta charset="utf-8">
<title>Downloads</title><meta name="viewport" content="width=device-width,initial-scale=1">
<style>body{font:15px/1.5 system-ui,-apple-system,Segoe UI,sans-serif;margin:0;background:#eef1f3;
color:#101d25}main{max-width:720px;margin:0 auto;padding:28px 20px}h1{font-size:21px;margin:0 0 4px}
p{color:#5c6c77;margin:.3em 0 1.3em}table{width:100%;border-collapse:collapse;background:#fff;
border-radius:10px;overflow:hidden;box-shadow:0 1px 2px rgba(0,0,0,.06)}td{padding:11px 14px;
border-top:1px solid #dde5ea}tr:first-child td{border-top:0}a{color:#0b5d78;font-weight:650}
.sha{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:12px;color:#5c6c77}
small{color:#5c6c77;display:block;margin-top:18px}</style>
<main><h1>Current installers</h1>
<p>Always the newest build. The version is in the file name; the program shows
its own version in its window.</p>
<table>""" + "".join(rows) + """</table>
<small>Published """ + dt.datetime.now().strftime("%b %d, %Y %H:%M") + """ from the
Alaska Fishery Openings app. If Windows warns that it does not recognise the
program: More info &rarr; Run anyway.</small></main>""").encode()
    return out


def site_files(token, site_id):
    """What is published on the site right now: {path: sha1}."""
    try:
        listing = _req(f"{API}/sites/{site_id}/files", token)
    except Exception:
        return {}
    out = {}
    for f in listing or []:
        p, sha = f.get("id") or f.get("path"), f.get("sha")
        if p and sha:
            out[p if p.startswith("/") else "/" + p] = sha
    return out


def publish(page_path, token, site_id, include_src=True, src_bytes=None, extra=None):
    """Deploy the site by DIGEST, not by zip.

    A zip deploy replaces the whole site, so every deploy silently deleted any
    file it did not itself contain — which meant a download published from this
    desktop would be wiped by the next cloud refresh two hours later. The digest
    API takes a manifest of sha1s: files already on the site are simply named
    and never re-uploaded, so anything under /downloads/ CARRIES FORWARD for
    free, from either publisher, forever. Only genuinely new bytes go over the
    wire.
    """
    with open(page_path, "rb") as f:
        page = f.read()
    payload = {"/index.html": page}
    if include_src:
        payload["/app-src.zip"] = src_bytes if src_bytes is not None else build_src_zip()
        # a few bytes the cloud refresher reads every run, so it downloads the
        # 7 MB engine only when it is actually newer (ledger #264: bandwidth
        # is billed too)
        payload["/engine.txt"] = (_engine_version() + "\n").encode()
    for k, v in (extra or {}).items():
        payload[k if k.startswith("/") else "/" + k] = v

    manifest = {p: _sha1(b) for p, b in payload.items()}
    # carry forward everything already published that we are not replacing
    for p, sha in site_files(token, site_id).items():
        manifest.setdefault(p, sha)

    dep = _req(f"{API}/sites/{site_id}/deploys", token,
               data=json.dumps({"files": manifest}).encode(),
               ctype="application/json", method="POST")
    dep_id = dep.get("id")
    required = set(dep.get("required") or [])
    uploaded = 0
    for p, b in payload.items():
        if _sha1(b) in required:
            _req(f"{API}/deploys/{dep_id}/files{p}", token, data=b,
                 ctype="application/octet-stream", method="PUT", raw=True)
            uploaded += 1
    return {"deploy_id": dep_id, "state": dep.get("state"),
            "url": dep.get("ssl_url") or dep.get("url"),
            "files": len(manifest), "uploaded": uploaded}


def _vt(v):
    import re as _re
    return tuple(int(x) for x in _re.findall(r"\d+", v or "")[:3]) or (0,)


def shell_marker(data_dir, today=None):
    """What the public site must hold for this build's CHART to be live:
    "<shell id>\n<ISO week, UTC>\n<engine version>\n". The shell id names the
    engine and the geometry, never the statuses. None when this build wrote
    no shell.json (an older pipeline)."""
    try:
        with open(os.path.join(data_dir, "shell.json"), encoding="utf-8") as f:
            sh = json.load(f)
    except Exception:
        return None
    d = today or dt.datetime.now(dt.timezone.utc).date()
    y, w, _ = d.isocalendar()
    return f"{sh.get('shell')}\n{y}-W{w:02d}\n{_engine_version()}\n".encode()


def _site_text(url):
    """('ok', text) | ('missing', None) | ('error', None) for a small public file."""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "AlaskaFisheryOpenings"})
        with urllib.request.urlopen(req, timeout=30, context=ssl.create_default_context()) as r:
            return "ok", r.read(512).decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return ("missing", None) if e.code == 404 else ("error", None)
    except Exception:
        return "error", None


def chart_decision(local, site_state, site_text):
    """Deploy the chart? -> (bool, reason). Pure, so it is tested directly.

    THE NEWS NEVER REDEPLOYS THE SITE, AND TWO PUBLISHERS NEVER TAKE TURNS
    (ledger #264, red team). The desktop app and the cloud refresher both
    publish. Deploy when the site has no chart marker, when this engine is
    newer than the site's, or when the ISO week (UTC, the same for both) has
    turned. Never over a newer engine; never when the site cannot be read
    (an outage must not turn into a deploy every run)."""
    ls, lw, lv = (local.decode().split("\n") + ["", "", ""])[:3]
    if site_state == "error":
        return False, "could not read the site's chart marker; not deploying"
    if site_state == "missing" or not site_text:
        return True, "the site has no chart marker"
    ss, sw, sv = (site_text.split("\n") + ["", "", ""])[:3]
    if _vt(sv) > _vt(lv):
        return False, f"the site carries a newer engine ({sv})"
    if _vt(lv) > _vt(sv):
        return True, f"a newer engine ({lv} over {sv or 'unversioned'})"
    if lw != sw:
        return True, "the weekly chart snapshot"
    return False, "chart unchanged (the news rides in the overlay)" if ss == ls else \
        "same engine, same week: the chart waits for the week to turn"


def maybe_publish(data_dir, page_path, log=print, today=None, site_text=None):
    """Called after every successful refresh. Publishes when configured and
    the CHART is due (chart_decision). Never raises.

    Every refresh used to change the page (its as-of stamp at least), so every
    refresh was a Netlify production deploy — fifteen credits each, three
    hundred a month on the free plan, and the site pauses when they run out.
    Statuses now travel in the overlay the cloud refresher keeps off Netlify.
    """
    cfg = load_cfg(data_dir)
    if not cfg.get("enabled") or not cfg.get("token") or not cfg.get("site_id"):
        return {"published": False, "reason": "not configured"}
    try:
        marker = shell_marker(data_dir, today)
        if marker is not None:
            st, txt = site_text if site_text is not None else \
                _site_text((cfg.get("site_url") or "").rstrip("/") + "/shell.txt")
            go, why = chart_decision(marker, st, txt)
            if not go:
                return {"published": False, "reason": why}
            extra = dict(extra_files(data_dir))
            extra["/shell.txt"] = marker
            res = publish(page_path, cfg["token"], cfg["site_id"], extra=extra)
            cfg["last_shell"] = marker.decode().strip()
            cfg["last_publish"] = dt.datetime.now().isoformat(timespec="seconds")
            cfg["last_result"] = {"ok": True, **res}
            save_cfg(data_dir, cfg)
            log(f"published the chart ({why}) to {res.get('url')} (deploy {res.get('deploy_id')})")
            return {"published": True, "why": why, **res}
        ph = _page_hash(page_path)
        if ph == cfg.get("last_hash"):
            return {"published": False, "reason": "page unchanged"}
        res = publish(page_path, cfg["token"], cfg["site_id"], extra=extra_files(data_dir))
        cfg["last_hash"] = ph
        cfg["last_publish"] = dt.datetime.now().isoformat(timespec="seconds")
        cfg["last_result"] = {"ok": True, **res}
        save_cfg(data_dir, cfg)
        log(f"published to {res.get('url')} (deploy {res.get('deploy_id')}, {res.get('state')})")
        return {"published": True, **res}
    except Exception as e:                       # network trouble must never
        cfg["last_result"] = {"ok": False, "error": str(e)[:300]}   # break refresh
        try:
            save_cfg(data_dir, cfg)
        except Exception:
            pass
        log("publish failed (will retry next refresh):", e)
        return {"published": False, "reason": str(e)[:300]}


def status(data_dir):
    """Safe-to-show status: NEVER includes the token."""
    cfg = load_cfg(data_dir)
    return {"enabled": bool(cfg.get("enabled")),
            "configured": bool(cfg.get("token") and cfg.get("site_id")),
            "site_name": cfg.get("site_name"), "site_url": cfg.get("site_url"),
            "last_publish": cfg.get("last_publish"),
            "last_result": cfg.get("last_result")}


def configure(data_dir, token, site_name):
    """Validate the token by resolving the site, then store. Returns status."""
    site_id, name, url = resolve_site(token, site_name)
    cfg = load_cfg(data_dir)
    cfg.update({"enabled": True, "token": token, "site_id": site_id,
                "site_name": name, "site_url": url, "last_hash": None})
    save_cfg(data_dir, cfg)
    return status(data_dir)


def disable(data_dir):
    cfg = load_cfg(data_dir)
    cfg["enabled"] = False
    save_cfg(data_dir, cfg)
    return status(data_dir)
