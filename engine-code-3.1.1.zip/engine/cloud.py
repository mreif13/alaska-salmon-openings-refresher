#!/usr/bin/env python3
"""THE CLOUD REFRESHER, CARRIED BY THE ENGINE (ledger #264).

The GitHub workflow runs a tiny bootstrap (ci_refresh.py) that unpacks the
newest engine and calls this. Everything that decides what the public page
says lives here, so the repo itself almost never needs touching.

One run:
  1. Seed a fresh data folder exactly as the desktop app does on first start,
     then lay the refresher's own held state on top (every announcement it has
     ever ingested, with its words; the PDFs Southeast is re-derived from; the
     disposition ledger) — so a release that has scrolled off ADF&G's listing
     never drops off the chart.
  2. One refresh, the desktop's own code path: fetch ADF&G, top up words,
     re-derive anything parsed by an older grammar, rebuild, doctor, self-audit.
  3. The ship gates the old refresher ran, plus the every-claim cases. A red
     gate publishes NOTHING — the page keeps saying what it said.
  4. Write the state back, and the overlay (statuses, pocket notes, the
     not-on-this-chart line) — but only when it says something new, or once an
     hour so the page can show when it was last checked.
  5. Deploy the CHART to Netlify only when it changed (engine or geometry) or
     once a week. The news never costs a deploy.

Exit 0 = ran green (whether or not anything changed). The workflow commits the
state folder when `state/.commit` says yes.

usage: python engine/cloud.py --state STATE_DIR [--site NAME] [--no-deploy]
env:   NETLIFY_AUTH_TOKEN   (deploys are skipped without it)
       AFO_HEARTBEAT_MIN    (default 55)
"""
import argparse
import datetime as dt
import glob
import json
import os
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)

# what the refresher keeps between runs (relative to the data folder)
KEEP_DIRS = ("raw", "areas", "eo_pdfs")
KEEP_FILES = ("dispositions.json", "ingest_manifest.json", "listing_snapshot.json",
              "selfaudit.json")
# fields that change every run without saying anything new
VOLATILE = ("as_of", "checked_at", "generated", "engine")
GATES = ("data_gate", "partial_floor_gate", "feature_floor_gate", "stale_status_gate",
         "future_open_gate", "page_engine_gate", "every_claim_gate")


def log(*a):
    print("[cloud]", *a, flush=True)


def _copytree_over(src, dst):
    """Copy every file under src into dst, overwriting (never deleting)."""
    n = 0
    for dp, _dns, fns in os.walk(src):
        rel = os.path.relpath(dp, src)
        os.makedirs(os.path.join(dst, rel), exist_ok=True)
        for fn in fns:
            shutil.copy2(os.path.join(dp, fn), os.path.join(dst, rel, fn))
            n += 1
    return n


def _content(ov):
    """An overlay with the fields that change every run removed."""
    o = {k: v for k, v in (ov or {}).items() if k not in VOLATILE}
    regs = {}
    for k, R in (o.get("regions") or {}).items():
        regs[k] = {x: y for x, y in R.items() if x not in VOLATILE}
    o["regions"] = regs
    return json.dumps(o, sort_keys=True, separators=(",", ":"))


def _load(p):
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def restore(state, data):
    """Lay the held state over a freshly seeded data folder."""
    held = os.path.join(state, "held")
    n = 0
    if os.path.isdir(held):
        for d in KEEP_DIRS:
            if os.path.isdir(os.path.join(held, d)):
                n += _copytree_over(os.path.join(held, d), os.path.join(data, d))
        for f in KEEP_FILES:
            if os.path.exists(os.path.join(held, f)):
                shutil.copy2(os.path.join(held, f), os.path.join(data, f))
                n += 1
    return n


def save(state, data, prune_pdf_days=150):
    held = os.path.join(state, "held")
    os.makedirs(held, exist_ok=True)
    for d in KEEP_DIRS:
        src = os.path.join(data, d)
        if os.path.isdir(src):
            dst = os.path.join(held, d)
            if os.path.isdir(dst):
                shutil.rmtree(dst)
            shutil.copytree(src, dst)
    for f in KEEP_FILES:
        if os.path.exists(os.path.join(data, f)):
            shutil.copy2(os.path.join(data, f), os.path.join(held, f))
    # PDFs are kept for re-deriving Southeast; an old season's are not needed.
    # Age is the announcement's own publication date (a git checkout gives
    # every file the same new mtime, so mtime would never prune anything).
    cut = (dt.datetime.now() - dt.timedelta(days=prune_pdf_days)).isoformat(timespec="minutes")
    for p in glob.glob(os.path.join(held, "eo_pdfs", "*.pdf")):
        rid = os.path.basename(p)[:-4]
        rec = _load(os.path.join(held, "raw", rid + ".json")) or \
            _load(os.path.join(held, "areas", rid + ".json")) or {}
        pub = str(rec.get("published") or "")
        if pub and pub < cut:
            try:
                os.remove(p)
            except Exception:
                pass


SITE_URL = "https://{site}.netlify.app"


def _tree_hash(root):
    """What the held state SAYS, not when it was last written: the run's own
    timestamps (the ledger's checked_at, the self-audit's run record) are left
    out, or every run would commit (red team)."""
    import hashlib
    h = hashlib.sha256()
    if os.path.isdir(root):
        for dp, dns, fns in sorted(os.walk(root)):
            dns.sort()
            for fn in sorted(fns):
                p = os.path.join(dp, fn)
                rel = os.path.relpath(p, root)
                if rel == "selfaudit.json":
                    continue
                h.update(rel.encode())
                with open(p, "rb") as f:
                    b = f.read()
                if rel == "dispositions.json":
                    try:
                        d = json.loads(b)
                        d.pop("checked_at", None)
                        b = json.dumps(d, sort_keys=True).encode()
                    except Exception:
                        pass
                h.update(hashlib.sha256(b).digest())
    return h.hexdigest()


def run_gates():
    sys.path.insert(0, os.path.join(APP, "tests"))
    import test_all
    out = []
    for g in GATES:
        fn = getattr(test_all, g, None)
        if fn is None:
            continue
        try:
            r = fn()
        except Exception as e:
            r = {"name": g, "ok": False, "detail": f"error: {e}"}
        out.append(r)
        log(("PASS" if r.get("ok") else "FAIL"), r.get("name"), "-", str(r.get("detail"))[:200])
    return out


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--state", required=True)
    ap.add_argument("--site", default=os.environ.get("NETLIFY_SITE", "alaska-salmon-openings"))
    ap.add_argument("--no-deploy", action="store_true")
    ap.add_argument("--offline-listing", help="tests: a saved ADF&G listing page instead of the network")
    a = ap.parse_args(argv)
    state = os.path.abspath(a.state)
    os.makedirs(state, exist_ok=True)
    commit_flag = os.path.join(state, ".commit")
    # a newer engine the bootstrap fetched is kept even if this run goes no
    # further, or every failed run would download it again (red team)
    with open(commit_flag, "w") as f:
        f.write("yes\n" if os.environ.get("AFO_ENGINE_CACHED") else "no\n")
    # ADF&G's times are Alaska times, and every naive clock in the engine
    # (as-of, the 14-day cut, weekly slots) must read Alaska, not the runner's UTC
    os.environ["TZ"] = "America/Anchorage"
    try:
        import time as _t
        _t.tzset()
    except Exception:
        pass

    # the desktop app's own code, run headless against a fresh data folder
    os.environ.setdefault("AFO_CHECKED_AT", dt.datetime.now().isoformat(timespec="minutes"))
    sys.path.insert(0, APP)
    import app                                   # binds nothing: main() is not called
    data = app.DATA
    if os.path.isdir(data):
        shutil.rmtree(data)
    os.makedirs(data)
    app._seed()
    n = restore(state, data)
    log(f"seeded from the engine; {n} held file(s) laid over it")

    if a.offline_listing:
        _listing = open(a.offline_listing, encoding="utf-8", errors="replace").read()
        _run = app.fetch_detect.run
        app.fetch_detect.run = lambda d, **k: _run(d, offline_listing=_listing, **k)
        app.fetch_detect.backfill_full_text = lambda d, **k: {"filled": 0, "tried": 0, "remaining": 0}
    res = app.refresh(force_rebuild=True)
    log("refresh:", json.dumps({k: res.get(k) for k in ("ok", "new", "ingested", "rebuilt", "reason")}))
    if not res.get("ok"):
        # ADF&G unreachable or the listing unreadable: nothing new is known,
        # so nothing is written — the page keeps its last word and its age
        log("refresh did not complete; publishing nothing")
        return 2

    gates = run_gates()
    if not all(g.get("ok") for g in gates):
        log("a ship gate is red; publishing nothing")
        return 3

    before = _tree_hash(os.path.join(state, "held"))
    save(state, data)
    held_moved = _tree_hash(os.path.join(state, "held")) != before

    # THE CHART FIRST, THEN THE NEWS (red team, ledger #264): an overlay built
    # for a chart the site does not carry is rejected by every visitor's page,
    # so the chart is deployed (when due) before the overlay is published, and
    # an overlay for a chart that is not live is never published.
    token = os.environ.get("NETLIFY_AUTH_TOKEN", "").strip()
    import publisher
    if a.no_deploy or not token:
        log("chart deploy skipped (" + ("--no-deploy" if a.no_deploy else "no token") + ")")
    else:
        try:
            publisher.configure(data, token, a.site)
            r = publisher.maybe_publish(data, os.path.join(data, "SE_Openings.html"), log=log)
            log("chart:", r.get("why") or r.get("reason") or "deployed")
        except Exception as e:
            log("chart deploy failed:", str(e)[:200])
        finally:
            # the token must never be committed with the state
            try:
                os.remove(os.path.join(data, "publish.json"))
            except Exception:
                pass
    shell = (_load(os.path.join(data, "shell.json")) or {}).get("shell")
    live_ok = True
    if not a.no_deploy:
        st, txt = publisher._site_text(SITE_URL.format(site=a.site) + "/shell.txt")
        if st == "ok" and txt and txt.split("\n")[0] != shell:
            live_ok = False
            log(f"the live chart is {txt.split(chr(10))[0]}, this overlay is for {shell}: "
                "the news is NOT published until the chart is deployed")

    new_ov = _load(os.path.join(data, "overlay.json"))
    old_ov = _load(os.path.join(state, "overlay.json"))
    changed = new_ov is not None and (old_ov is None or _content(new_ov) != _content(old_ov))
    beat = False
    if new_ov is not None and not changed:
        try:
            last = dt.datetime.fromisoformat(str(old_ov.get("checked_at"))[:16])
            beat = (dt.datetime.now() - last).total_seconds() >= 60 * int(os.environ.get("AFO_HEARTBEAT_MIN", "55"))
        except Exception:
            beat = True
    wrote = False
    if live_ok and (changed or beat):
        shutil.copy2(os.path.join(data, "overlay.json"), os.path.join(state, "overlay.json"))
        wrote = True
        log("overlay:", "NEW NEWS" if changed else "heartbeat")
    elif live_ok:
        log("overlay: nothing new this run")
    if wrote or held_moved or os.environ.get("AFO_ENGINE_CACHED"):
        with open(commit_flag, "w") as f:
            f.write("yes\n")
    return 0 if live_ok else 4


if __name__ == "__main__":
    sys.exit(main())
