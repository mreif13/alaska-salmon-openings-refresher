"""EVERY CLAIM, MEASURED — regression cases for the 2026-10-15 measurement (ledger #264).

A pre-registered, blind, two-reader check of 197 opening statements against
ADF&G's own words found twelve causes of wrong or missing claims (A-L). Each
case below reproduces one cause from the shipped fixtures and the built data,
and fails on engine 3.0.5. A fix that regresses brings its case back to red.

Synthetic text is used only where a fixture does not carry the wording; it is
marked SYNTHETIC and paraphrases the announcement's structure, not its words.

Run standalone (python tests/every_claim.py) or as gate 21 of test_all.py.
"""
import copy
import datetime as dt
import glob
import json
import os
import shutil
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
for p in (os.path.join(ROOT, "engine"), os.path.join(ROOT, "pipeline")):
    if p not in sys.path:
        sys.path.insert(0, p)
FX = os.path.join(HERE, "fixtures")
DATA = os.path.join(ROOT, "data")


def _fx(sub, rid):
    with open(os.path.join(FX, sub, rid + ".txt"), encoding="utf-8") as f:
        return f.read()


def _j(p):
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def _units(rid):
    import openparse
    return openparse.parse(_fx("nseo_live", rid), rid).get("units") or []


def _area_status(region, rids, now):
    """The status one area shows at `now`, from the held records `rids`."""
    from areastatus import apply_area
    rd = _j(os.path.join(DATA, "regions_data.json"))
    blk = copy.deepcopy(rd["regions"][region])
    blk["status"] = {}
    rels = []
    for rid in rids:
        p = os.path.join(DATA, "areas", rid + ".json")
        rels.append(_j(p))
    apply_area(region, blk, rels, now)
    return blk.get("status") or {}


def _se_status(rid, now):
    from restatus import recompute_status
    se = _j(os.path.join(DATA, "se_openings_data.json"))
    ad = _j(os.path.join(DATA, "app_data.json"))
    rel = [r for r in ad["releases"] if str(r.get("id")) == rid]
    st, notes = recompute_status(se["sections"], rel, now)
    notes = list(notes.values()) if isinstance(notes, dict) else list(notes)
    return st, notes


# ------------------------------------------------------------------ the cases
def case_A_held_records_heal():
    """Kodiak #42 shipped placing 1 of its 16 units, with no words to re-read."""
    import reparse
    d = tempfile.mkdtemp(prefix="ec_A_")
    try:
        os.makedirs(os.path.join(d, "areas")); os.makedirs(os.path.join(d, "raw"))
        shutil.copy(os.path.join(ROOT, "seeds", "areas", "1830439489.json"), os.path.join(d, "areas"))
        reparse.run(d, log=lambda *a: None)
        n = len(_j(os.path.join(d, "areas", "1830439489.json")).get("units") or [])
        return n >= 16, f"Kodiak #42 holds {n} units after the re-read (16 stated)"
    finally:
        shutil.rmtree(d, ignore_errors=True)


def case_A_never_more_open():
    """A re-parse that keeps the sections but loses their carve-outs is refused."""
    import reparse
    if not hasattr(reparse, "_more_open"):
        return False, "no rule refuses a re-parse that opens what was partial"
    old = {"areas": [{"section": "13-A", "district": "13", "status": "partial", "rules": [{"subject": "x"}]}]}
    new = {"areas": [{"section": "13-A", "district": "13", "status": "open", "rules": []}]}
    pocket = {"areas": [{"tha_pocket": "Crawfish Inlet", "status": "open", "rules": [{"subject": "x"}]}]}
    region = {"areas": [{"region_wide": True, "status": "open"}]}
    a = reparse._more_open(old, new, "raw")
    b = reparse._more_open(pocket, region, "raw")
    # red team: a bounded CLOSURE window must not pass as a corrected opening
    clo = "will be closed from 6:00 p.m. Friday, August 28 until 6:00 a.m. Monday, August 31"
    c = reparse._more_open({"units": [{"name": "X District", "status": "closed", "period_text": clo}]},
                           {"units": [{"name": "X District", "status": "open", "period_text": clo}]}, "areas")
    return bool(a and b and c), (f"partial->open refused: {bool(a)}; pocket->region-wide refused: {bool(b)}; "
                                 f"closed->open on a closure's window refused: {bool(c)}")


def case_B_misfiled_release_rerouted():
    """PWS, Kodiak and Yakutat releases filed in raw/ reached no chart."""
    import reparse
    d = tempfile.mkdtemp(prefix="ec_B_")
    try:
        os.makedirs(os.path.join(d, "areas")); os.makedirs(os.path.join(d, "raw"))
        rec = {"release_id": "9000000001", "region": "Prince William Sound", "areas": [],
               "published": "2026-08-25T10:00", "full_text": _fx("nseo_live", "1830286679")}
        with open(os.path.join(d, "raw", "9000000001.json"), "w", encoding="utf-8") as f:
            json.dump(rec, f)
        reparse.run(d, log=lambda *a: None)
        moved = os.path.exists(os.path.join(d, "areas", "9000000001.json"))
        return moved, ("re-routed to the area parser" if moved else "still filed as Southeast")
    finally:
        shutil.rmtree(d, ignore_errors=True)


def case_C_salmon_without_the_word():
    """SYNTHETIC headings: a drift gillnet extension in a terminal harvest area names no species."""
    import openparse
    if not hasattr(openparse, "is_commercial_salmon"):
        return False, "the salmon test is the word 'salmon'"
    gn = ("DISTRICT 11 DRIFT GILLNET FISHERY EXTENSION IN SPEEL ARM TERMINAL HARVEST AREA. "
          "The drift gillnet fishery in the Speel Arm Terminal Harvest Area will be extended.")
    hr = ("SITKA SOUND SAC ROE HERRING FISHERY. The purse seine fishery in District 13 "
          "will open for herring.")
    a, b = openparse.is_commercial_salmon(gn), openparse.is_commercial_salmon(hr)
    return a and not b, f"gillnet extension -> {a}; herring -> {b}"


def case_D_pocket_windows():
    """Carroll Inlet lists several windows; Little Port Walter is open all June."""
    out, ok = [], True
    for rid, now, want in (("1768115624", "2026-06-09T12:00", ("open", "partial")),
                           ("1767371202", "2026-06-10T12:00", ("open", "partial"))):
        _st, notes = _se_status(rid, now)
        got = [n.get("status") for n in notes if str(n.get("rel")) == rid]
        good = bool(got) and all(g in want for g in got)
        ok = ok and good
        out.append(f"{rid}@{now[5:10]}: {got or 'no note'}")
    return ok, "; ".join(out)


def case_D_pocket_schedules():
    """Found by the adversarial diff: a weekly THA schedule read as open every
    day of its season; "unless closed by emergency order" read as a closure;
    "will NOT OPEN" and an "effective" closure instant dropped the note."""
    out, ok = [], True
    for rid, now, want_status, want_gear in (
            ("1825557305", "2026-08-24T12:00", ("open", "partial"), "drift gillnet"),   # a Monday
            ("1825557305", "2026-08-22T12:00", ("open", "partial"), "troll"),           # a Saturday
            ("1767666157", "2026-06-03T12:00", ("upcoming",), "troll"),
            ("1768070800", "2026-06-03T12:00", ("closed",), None)):
        _st, notes = _se_status(rid, now)
        got = [(n.get("status"), n.get("gear")) for n in notes if str(n.get("rel")) == rid]
        good = len(got) == 1 and got[0][0] in want_status and (want_gear is None or got[0][1] == want_gear)
        ok = ok and good
        out.append(f"{rid}@{now[5:10]}: {got or 'no note'}")
    return ok, "; ".join(out)


def case_D_newer_release_governs():
    """Red team: an older pocket opener must not outlive a newer release that
    closes now and reopens later ("open again" or "reopen")."""
    import restatus
    rel = lambda i: {"id": i, "gear": ["troll"], "emergency_order": None, "url": None, "title": "X Bay THA"}
    a_old = {"status": "open", "starts": "2026-06-01T00:01:00", "ends": "2026-09-20T23:59:00",
             "period_text": "The X Bay THA troll fishery will be open from 12:01 a.m., Monday, June 1, "
                            "through 11:59 p.m., Sunday, September 20, 2026."}
    out, ok = [], True
    for word in ("open again", "reopen"):
        a_new = {"status": "partial", "starts": None, "ends": None,
                 "period_text": f"The X Bay THA will close to troll gear at 12:01 a.m., Wednesday, August 12, "
                                f"and will {word} from 12:01 a.m., Thursday, August 20, through 11:59 p.m., "
                                f"Sunday, September 20, 2026."}
        items = [("2026-05-01T00:00", rel("A"), a_old, "X Bay"), ("2026-08-10T00:00", rel("B"), a_new, "X Bay")]
        n1 = restatus._pocket_note(items, "2026-08-15T12:00")
        n2 = restatus._pocket_note(items, "2026-08-21T12:00")
        good = (n1 or {}).get("status") in ("upcoming", "closed") and (n2 or {}).get("status") in ("open", "partial")
        ok = ok and good
        out.append(f"{word}: Aug 15 {(n1 or {}).get('status')}, Aug 21 {(n2 or {}).get('status')}")
    return ok, "; ".join(out)


def case_E_daily_run():
    """PWS #42: 'daily 12-hour periods ... Friday through Monday' kept as one day."""
    from timemodel import parse_windows, weekly_pattern
    u = [x for x in _units("1831556004") if x["name"] == "Montague District"]
    if not u:
        return False, "Montague District not parsed"
    t = u[0].get("period_text") or ""
    w = parse_windows(t, 2026)
    spec = weekly_pattern(t)
    ok = len(w) == 4 and w[-1] == ("2026-08-31T08:00:00", "2026-08-31T20:00:00") and bool(spec)
    return ok, f"{len(w)} daily window(s), last {w[-1] if w else None}; recurrence {bool(spec)}"


def case_F_two_periods():
    """Kotzebue: two 8-hour periods in one bullet list."""
    from timemodel import parse_windows
    u = [x for x in _units("1832249515") if x["name"] == "Kotzebue District"]
    w = parse_windows(u[0].get("period_text") or "", 2026) if u else []
    return len(w) >= 2, f"{len(w)} window(s): {w}"


def case_G_closed_now_open_later():
    """PWS #41: remains closed this week, opens Monday — the opening was dropped."""
    st = _area_status("PWS", ["1831020199"], dt.datetime(2026, 8, 29, 12, 0))
    dg = st.get("drift gillnet") or {}
    cr = [v.get("status") for v in dg.values() if (v.get("unit_name") or "").startswith("Copper River")]
    ok = bool(cr) and all(s == "upcoming" for s in cr)
    return ok, f"Copper River District drift gillnet on Aug 29: {sorted(set(cr)) or 'absent'}"


def case_H_duration():
    """'will open at 7:00 am Monday, August 31 for a 12-hour period' has an end."""
    from timemodel import parse_period
    r = parse_period("will open at 7:00 am on Monday, August 31 for a 12-hour commercial "
                     "drift gillnet fishing period", 2026)
    end = r[1] if isinstance(r, (list, tuple)) and len(r) > 1 else None
    return str(end or "").startswith("2026-08-31T19:00"), f"end {end}"


def case_I_river_after_district():
    """Yakutat: Kaliakh River fishes Sep 2-3, after the Yakataga District closes."""
    st = _area_status("Yakutat", ["1831725647"], dt.datetime(2026, 9, 3, 12, 0))
    sg = st.get("set gillnet") or {}
    yk = [(c, v.get("status")) for c, v in sg.items()
          if "kaliakh" in json.dumps(v, default=str).lower()]
    ok = any(s in ("open", "partial") for _c, s in yk)
    return ok, f"Sep 3 noon, Kaliakh-bearing units: {yk[:4] or 'none'}"


def case_J_norton_sound():
    """Norton Sound #19: five subdistrict bullets placed nothing — and must
    never paint Nome (Subdistrict 1), which it does not open (red team)."""
    names = sorted(x["name"] for x in _units("1830021593") if x["name"].startswith("Norton Sound"))
    want = [f"Norton Sound Subdistrict {n}" for n in range(2, 7)]
    st = _area_status("AYK", ["1830021593"], dt.datetime(2026, 8, 29, 12, 0))
    nome = [v.get("status") for g in st.values() for c, v in g.items() if c == "33310"]
    une = [v.get("status") for g in st.values() for c, v in g.items() if c == "33360"]
    ok = names == want and not nome and une and all(s == "open" for s in une)
    return ok, f"units {names}; Nome {nome or 'untouched'}; Unalakleet {une}"


def _unread_at(now):
    """The page's not-on-this-chart bar at a given clock, computed by the page
    builder's own functions (lifted out of build_app.py without running it)."""
    import ast
    src = open(os.path.join(ROOT, "pipeline", "build_app.py"), encoding="utf-8").read()
    want = {"_on_chart_ids", "_record_current", "_pretty_date", "_unread_announcements", "_read_record"}
    tree = ast.parse(src)
    mod = ast.Module(body=[n for n in tree.body if isinstance(n, (ast.Import, ast.ImportFrom))
                           or (isinstance(n, ast.FunctionDef) and n.name in want)], type_ignores=[])
    ns = {"__name__": "every_claim_unread", "UNREAD_ALL": []}
    cwd = os.getcwd()
    try:
        os.chdir(DATA)
        exec(compile(mod, "build_app.py", "exec"), ns)
        return {c["id"]: c["name"] for c in ns["_unread_announcements"](now)}, ns["_on_chart_ids"]()
    finally:
        os.chdir(cwd)


def case_B_J_surfaced():
    """A release on no chart is NAMED in the bar at publication + 1 hour:
    PWS #38 and Yakutat (filed as Southeast), Lower Cook Inlet #19 (no map).
    Judged by release, not by the words of its name: once the refresher has a
    release's words it may be re-routed and placed, and its name read from its
    letterhead — on the chart or named in the bar, never neither."""
    out, ok = [], True
    for rid, now in (("1828798898", "2026-08-21T13:30"), ("1828817395", "2026-08-21T13:30"),
                     ("1831806203", "2026-08-28T15:00")):
        named, placed = _unread_at(now)
        good = rid in named or rid in placed
        ok = ok and good
        out.append(f"{rid}: " + (named.get(rid) or ("on the chart" if rid in placed else "NEITHER")))
    return ok, "; ".join(out)


def case_K_eastern_district():
    """PWS #42: 'Waters of the Eastern District, waters south of ...' was not read."""
    u = [x for x in _units("1831556004") if x["name"] == "Eastern District"]
    ok = bool(u) and u[0]["status"] == "partial"
    return ok, (f"Eastern District {u[0]['status']}" if u else "Eastern District absent")


def case_L_pocket_closure():
    """Seine Aug 20: 'Redoubt Bay, Kanga Bay' (in 13-B) closed all of District 13."""
    st, _n = _se_status("1828612329", "2026-08-22T12:00")
    ps = st.get("purse seine") or {}
    c13 = (ps.get("13-C") or {})
    b13 = (ps.get("13-B") or {})
    wrong = str(c13.get("rel")) == "1828612329" and c13.get("status") == "closed"
    carried = any("Redoubt" in (r.get("subject") or r.get("text") or "") for r in (b13.get("rules") or []))
    return (not wrong) and carried, f"13-C closed by it: {wrong}; 13-B carries Redoubt/Kanga: {carried}"


def case_M_one_sentence_period():
    """Found by the adversarial diff (not in the sample): Kodiak #43's
    "78-hour ... period ... in the Inner and Outer Ugak Bay Sections" placed nothing."""
    names = {x["name"] for x in _units("1831326732")}
    ok = {"Inner Ugak Bay", "Outer Ugak Bay"} <= names
    return ok, f"Ugak sections parsed: {sorted(n for n in names if 'Ugak' in n) or 'none'}"


CASES = [case_A_held_records_heal, case_A_never_more_open, case_B_misfiled_release_rerouted,
         case_C_salmon_without_the_word, case_D_pocket_windows, case_D_pocket_schedules, case_D_newer_release_governs, case_E_daily_run, case_F_two_periods,
         case_G_closed_now_open_later, case_H_duration, case_I_river_after_district,
         case_J_norton_sound, case_B_J_surfaced, case_K_eastern_district, case_L_pocket_closure,
         case_M_one_sentence_period]


def run():
    out = []
    for c in CASES:
        try:
            ok, detail = c()
        except Exception as e:
            ok, detail = False, f"error: {type(e).__name__}: {e}"
        out.append({"case": c.__name__[5:], "ok": bool(ok), "detail": detail})
    return out


def gate():
    name = "every claim, measured: the twelve causes (and one found after) stay fixed (ledger #264)"
    if not os.path.exists(os.path.join(DATA, "regions_data.json")):
        return {"name": name, "ok": False, "detail": "no built data/ to check against"}
    res = run()
    bad = [r for r in res if not r["ok"]]
    return {"name": name, "ok": not bad,
            "detail": (f"{len(res)} cases, all hold" if not bad else
                       "; ".join(f"{r['case']}: {r['detail']}" for r in bad[:4]))}


if __name__ == "__main__":
    res = run()
    for r in res:
        print(("PASS" if r["ok"] else "FAIL"), r["case"], "—", r["detail"])
    print(f"{sum(r['ok'] for r in res)}/{len(res)}")
    sys.exit(0 if all(r["ok"] for r in res) else 1)
