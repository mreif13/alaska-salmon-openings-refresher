"""Refresh the openings map's STATUS layer without re-reading the raw geometry.

The regulation geometry (section polygons, permanent closed waters) is static —
it is shipped once, baked into the built page, and does not change when a new
announcement posts. Only the open/closed/partial STATUS of each section, and the
in-season closure rules, change. So on refresh we reuse the geometry already in
`se_openings_data.json` (extracted once from the shipped page) and recompute only
the status from the freshly-built `app_data.json`.

This is what lets the standalone app ship WITHOUT the ~11 MB of source geojson:
the geometry travels once, in the page. `prep.py` (which builds the geometry from
geojson) remains the tool of record for first construction; this is its
runtime-refresh twin. The status logic is a faithful port of prep.py's.
"""
import json, os
from collections import Counter
from datetime import datetime
from timemodel import tha_name

GEARS = ["purse seine", "drift gillnet", "troll"]


def dist_name(d):
    if d is None:
        return None
    d = str(d)
    if d.startswith("District"):
        return d
    if d.isdigit():
        return "District " + d
    return d


def recompute_status(sections, releases, now):
    secs_by_dist = {}
    for code, s in sections.items():
        secs_by_dist.setdefault(s.get("district_name"), []).append(code)
    status = {g: {} for g in GEARS}
    tha_notes = {}                          # pocket name -> newest words-only advisory
    tha_items = {}                          # pocket key -> every statement about it
    pocket_closures = {}                    # (release, district) -> named closed waters

    def consider(rel, gear):
        if gear not in (rel.get("gear") or []):
            # a THA pocket advisory ("closed to ALL common property commercial
            # salmon fisheries") often names no gear — it applies to every
            # gear; let it through so its note is collected (deduped by name)
            if not any(a.get("tha_pocket") for a in rel.get("areas") or []):
                return
        pub = rel.get("published") or ""
        tha = tha_name(rel)
        for a in rel.get("areas", []):
            st = a.get("status"); ts = a.get("time_state")
            if st not in ("open", "closed", "partial"):
                continue
            # an ENDED opening is not an opening: SE fisheries open by
            # per-period EO, and once the window passes those waters are closed
            # to that gear until a new EO says otherwise. Leaving 13-B "partly
            # open until Aug 23" on Aug 30 is a wrong opening a week stale.
            # (The words and drawn lines stay — the captain sees WHAT expired.)
            # THE CLOCK IS THE AUTHORITY, NEVER A LABEL (axiom 30, ledger #74):
            # keying this on time_state=="expired" alone let records labeled
            # "superseded" — whose windows had ALSO ended — sail through and
            # show 9-B "partly open until Aug 23" a full week stale. Any
            # open/partial whose own end time is behind the build clock
            # displays CLOSED, whatever its label says.
            # A TIME CHECK RUNS IN BOTH DIRECTIONS (axiom 36, ledger #105).
            # The expired->closed rule above was written against the sighting
            # that prompted it and guarded ONE end of the window. An opening
            # announced on the 3rd for the 6th was therefore stored "open" and
            # painted green from the moment it was ingested — a gillnetter saw
            # a section shown open for gillnetting two days before it opened.
            # "Open" is a claim about NOW: before the start it is UPCOMING,
            # after the end it is CLOSED, and only between them is it open.
            _ends = a.get("ends")
            _starts = a.get("starts")
            if st in ("open", "partial") and (
                    ts == "expired" or (_ends and str(_ends) < str(now))):
                st = "closed"
            elif st in ("open", "partial") and (
                    ts == "upcoming" or (_starts and str(_starts) > str(now))):
                st = "upcoming"
            subrules = []
            for rr in (a.get("rules") or []):
                pts = [[round(pp["lon"], 5), round(pp["lat"], 5)]
                       for pp in (rr.get("points") or [])
                       if isinstance(pp, dict) and pp.get("lat") and pp.get("lon")]
                subrules.append({"subject": rr.get("subject"), "status": rr.get("status"),
                                 "geometry": rr.get("geometry"), "side": rr.get("side"),
                                 "distance_nmi": rr.get("distance_nmi"), "pts": pts,
                                 "pt_labels": [(pp.get("lat_dm") or "") + " " + (pp.get("lon_dm") or "")
                                               for pp in (rr.get("points") or []) if isinstance(pp, dict)],
                                 "text": (rr.get("text") or "")[:400]})
            rec = {"status": st, "starts": a.get("starts"), "ends": a.get("ends"),
                   "eo": rel.get("emergency_order"), "title": rel.get("title"),
                   "published": pub, "time_state": ts, "url": rel.get("url"),
                   "rel": rel.get("id"),
                   "shore_only": a.get("shore_only"), "shore_bands": a.get("shore_bands") or [],
                   "rules": subrules, "period_text": (a.get("period_text") or "")[:600]}
            sec = a.get("section")
            if tha:
                # A TERMINAL HARVEST AREA release governs a pocket, never whole
                # sections. Painting 12-A/12-B fully open off the Hidden Falls
                # THA opener was a wrong opening waiting for the day the
                # region-wide fishery closes around the pocket. A THA record
                # renders at most PARTIAL on its host sections, at the LOWEST
                # rank, so it only fills where nothing region/district/section
                # scoped speaks.
                if sec and sec in sections:
                    codes = [sec]
                elif a.get("district") is not None:
                    codes = secs_by_dist.get(dist_name(a.get("district")), [])
                else:
                    # no host named: the pocket statement surfaces as a NAMED
                    # advisory note (Deep Inlet THA closing to all common-
                    # property fisheries, ledger #70) — its words shown on the
                    # area page, no section painted (a pocket closure does not
                    # change the surrounding fishery's status)
                    import re as _re
                    nm = (a.get("tha_pocket") or tha or "THA").strip()
                    key = _re.sub(r"[^a-z0-9]+", "", nm.lower())
                    # an advisory whose own window has ended is history, not
                    # status — it never earns a note (Gunnuk's June opener).
                    # EXCEPT an until-further-notice closure: its "effective"
                    # date can misread as an end, and the closure stands until
                    # a new announcement lifts it.
                    # EVERY STATEMENT ABOUT THE POCKET IS KEPT, then judged
                    # together (ledger #264, cause D). The note used to be the
                    # LAST statement written: Carroll Inlet's thirteen windows by
                    # gear collapsed to one drift-gillnet day labelled with all
                    # three gears, and Little Port Walter's July 1 closure of a
                    # corner read OPENS SOON while its June troll fishery was
                    # missing. Collected here, resolved after the loop.
                    tha_items.setdefault(key, []).append((pub or "", rel, a, nm))
                    continue
                rec = dict(rec); rec["scope"] = "tha"
                if rec["status"] == "open":
                    rec["status"] = "partial"       # a pocket open = some waters open
            elif a.get("region_wide") and sec is None and a.get("district") is None:
                # a region-wide fishery statement (e.g. the summer troll
                # opener/closure) governs every section for its gear
                codes = list(sections.keys()); rec = dict(rec); rec["scope"] = "region"
            elif sec and sec in sections:
                codes = [sec]; rec = dict(rec); rec["scope"] = "section"
            elif sec is None and a.get("district") is not None:
                # A NAMED POCKET IS NOT ITS DISTRICT (ledger #264, cause L).
                # "Redoubt Bay, Kanga Bay, and contiguous waters: will be closed"
                # under the District 13 heading closes two bays in Section 13-B;
                # spread across the district it closed all of Section 13-C and
                # left 13-B's record without the closure. A district-level
                # closure whose subject is a named water travels as words on the
                # same release's open records in that district instead.
                import re as _re2
                subj = [r.get("subject") or "" for r in (a.get("rules") or [])]
                if st == "closed" and subj and not any(_re2.match(r"\s*(?:district|section)\b", x, _re2.I) for x in subj):
                    pocket_closures.setdefault((rel.get("id"), dist_name(a.get("district"))), []).extend(
                        {"subject": x, "status": "closed", "geometry": None, "side": None, "distance_nmi": None,
                         "pts": [], "pt_labels": [], "text": (r.get("text") or x)[:400]}
                        for x, r in zip(subj, a.get("rules") or []))
                    continue
                codes = secs_by_dist.get(dist_name(a.get("district")), []); rec = dict(rec); rec["scope"] = "district"
            else:
                continue
            SCOPE_RANK = {"section": 3, "district": 2, "region": 1, "tha": 0}

            def rank(r):
                return (1 if r.get("time_state") == "in_force" else 0,
                        SCOPE_RANK.get(r.get("scope"), 0), r.get("published") or "")
            for c in codes:
                prev = status[gear].get(c)
                if prev is None or rank(rec) >= rank(prev):
                    status[gear][c] = dict(rec)

    for rel in releases:
        for g in GEARS:
            consider(rel, g)
    for (rid, dname), rules in pocket_closures.items():
        for g in GEARS:
            for c in secs_by_dist.get(dname, []):
                r = status[g].get(c)
                if r and str(r.get("rel")) == str(rid) and r.get("status") in ("open", "partial", "upcoming"):
                    r["rules"] = list(r.get("rules") or []) + [dict(x) for x in rules]
                    if r["status"] == "open":
                        r["status"] = "partial"
    for key, items in tha_items.items():
        note = _pocket_note(items, now)
        if note:
            tha_notes[key] = note
    return status, sorted(tha_notes.values(), key=lambda n: n.get("published") or "", reverse=True)


_GEAR_WORDS = [("purse seine", r"\bpurse\s+seine|\bseine\b"), ("drift gillnet", r"\bdrift\s+gillnet|\bgillnet"),
               ("troll", r"\btroll")]


def _pocket_note(items, now):
    """One hatchery-pocket note from every statement its NEWEST release makes.

    Each statement's windows are read (several to a statement where it lists
    them), with the gears its own words name. The note then says what is true
    NOW: the gears fishing inside a window now; else the next window to open;
    else a closure in force. A statement that only closes water is never shown
    as "opens soon" (ledger #264). The full list travels as `windows` so the
    page can judge the clock itself."""
    import re as _re
    import datetime as _dt
    from timemodel import parse_windows, parse_period, weekly_pattern
    newest = max(p for p, _r, _a, _n in items)
    seen, wins = set(), []
    rel0 = name0 = None
    for pub, rel, a, nm in sorted(items, key=lambda x: x[0], reverse=True):
        if id(a) in seen:
            continue
        seen.add(id(a))
        if pub == newest:
            rel0 = rel0 or rel; name0 = name0 or nm
        text = a.get("period_text") or ""
        # "unless closed by emergency order" is boilerplate on every opener, not
        # a closure (Neets Bay's June troll fishery vanished on it — ledger #264)
        bare = _re.sub(r"unless\s+(?:otherwise\s+)?(?:modified|closed|changed|superseded)\s+by\s+"
                       r"(?:an?\s+)?(?:emergency order|subsequent[a-z ]{0,30}announcement)", " ", text, flags=_re.I)
        # "reopen" is an opening too (red team: a "will reopen" statement
        # read as a closure)
        closure = (a.get("status") == "closed"
                   or bool(_re.search(r"\bnot\s+(?:be\s+)?open\b", bare, _re.I))
                   or (bool(_re.search(r"\bclos(?:ed|e|ure|ing)\b", bare, _re.I))
                       and not _re.search(r"\b(?:re-?)?open", bare, _re.I)))
        # a clause LABELLED with its gear ("Troll: will be open during those
        # periods the purse seine fishery is closed") is that gear's alone —
        # the other gear it mentions is the condition, not a fishery
        lab = list(_re.finditer(r"\b(purse\s+seine|drift\s+gillnet|troll)\s*(?::|—|–|--)\s", text, _re.I))
        if lab:
            g0 = " ".join(lab[-1].group(1).lower().split())
            gl = [g0]
        else:
            gl = [g for g, rx in _GEAR_WORDS if _re.search(rx, text, _re.I)] or list(rel.get("gear") or [])
        cm = _re.search(r"during (?:those|the) periods? (?:when |that )?the (purse seine|net) fisher(?:y|ies) (?:is|are) closed", text, _re.I)
        complement = (cm.group(1).lower() if cm else None)
        yr = int((pub or "2026")[:4]) if (pub or "")[:4].isdigit() else 2026
        ws = parse_windows(text, yr, pub) or [(a.get("starts"), a.get("ends"))]
        if closure:
            # a closure's one stated instant ("closed ... effective 12:01 a.m.,
            # Monday, August 31") is when it BEGINS, not when it ends
            ps, pe, kind = parse_period(bare, yr, pub)
            if kind == "close_only" and pe:
                ws = [(pe, None)]
            elif not any(s_ or e_ for s_, e_ in ws):
                ws = [(None, None)]
        # A SEASON ENVELOPE IS NOT A FISHING PERIOD: "open ... on a rotational
        # basis from June 13 through August 31. The rotational periods are as
        # follows: Purse Seine — ..." lists the real 24-hour periods; the
        # envelope that contains two or more of them is dropped, or every
        # gear reads open every day of the rotation (Anita Bay, ledger #264).
        if len(ws) > 2:
            def _within(i, j):
                (a1, b1), (a2, b2) = ws[i], ws[j]
                return i != j and a1 and b1 and a2 and b2 and a1 <= a2 and b2 <= b1 and (a1, b1) != (a2, b2)
            env = {i for i in range(len(ws)) if sum(_within(i, j) for j in range(len(ws))) >= 2}
            ws = [w for i, w in enumerate(ws) if i not in env] or ws
        spec = weekly_pattern(bare) if not closure else None
        for s_, e_ in ws:
            wins.append({"starts": s_, "ends": e_, "gear": gl, "closure": closure, "weekly": spec,
                         "complement": complement, "pub": pub, "rel": rel,
                         "partial": a.get("status") == "partial", "ufn": bool(_re.search(r"until further notice", text, _re.I)),
                         "text": text[:350]})
    # A NEWER RELEASE GOVERNS FROM ITS PUBLICATION (ledger #264, red team).
    # ADF&G restates a pocket's whole picture in each release, so the older
    # release stops counting the moment the newer one is published. One
    # exception: a newer release that ONLY announces a closure from a stated
    # future instant ("closed ... effective 12:01 a.m., Monday, August 31") —
    # until that instant the older schedule still stands (Deep Inlet was
    # fishing its weekly slots from August 27 to 30). Anything else in the
    # newer release — a reopening, a changed window — ends the older one at
    # publication, so an older OPEN can never outlive a newer "closes now".
    pubs = sorted({w["pub"] for w in wins}, reverse=True)
    cut = None
    kept = []
    for pb in pubs:
        mine = [w for w in wins if w["pub"] == pb]
        if cut is None:
            kept.extend(mine)
        else:
            for w in mine:
                if w["starts"] and str(w["starts"]) >= cut:
                    continue
                if not w["ends"] or str(w["ends"]) > cut:
                    w = dict(w, ends=cut, ufn=False)
                kept.append(w)
        here = pb or ""
        if mine and all(w["closure"] and w["starts"] for w in mine):
            here = max(here, min(str(w["starts"]) for w in mine))
        if here:
            cut = here if cut is None else min(cut, here)
    wins = kept
    n = str(now)
    def inside(w):
        return (not w["starts"] or str(w["starts"]) <= n) and (not w["ends"] or n <= str(w["ends"]))

    def slots(w):
        """A weekly schedule inside its season: the open slot now, else the next one."""
        days, (h1, m1), (h2, m2) = w["weekly"]
        try:
            t0 = _dt.datetime.fromisoformat(n[:16])
        except Exception:
            return None, None
        for k in range(0, 9):
            d = (t0 + _dt.timedelta(days=k)).date()
            if d.weekday() not in days:
                continue
            a_ = _dt.datetime(d.year, d.month, d.day, h1, m1)
            b_ = _dt.datetime(d.year, d.month, d.day, h2, m2)
            if b_ <= a_:
                b_ += _dt.timedelta(days=1)
            if w["ends"] and a_.isoformat() > str(w["ends"]):
                return None, None
            if a_ <= t0 <= b_:
                return (a_.isoformat(), b_.isoformat()), None
            if a_ > t0:
                return None, (a_.isoformat(), b_.isoformat())
        return None, None

    fishing, later = [], []
    for w in wins:
        if w["closure"] or not w["starts"]:
            continue
        if w.get("weekly") and inside(w):
            # A WEEKLY SCHEDULE IS OPEN ONLY ON ITS DAYS (ledger #264): Deep
            # Inlet's seine fishes Sun/Thu/Fri, its gillnet Mon-Wed, its troll
            # Saturday; inside the season window is not inside the fishery.
            now_s, next_s = slots(w)
            if now_s:
                fishing.append(dict(w, starts=now_s[0], ends=now_s[1]))
            elif next_s:
                later.append(dict(w, starts=next_s[0], ends=next_s[1]))
        elif inside(w):
            fishing.append(w)
        elif str(w["starts"]) > n:
            later.append(w)
    # "open during those periods the purse seine fishery is closed": while a
    # seine (or any net) slot is fishing, the complementary gear is not
    def _is_net(w, which):
        return any((g == "purse seine") if which == "purse seine" else g in ("purse seine", "drift gillnet")
                   for g in w["gear"])
    for w in [x for x in fishing if x.get("complement")]:
        if any(_is_net(o, w["complement"]) for o in fishing if o is not w and not o.get("complement")):
            fishing.remove(w)
    later.sort(key=lambda w: str(w["starts"]))
    closing = [w for w in wins if w["closure"] and (inside(w) or w["ufn"])]
    if fishing:
        gl = sorted({g for w in fishing for g in w["gear"]})
        pick = fishing[0]; st = "partial" if any(w["partial"] for w in fishing) else "open"
    elif later:
        pick = later[0]; gl = sorted({g for w in later if w["starts"] == pick["starts"] for g in w["gear"]}); st = "upcoming"
    elif closing:
        pick = closing[0]; gl = sorted({g for w in closing for g in w["gear"]}); st = "closed"
    else:
        return None                      # every window has ended: history, not status
    disp = name0 or "THA"
    if " " not in disp:
        # the capitalized words just before "THA" — never the sentence's
        # opening words ("Salmon may be taken in the Neets Bay" was a name)
        pm = _re.search(r"((?:[A-Z][A-Za-z'\-]+\s+){1,4}?)(?:Troll\s+)?(?:Terminal Harvest Area|THA)\b",
                        " ".join(w["text"] for w in wins)) or \
            _re.search(r"((?:[A-Z][A-Za-z'\-]+\s+){1,4}?)(?:Troll\s+|Salmon\s+)*(?:Terminal Harvest Area|THA|Special Harvest Area|SHA)\b",
                       str(rel0.get("title") or ""))
        if pm:
            disp = _re.sub(r"^(?:The|Salmon)\s+", "", pm.group(1).strip())
    relp = pick.get("rel") or rel0
    return {"name": disp, "status": st, "text": pick["text"], "eo": relp.get("emergency_order"),
            "published": pick.get("pub") or newest, "url": relp.get("url"), "rel": relp.get("id"),
            "starts": pick["starts"], "ends": pick["ends"], "gear": ", ".join(gl) or None,
            "windows": [{"starts": w["starts"], "ends": w["ends"], "gear": ", ".join(w["gear"]),
                         "closure": w["closure"]} for w in wins]}


def restatus(data_dir, log=print):
    """Rebuild se_openings_data.json from the existing geometry + new app_data.json."""
    prev_path = os.path.join(data_dir, "se_openings_data.json")
    ad_path = os.path.join(data_dir, "app_data.json")
    prev = json.load(open(prev_path, encoding="utf-8"))
    ad = json.load(open(ad_path, encoding="utf-8"))
    # the sectionless districts (2, 4, 5, 16, Dixon Entrance) must exist BEFORE
    # status mapping, or their EO statuses have nothing to land on — the very
    # miss that hid District 4's opening (ledger #60)
    try:
        from build_regions import _merge_se_districts
        _merge_se_districts(prev)
    except Exception as e:
        log(f"  (district merge skipped: {e})")
    now = ad.get("now") or datetime.utcnow().isoformat()
    status, tha_notes = recompute_status(prev["sections"], ad.get("releases", []), now)
    out = dict(prev)
    out["generated"] = ad.get("generated")
    out["as_of"] = now
    out["status"] = status
    out["tha_notes"] = tha_notes
    # ONE copy of each announcement's complete words, keyed by release; every
    # section rec points at its own by id (ledger #89). Stored once, never per
    # section — the whole SE fishery is a handful of releases.
    out["announcements"] = {
        r["id"]: {"title": r.get("title"), "published": r.get("published"),
                  "eo": r.get("emergency_order"), "url": r.get("url"),
                  "text": r.get("full_text")}
        for r in (ad.get("releases") or []) if r.get("id") and r.get("full_text")}
    log(f"  announcements with complete words: {len(out['announcements'])}"
        f" of {len(ad.get('releases') or [])}")
    json.dump(out, open(prev_path, "w", encoding="utf-8"), separators=(",", ":"))
    for g in GEARS:
        c = Counter(v["status"] for v in status[g].values())
        log(f"  {g:14s}: {len(status[g])} sections {dict(c)}")
    return prev_path


if __name__ == "__main__":
    import sys
    restatus(sys.argv[1] if len(sys.argv) > 1 else ".")
