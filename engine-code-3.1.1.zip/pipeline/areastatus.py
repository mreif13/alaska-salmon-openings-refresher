#!/usr/bin/env python3
"""Apply LIVE open/closed status to the non-Southeast areas' geometry.

Reads the per-unit status records openparse.py produced (data/areas/*.json) and
lays them onto each area's section geometry in regions_data.json — the same
{gear:{section_code:rec}} shape build_app.py already renders for Southeast.

PRECISION IS THE HARD CONSTRAINT (a wrong closure is the one thing this app must
never show), enforced structurally:
  * A section is marked open/closed/partial ONLY when the announcement names its
    unit (its own section, or a whole district that contains it) AND that name
    maps to exactly one geometry unit. Anything unmapped stays "unknown" — a
    neutral "no current announcement" state, never "closed".
  * A section-specific statement outranks a district-wide one for that section,
    and a newer release outranks an older one (same rank() idea as Southeast).
  * "All waters not listed remain closed" turns unlisted sections closed ONLY
    when every listed unit in that announcement mapped cleanly — so a recall
    miss can never manufacture a wrong closure; it degrades to "unknown".
  * An area goes status_live ONLY if at least one of its sections got a real
    status. Everything else stays boundary-reference. This is data-driven: an
    area lights up exactly when its announcements map to its geometry.

Pure stdlib.
"""
import json, os, re, glob, datetime as dt
from timemodel import parse_period, parse_windows, state_of, open_now, weekly_pattern  # noqa: F401


class _AlaskaTZ(dt.tzinfo):
    """Self-contained America/Anchorage (AKST/AKDT, US DST rule) — ADF&G windows
    are Alaska time, and 'is it open right now' must be answered on the Alaska
    clock whatever clock the machine runs (same fallback as build_data)."""
    def _dst_on(self, d):
        y = d.year
        mar = dt.datetime(y, 3, 8); mar += dt.timedelta(days=(6 - mar.weekday()) % 7)
        nov = dt.datetime(y, 11, 1); nov += dt.timedelta(days=(6 - nov.weekday()) % 7)
        return mar.replace(hour=2) <= d.replace(tzinfo=None) < nov.replace(hour=2)
    def utcoffset(self, d): return dt.timedelta(hours=-8 if self._dst_on(d) else -9)
    def dst(self, d): return dt.timedelta(hours=1) if self._dst_on(d) else dt.timedelta(0)
    def tzname(self, d): return "AKDT" if self._dst_on(d) else "AKST"


def alaska_now():
    try:
        from zoneinfo import ZoneInfo
        return dt.datetime.now(ZoneInfo("America/Anchorage")).replace(tzinfo=None, microsecond=0)
    except Exception:
        return dt.datetime.now(_AlaskaTZ()).replace(tzinfo=None, microsecond=0)


def _norm(n):
    """Normalise a unit name for matching: lowercase, drop punctuation, drop a
    leading 'the'/'remainder of the' and a trailing type word. 'Remainder of the
    Yakutat District' is the district itself for mapping — the caller downgrades
    its open to partial, since a remainder implies other parts have their own
    (possibly closed) statuses."""
    if not n:
        return ""
    t = re.sub(r"[^a-z0-9 ]+", " ", str(n).lower())
    t = re.sub(r"\s+", " ", t).strip()
    t = re.sub(r"^(the)\s+", "", t)
    t = re.sub(r"^remainder of (the )?", "", t)
    t = re.sub(r"\s+(district|section|subdistrict|area)$", "", t)
    return t.strip()


# per-unit gear: a multi-fishery release ("PWS #43": drift gillnet on the Copper,
# purse seine in the Northern District) must not stamp every unit with every
# gear — that would show a drift opening under the Seine tab, a wrong opening
# for that gear. When the unit's own text names its gear, that gear wins.
_GEARMAP = [("purse seine", "purse seine"), ("drift gillnet", "drift gillnet"),
            ("set gillnet", "set gillnet"), ("troll", "troll"), ("seine", "purse seine")]
_BARE_GILLNET = re.compile(r"(?<!set )(?<!drift )\bgillnet", re.I)


def _unit_gears(text, fallback):
    tl = (text or "").lower(); found = []
    for k, v in _GEARMAP:
        if k in tl and v not in found:
            found.append(v)
    if re.search(r"set and drift gillnett?", tl):
        for v in ("set gillnet", "drift gillnet"):
            if v not in found:
                found.append(v)
    if "drift gillnet" not in found and _BARE_GILLNET.search(tl):
        found.append("drift gillnet")
    return found or fallback


# Which areas map at which granularity, and how each section knows its parent
# district. PWS/Yakutat geometry IS districts (the section is the district);
# reflines areas (Kodiak, Chignik) carry their real parent in district_name,
# parsed district-aware from the regulation itself — which is what lets a
# district-wide order ("The Eastside Kodiak District will close") map onto its
# member sections.
def _build_index(region_key, block):
    """Map normalised unit-name -> [section_code], district -> [member codes]
    (the district unit itself, when the geometry carries one, plus every unit
    inside it — so 'the Eshamy District will remain closed' paints the district
    polygon AND its Main Bay / Crafton Island subdistricts), and a composite
    'name|district' index so two 'General Subdistrict's in different districts
    stay unambiguous."""
    by_name = {}
    dist_self = {}                          # district name -> the unit that IS it
    dist_members = {}                       # district name -> units inside it
    by_composite = {}
    area_label = _norm(block.get("area_label") or "")
    for code, s in block["sections"].items():
        for cand in (s.get("name"), s.get("label"), code):
            k = _norm(cand)
            if k:
                by_name.setdefault(k, set()).add(code)
        nm = _norm(s.get("name"))
        dn = _norm(s.get("district_name"))
        if re.search(r"\bdistrict$", str(s.get("name") or ""), re.I) or (
                block.get("geometry_kind") != "reflines" and region_key in ("PWS", "Yakutat")
                and (not dn or dn == area_label)):
            dist_self.setdefault(nm, set()).add(code)      # this unit IS a district
        if dn and dn != area_label and dn != nm:
            dist_members.setdefault(dn, set()).add(code)
            if nm:
                by_composite.setdefault(nm + "|" + dn, set()).add(code)
    # THE KIND OF A UNIT IS PART OF ITS IDENTITY (ledger #114). Names are
    # normalised by stripping the trailing type word, so "Eastern District"
    # and "Eastern Subdistrict" collapse to the same key — and Lower Cook
    # Inlet's EASTERN DISTRICT was binding to Upper Cook Inlet's EASTERN
    # SUBDISTRICT, a different body of water in a different fishery. A closure
    # painted there is a wrong closure, which this app must never show.
    kinds = {}
    for code, s2 in block["sections"].items():
        nm2 = str(s2.get("name") or code)
        m2 = re.search(r"\b(district|subdistrict|section|area)\s*$", nm2, re.I)
        kinds[code] = (m2.group(1).lower() if m2 else "")
    return by_name, (dist_self, dist_members, kinds), by_composite


def _map_unit(u, by_name, by_district, by_composite=None):
    """Return the set of section codes a parsed unit names, or empty if it cannot
    be mapped unambiguously (which keeps those sections 'unknown', never wrong)."""
    nm = _norm(u.get("name"))
    if not nm:
        return set()
    # NORTON SOUND SUBDISTRICTS ARE NUMBERED INTO THEIR STATISTICAL AREAS
    # (333-N0 / 333-Nx): the chart's polygons are all named "Norton Sound
    # District", so a subdistrict resolves by its number, never by name
    m = re.match(r"norton sound subdistrict (\d)$", nm)
    if m:
        allc = {c for codes in by_name.values() for c in codes}
        return {c for c in allc if str(c).startswith("333" + m.group(1))}
    if u.get("kind") == "district":
        dist_self, dist_members = by_district[0], by_district[1]
        kinds = by_district[2] if len(by_district) > 2 else {}
        own = set(dist_self.get(nm) or ())
        members = set(dist_members.get(nm) or ())
        # A district-wide CLOSED distributes safely to every unit inside it.
        # A district-wide OPEN/PARTIAL paints only the district's own polygon —
        # asserting "some waters open" on a carve-out subdistrict the order
        # never opened (Perry Island, when only Cannery Creek opened) would be
        # a wrong opening. Where no district polygon exists (Kodiak reflines),
        # the members ARE the district and take its status.
        if u.get("status") == "closed":
            got = own | members
        else:
            got = own or members
        if got:
            return got
        # the last-resort name match must not cross KINDS: a district may fall
        # back to a unit that is itself a district (or carries no type word),
        # never to a subdistrict or a section that merely shares its name.
        if nm in by_name and len(by_name[nm]) == 1:
            code = next(iter(by_name[nm]))
            if kinds.get(code, "") in ("", "district"):
                return set(by_name[nm])
        return set()
    # a name+parent composite resolves duplicates ("General Subdistrict of the
    # Coghill District") that a bare name cannot
    if by_composite and u.get("parent"):
        k = nm + "|" + _norm(u.get("parent"))
        if k in by_composite and len(by_composite[k]) == 1:
            return set(by_composite[k])
    # a section / subdistrict / other: match by exact normalised name
    if nm in by_name and len(by_name[nm]) == 1:
        return set(by_name[nm])
    return set()


GEAR_ALL = ["purse seine", "drift gillnet", "set gillnet", "troll"]

# ---- coordinate conversion + drawable sub-rules ------------------------------
_DM = re.compile(r"(\d{1,3})\s*[°º˚]\s*(\d{1,2}(?:\.\d+)?)\s*[′'’´]?\s*([NSEW])", re.I)


def _dm2dec(dm):
    """Strict degrees-minutes -> decimal; None unless clean and inside Alaska."""
    if not dm:
        return None
    m = _DM.match(str(dm).strip())
    if not m:
        return None
    v = int(m.group(1)) + float(m.group(2)) / 60.0
    h = m.group(3).upper()
    if h in ("S", "W"):
        v = -v
    if h in ("N", "S") and not (50 <= v <= 72):
        return None
    if h in ("E", "W") and not (-180 <= v <= -125):
        return None
    return round(v, 6)


def _subrules_for(u, gear, sec_bbox):
    """A unit's parsed coordinate rules -> the drawable sub-rule shape the SE
    renderer already paints ({status, side, geometry, pts, pt_labels, text}).
    A single-latitude cutoff becomes a line across the unit's own bbox at the
    regulation's own latitude — that IS what 'south of 60°56.00′ N' means
    within that unit. A rule scoped to other gears is excluded from this
    gear's record. Anything that fails strict conversion is dropped (words
    stay in the text; the map never draws a guessed line)."""
    out = []
    for r in (u.get("rules") or []):
        if r.get("gears") and gear not in r["gears"] and gear != "all":
            continue
        pts = []
        labels = []
        for p in (r.get("points") or []):
            la = _dm2dec(p.get("lat_dm"))
            lo = _dm2dec(p.get("lon_dm"))
            if la is not None and lo is not None:
                pts.append([lo, la])
                labels.append(f"{p.get('lat_dm')} {p.get('lon_dm')}")
            elif la is not None and r.get("geometry") == "lat_cutoff" and sec_bbox:
                w = sec_bbox[2] - sec_bbox[0]
                pts = [[sec_bbox[0] - w * 0.05, la], [sec_bbox[2] + w * 0.05, la]]
                labels = [f"{p.get('lat_dm')} (line across the unit)"] * 2
                break
        if len(pts) >= 2:
            out.append({"subject": u.get("name"), "status": r.get("status"),
                        "geometry": "line", "side": r.get("side"),
                        "distance_nmi": None, "pts": pts, "pt_labels": labels,
                        "text": (r.get("text") or "")[:300]})
        elif r.get("text"):
            out.append({"subject": u.get("name"), "status": r.get("status"),
                        "geometry": r.get("geometry") or "other", "side": r.get("side"),
                        "distance_nmi": None, "pts": [], "pt_labels": [],
                        "text": (r.get("text") or "")[:300]})
    return out


def _pip(pt, ring):
    """Ray-cast point-in-ring."""
    x, y = pt
    inside = False
    n = len(ring)
    for i in range(n):
        x1, y1 = ring[i][0], ring[i][1]
        x2, y2 = ring[(i + 1) % n][0], ring[(i + 1) % n][1]
        if (y1 > y) != (y2 > y):
            xin = (x2 - x1) * (y - y1) / (y2 - y1) + x1
            if x < xin:
                inside = not inside
    return inside


def _containing_code(block, lon, lat):
    """The polygon unit that geometrically contains a point (smallest wins, so a
    subdistrict beats its district)."""
    best = None
    best_area = None
    for code, s in block["sections"].items():
        for poly in (s.get("polys") or []):
            if poly and _pip((lon, lat), poly[0]):
                b = s.get("bbox") or [0, 0, 0, 0]
                a = (b[2] - b[0]) * (b[3] - b[1])
                if best is None or a < best_area:
                    best, best_area = code, a
    if best is not None:
        return best
    # shore-marker fallback: an ADF&G regulation marker often stands ON the
    # beach, a few hundred meters landward of the water polygon, so strict
    # point-in-polygon misses (Yakutat's Lost River markers). Attach only when
    # geometry is unambiguous: the point must fall inside exactly ONE unit's
    # (slightly padded) bbox AND lie within ~2 km of that unit's boundary.
    # Ambiguity or distance means no attachment — never a guessed host.
    PAD = 0.02
    cands = []
    for code, s in block["sections"].items():
        b = s.get("bbox")
        if b and b[0] - PAD <= lon <= b[2] + PAD and b[1] - PAD <= lat <= b[3] + PAD \
                and s.get("polys"):
            cands.append(code)
    if len(cands) != 1:
        return None
    import math
    s = block["sections"][cands[0]]
    ky = 111.32                              # km per deg lat
    kx = 111.32 * math.cos(math.radians(lat))
    dmin = None
    for poly in s.get("polys") or []:
        for x, y in poly[0]:
            d = math.hypot((x - lon) * kx, (y - lat) * ky)
            if dmin is None or d < dmin:
                dmin = d
    return cands[0] if dmin is not None and dmin <= 2.0 else None


def _rank(rec):
    """Precedence: newest release first (each ADF&G advisory restates the current
    picture — an older section-scope 'open' must never outrank a newer
    district-wide closure), then section over district within the same release,
    then in-force over lapsed."""
    return (rec.get("published") or "",
            1 if rec.get("scope") == "section" else 0,
            1 if rec.get("time_state") == "in_force" else 0)


def _windows_state(wins, now):
    """in_force inside any window; upcoming before the first or between two;
    expired after the last. Windows are (start_iso, end_iso) pairs."""
    n = now.isoformat() if hasattr(now, "isoformat") else str(now)
    if any(a <= n <= b for a, b in wins):
        return "in_force"
    if any(a > n for a, _b in wins):
        return "upcoming"
    return "expired"


def _prefer_within(prev, new):
    """Which of two records FROM THE SAME RELEASE stands for one unit and gear.

    "The Copper River District will remain closed for the remainder of the week"
    and "...will open at 7:00 am on Monday, August 31 for a 12-hour period" are
    both true (ledger #264, cause G). Ranked as equals, the closure won and the
    Monday opening was never on the chart. An open-ended closure and a later
    opening do not conflict: the upcoming record already says "not open now",
    so it is the one that carries both facts."""
    if prev is None:
        return True
    def _ufn_closed(r):
        return r.get("status") == "closed" and not r.get("ends")
    if _ufn_closed(prev) and new.get("status") == "upcoming":
        return True
    if _ufn_closed(new) and prev.get("status") == "upcoming":
        return False
    return _rank(new) >= _rank(prev)


def _host_for_unmapped(units, i, mapped):
    """The mapped district an unmapped named water (a river, a bay) belongs to,
    read off the announcement's own order: Yakutat lists its rivers and then
    "Remainder of the Yakutat District", then "Yakataga District" and ITS
    rivers. So: the next "Remainder of ..." unit after it, else the nearest
    mapped district before it."""
    for j in range(i + 1, len(units)):
        if mapped.get(j) and re.match(r"\s*remainder of\b", units[j].get("name") or "", re.I):
            return j
        if mapped.get(j) and units[j].get("kind") == "district":
            break
    for j in range(i - 1, -1, -1):
        if mapped.get(j) and units[j].get("kind") == "district":
            return j
    return None


def apply_area(region_key, block, releases, now):
    """Lay live status onto one area block. Returns True if it went live."""
    by_name, by_district, by_composite = _build_index(region_key, block)
    gears_present = set()
    status = {}                                     # gear -> code -> rec
    mapped_any = False
    for rel in sorted(releases, key=lambda r: r.get("published") or ""):
        gears = rel.get("gear") or ["all"]
        pub = rel.get("published") or ""
        # was every named unit mappable? (gates 'all others closed')
        all_mapped = True
        # Does this release close waters the geometry cannot place (a river inside
        # a district, an unmapped section)? Then a DISTRICT-scope open from the
        # same release is downgraded to partial — the district holds closed water
        # this map cannot draw, and plain green would paint over it. (Yakutat:
        # "Yakataga District will be open" + "Tsiu River is closed".)
        unmapped_closed = any(u.get("status") in ("closed", "partial")
                              and not _map_unit(u, by_name, by_district, by_composite)
                              for u in rel.get("units", []))
        # the WORDS of those unplaceable closed/restricted waters, as text-only
        # rules — a district shown partial because of them owes its captain the
        # announcement's own sentences saying which waters and why. Units whose
        # coordinates draw elsewhere (geo-attach below) are skipped here.
        unplaced_rules = []
        for u in rel.get("units", []):
            if u.get("status") not in ("closed", "partial"):
                continue
            if _map_unit(u, by_name, by_district, by_composite):
                continue
            if any(len(rr.get("points") or []) >= 2 for rr in (u.get("rules") or [])):
                continue                     # drawn on its containing unit instead
            unplaced_rules.append({
                "subject": u.get("name"), "status": "closed" if u.get("status") == "closed" else "restricted",
                "geometry": None, "side": None, "distance_nmi": None,
                "pts": [], "pt_labels": [],
                "text": re.sub(r"\s+", " ", (u.get("period_text") or "")).strip()[:300]})
        applied = {}                                # gear -> code -> rec (this release)
        for u in rel.get("units", []):
            codes = _map_unit(u, by_name, by_district, by_composite)
            if not codes:
                all_mapped = False
                continue
            mapped_any = True
            # ADF&G writes "open at 7:00 am on Monday, August 31"; the " on " before
            # the weekday defeats the time model's separator, so drop it here.
            pt = re.sub(r"\bon\s+((?:mon|tues|wednes|thurs|fri|satur|sun)day)\b", r"\1",
                        u.get("period_text") or "", flags=re.I)
            # a locational clause between the hours and the date ("from 8:00 am
            # until 8:00 pm, in the Northern District on Saturday, August 29")
            # defeats the time model and left an EXPIRED 12-hour opening showing
            # partly-open the next day — strip it from the PARSING copy only
            # (the captain still reads the verbatim words).
            pt = re.sub(r",?\s+in\s+the\s+[A-Z][A-Za-z ]{2,40}?\b(?:District|Subdistrict|Section)\b", "", pt)
            _yr = int((pub or "2026")[:4]) if pub[:4].isdigit() else 2026
            s, e, conf = parse_period(pt, _yr, pub)
            # SEVERAL PERIODS IN ONE STATEMENT (ledger #264, cause F): Kotzebue's
            # "Sunday 10-6 ... Monday 10-6" is two openings; the record carries
            # every window and is in force only inside one of them.
            wins = parse_windows(pt, _yr, pub)
            if len(wins) >= 2:
                s, e = wins[0][0], max(b for _a, b in wins)
                ts = _windows_state(wins, now)
            else:
                wins = None
                ts = state_of(s, e, now)
            asserted = u.get("status")              # open / closed / partial
            # a district-wide open in a release that also closes unplaceable
            # waters, or a "Remainder of the ..." open, is at most PARTIAL
            if asserted == "open" and u.get("kind") == "district" and (
                    unmapped_closed
                    or re.match(r"\s*remainder of\b", u.get("name") or "", re.I)):
                asserted = "partial"
            # translate asserted status + time window into a display status.
            # An OPEN with an unparseable window is NOT defaulted to green — that
            # would tell a captain to fish on an unproven opening — it degrades to
            # "unknown" (neutral), the safe direction.
            weekly_spec = None   # reset per unit: a pattern must never leak
            if asserted == "closed":
                disp = "closed"
            elif asserted == "partial":
                disp = {"in_force": "partial", "upcoming": "upcoming",
                        "expired": "closed", "unknown": "partial"}[ts]
                # a partly-open DAILY or weekly fishery is partly open only in
                # its hours (ledger #264, cause E) — the same recurrence rule as
                # a full opening below, carried on the record for the page
                pat = weekly_pattern(pt) if ts in ("in_force", "upcoming") else None
                if pat is not None:
                    _days, (_sh, _sm), (_eh, _em) = pat
                    weekly_spec = {"days": sorted(int(d) for d in _days),
                                   "from": f"{_sh:02d}:{_sm:02d}", "to": f"{_eh:02d}:{_em:02d}"}
                    if ts == "in_force":
                        cur = now.weekday() in _days and (_sh * 60 + _sm) <= (now.hour * 60 + now.minute) <= (_eh * 60 + _em)
                        disp = "partial" if cur else "upcoming"
            else:  # open
                disp = {"in_force": "open", "upcoming": "upcoming",
                        "expired": "closed", "unknown": "unknown"}[ts]
                # A weekly fishery ("on Tuesdays and Fridays from 7:00 a.m. to
                # 7:00 p.m.") is open ONLY on its own days and hours — whatever
                # the envelope says, and even when no envelope parsed at all
                # (Chinitna Bay's phrasing yields a schedule but no date range).
                pat = weekly_pattern(pt) if ts != "expired" else None
                if pat is not None:
                    fishing, _why = open_now(pt, s, e, now)
                    if fishing is None:
                        days, (sh, sm), (eh, em) = pat
                        cur = now.weekday() in days and (sh * 60 + sm) <= (now.hour * 60 + now.minute) <= (eh * 60 + em)
                        fishing = cur
                    disp = "open" if fishing else "upcoming"
                    # THE PATTERN TRAVELS WITH THE RECORD (axiom 36, ledger #108).
                    # A weekly fishery has no date window to re-check at read
                    # time — "Tuesdays and Fridays, 7 a.m. to 7 p.m." is a
                    # recurrence — so a status computed at BUILD time froze,
                    # and Chinitna Bay read OPEN one minute after its Friday
                    # period closed, and would have read open all weekend.
                    # Carrying the recurrence lets the page judge the day and
                    # the hour in Alaska time, in the reader's own browser.
                    _days, (_sh, _sm), (_eh, _em) = pat
                    weekly_spec = {"days": sorted(int(d) for d in _days),
                                   "from": f"{_sh:02d}:{_sm:02d}",
                                   "to": f"{_eh:02d}:{_em:02d}"}
                elif disp == "open":
                    fishing, _why = open_now(pt, s, e, now)
                    if fishing is False:
                        disp = "upcoming"
            scope = "district" if u.get("kind") == "district" else "section"
            rec = {"status": disp, "time_state": ts, "starts": s, "ends": e,
                   "weekly": weekly_spec, "windows": [list(w) for w in wins] if wins else None,
                   "eo": rel.get("emergency_order"), "title": rel.get("title"),
                   "published": pub, "url": rel.get("url"), "scope": scope,
                   "rel": rel.get("release_id"),
                   "period_text": (u.get("period_text") or "")[:560],
                   "unit_name": u.get("name")}
            for g in _unit_gears(u.get("period_text"), gears):
                for c in codes:
                    # per-gear, per-section record with its DRAWABLE sub-rules —
                    # the "exactly where" a partial owes its captain
                    rec2 = dict(rec)
                    rec2["rules"] = _subrules_for(u, g, (block["sections"].get(c) or {}).get("bbox"))
                    # a district downgraded (or held partial) by unplaceable
                    # closures carries their verbatim sentences
                    if u.get("kind") == "district" and unplaced_rules:
                        rec2["rules"] = rec2["rules"] + [dict(r) for r in unplaced_rules]
                    # a gear-scoped open carve ("waters open to drift gillnetting
                    # ... occur east of a line") limits THIS gear to part of the
                    # unit: its status for this gear is partial, exactly-where drawn
                    if rec2["status"] == "open" and any(
                            rr.get("status") == "open" and rr.get("side") and rr.get("pts")
                            for rr in rec2["rules"]):
                        rec2["status"] = "partial"
                    # rank WITHIN a release too: "The Afognak District will close
                    # Saturday (… and the Southwest Afognak Section is extended
                    # until Wednesday)" — the district expansion must not
                    # overwrite the section's own extension.
                    prev = applied.get(g, {}).get(c)
                    if _prefer_within(prev, rec2):
                        applied.setdefault(g, {})[c] = rec2
        # NAMED WATERS THE MAP CANNOT DRAW STILL KEEP THEIR HOURS (ledger #264,
        # cause I). Yakutat Bay, the Situk-Ahrnklin Inlet and Manby Shore fish
        # until noon Thursday; the Yakutat District around them closes noon
        # Wednesday. Drawn only as the district, those waters read CLOSED for
        # their last 24 hours. Their window is folded into their host district's
        # record, which becomes partly open (only those waters) for the extra
        # time, with their own words.
        _units = rel.get("units", [])
        _mapped = {k: bool(_map_unit(uu, by_name, by_district, by_composite)) for k, uu in enumerate(_units)}
        for k, uu in enumerate(_units):
            if _mapped[k] or uu.get("status") not in ("open", "partial"):
                continue
            upt = re.sub(r"\bon\s+((?:mon|tues|wednes|thurs|fri|satur|sun)day)\b", r"\1",
                         uu.get("period_text") or "", flags=re.I)
            uw = parse_windows(upt, _yr, pub)
            if len(uw) < 2:
                us, ue, _c = parse_period(upt, _yr, pub)
                uw = [(us, ue)] if us and ue else []
            if not uw:
                continue
            hk = _host_for_unmapped(_units, k, _mapped)
            if hk is None:
                continue
            for hc in _map_unit(_units[hk], by_name, by_district, by_composite) or []:
                for g in _unit_gears(uu.get("period_text"), gears):
                    hrec = applied.get(g, {}).get(hc)
                    if hrec is None or not hrec.get("starts") or not hrec.get("ends"):
                        continue
                    hw = [tuple(w) for w in (hrec.get("windows") or [(hrec["starts"], hrec["ends"])])]
                    extra = [w for w in uw if w[1] > max(b for _a, b in hw) or w[0] < min(a for a, _b in hw)]
                    if not extra:
                        continue
                    allw = sorted(set(hw) | set(extra))
                    hrec = dict(hrec)
                    hrec["windows"] = [list(w) for w in allw]
                    hrec["starts"], hrec["ends"] = allw[0][0], max(b for _a, b in allw)
                    hrec["time_state"] = _windows_state(allw, now)
                    hrec["status"] = {"in_force": "partial", "upcoming": "upcoming",
                                      "expired": "closed"}[hrec["time_state"]]
                    hrec["rules"] = list(hrec.get("rules") or []) + [{
                        "subject": uu.get("name"), "status": "open", "geometry": None, "side": None,
                        "distance_nmi": None, "pts": [], "pt_labels": [],
                        "text": re.sub(r"\s+", " ", (uu.get("name") or "") + ": " + (uu.get("period_text") or "")).strip()[:300]}]
                    applied[g][hc] = hrec
        # an UNMAPPED closed unit that carries the closure line's own
        # coordinates (Yakutat's Lost River markers) still belongs on the map:
        # geometry says which mapped unit contains it, and the closure attaches
        # there as a drawable red line — an open/partial host shows partial.
        for u in rel.get("units", []):
            if u.get("status") != "closed" or _map_unit(u, by_name, by_district, by_composite):
                continue
            subs = _subrules_for(u, "all", None)
            subs = [rr for rr in subs if len(rr.get("pts") or []) >= 2]
            if not subs:
                continue
            for rr in subs:
                rr["attached"] = True        # renderer: draw line + words, never fill
            lon, lat = subs[0]["pts"][0]
            host = _containing_code(block, lon, lat)
            if not host:
                continue
            for g in _unit_gears(u.get("period_text"), gears):
                hrec = applied.get(g, {}).get(host)
                if hrec is None:
                    continue
                hrec = dict(hrec)
                hrec["rules"] = list(hrec.get("rules") or []) + subs
                if hrec["status"] == "open":
                    hrec["status"] = "partial"
                applied[g][host] = hrec
        # "all others remain closed" — only trustworthy if everything mapped
        if rel.get("all_others_closed") and all_mapped and applied:
            for g in gears:
                touched = set(applied.get(g, {}))
                for c in block["sections"]:
                    if c not in touched:
                        applied.setdefault(g, {})[c] = {
                            "status": "closed", "time_state": "in_force",
                            "starts": None, "ends": None, "eo": rel.get("emergency_order"),
                            "title": rel.get("title"), "published": pub, "url": rel.get("url"),
                            "rel": rel.get("release_id"), "scope": "all-others-closed",
                            "period_text": "All waters not listed in this announcement remain closed."}
        # merge into the running status with rank precedence
        for g, cm in applied.items():
            gears_present.add(g)
            for c, rec in cm.items():
                prev = status.get(g, {}).get(c)
                if prev is None or _rank(rec) >= _rank(prev):
                    status.setdefault(g, {})[c] = rec
    if not mapped_any:
        return False
    block["status"] = status
    block["gears"] = [g for g in GEAR_ALL if g in gears_present] or ["all"]
    block["status_live"] = True
    # These areas are updated by per-unit advisories, not one comprehensive
    # restatement, so a section with no record is "no current announcement"
    # (neutral), never "no opening" (which reads as closed).
    block["comprehensive"] = False
    return True


def apply_all(data_dir, regions_data, now=None, log=print):
    """Load data/areas/*.json, group by region, apply to each area block. Mutates
    regions_data in place; returns the set of areas that went live."""
    now = now or alaska_now()
    by_region = {}
    for f in sorted(glob.glob(os.path.join(data_dir, "areas", "*.json"))):
        try:
            r = json.load(open(f, encoding="utf-8"))
        except Exception:
            continue
        if r.get("region") and r.get("units"):
            by_region.setdefault(r["region"], []).append(r)
    live = set()
    for key, releases in by_region.items():
        block = regions_data["regions"].get(key)
        if not block:
            continue
        # ONE copy of each announcement's complete words for this area, keyed
        # by release id; the section recs point at theirs (ledger #89)
        anns = dict(block.get("announcements") or {})
        for r in releases:
            if r.get("release_id") and r.get("full_text"):
                anns[str(r["release_id"])] = {
                    "title": r.get("title"), "published": r.get("published"),
                    "eo": r.get("emergency_order"), "text": r.get("full_text"),
                    "url": ("https://www.adfg.alaska.gov/static/applications/"
                            f"dcfnewsrelease/{r['release_id']}.pdf")}
        if anns:
            block["announcements"] = anns
        if apply_area(key, block, releases, now):
            live.add(key)
            n = sum(len(v) for v in block["status"].values())
            log(f"  {key:11} LIVE: {n} section-status across gears {block['gears']}")
    # reflect status_live back into the areas[] list the page reads
    for a in regions_data.get("areas", []):
        if a["key"] in live:
            a["status_live"] = True
    return live


if __name__ == "__main__":
    import sys
    dd = sys.argv[1] if len(sys.argv) > 1 else "."
    rd = json.load(open(os.path.join(dd, "regions_data.json"), encoding="utf-8"))
    live = apply_all(dd, rd)
    print("live areas:", sorted(live))
    json.dump(rd, open(os.path.join(dd, "regions_data.json"), "w", encoding="utf-8"),
              separators=(",", ":"))
